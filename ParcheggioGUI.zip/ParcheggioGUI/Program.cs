using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ParcheggioGUI;
using Blazored.LocalStorage;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.Services.AddBlazoredLocalStorage();

builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Logging.SetMinimumLevel(LogLevel.Debug);

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri("https://localhost:8443/") });

// ✅ Cancella il token JWT ogni volta che l'app viene avviata
var host = builder.Build();
var localStorage = host.Services.GetRequiredService<ILocalStorageService>();
await localStorage.RemoveItemAsync("authToken");


await builder.Build().RunAsync();












