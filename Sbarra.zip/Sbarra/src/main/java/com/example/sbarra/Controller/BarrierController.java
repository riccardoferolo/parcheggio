package com.example.sbarra.Controller;

import com.example.sbarra.ui.SbarraUi;
import javafx.application.Application;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/barrier")
public class BarrierController {
    private final SbarraUi sbarraUi = SbarraUi.getInstance();

    @PostMapping("/open")
    public void openBarrier() {
        new Thread(() -> {
            try {
                sbarraUi.toggleSbarra(true);
            } catch (Exception e) {
                System.err.println("Errore durante l'apertura della sbarra: " + e.getMessage());
            }
        }).start();
    }

    @PostMapping("/close")
    public void closeBarrier() {
        new Thread(() -> {
            try {
                sbarraUi.toggleSbarra(false);
            } catch (Exception e) {
                System.err.println("Errore durante la chiusura della sbarra: " + e.getMessage());
            }
        }).start();
    }
}
