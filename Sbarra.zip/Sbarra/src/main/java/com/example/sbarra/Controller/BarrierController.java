package com.example.sbarra.Controller;

import com.example.sbarra.ui.SbarraUi;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import javafx.application.Application;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/barrier")
@Tag(name = "UserController", description = "Controller per la sbarra")
public class BarrierController {
    private final SbarraUi sbarraUi = SbarraUi.getInstance();

    @Operation(summary = "Apertura")
    @PostMapping("/open")
    public void openBarrier() {
        new Thread(() -> {
            try {
                sbarraUi.toggleSbarra(true);
            } catch (Exception e) {
                System.err.println("Errore durante l'apertura della sbarra: " + e.getMessage());
            }
        }).start();
    }

    @Operation(summary = "chiusura")
    @PostMapping("/close")
    public void closeBarrier() {
        new Thread(() -> {
            try {
                sbarraUi.toggleSbarra(false);
            } catch (Exception e) {
                System.err.println("Errore durante la chiusura della sbarra: " + e.getMessage());
            }
        }).start();
    }
}
