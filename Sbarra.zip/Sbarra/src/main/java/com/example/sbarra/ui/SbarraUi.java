package com.example.sbarra.ui;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class SbarraUi extends Application {
    private static final double PALO_WIDTH = 100;
    private static final double PALO_HEIGHT = 200;
    private static final double SBARRA_WIDTH = 330;
    private static final double SBARRA_HEIGHT = 20;
    private static final double SBARRA_OFFSET = 20;

    private static SbarraUi instance;

    private boolean isOpen = false; // Stato della sbarra
    private boolean isAnimating = false; // Flag per evitare conflitti
    private Rectangle sbarra;

    public static SbarraUi getInstance() {
        if (instance == null) {
            instance = new SbarraUi();
        }
        return instance;
    }

    @Override
    public void start(Stage primaryStage) {
        instance = this;

        Pane root = new Pane();

        // Creazione del palo fisso
        Rectangle palo = new Rectangle(PALO_WIDTH, PALO_HEIGHT, Color.GRAY);
        palo.setLayoutX(100);
        palo.setLayoutY(150);

        // Creazione della sbarra
        sbarra = new Rectangle(SBARRA_WIDTH, SBARRA_HEIGHT, Color.BLUE);
        sbarra.setLayoutX(100 + PALO_WIDTH / 2 - SBARRA_OFFSET);
        sbarra.setLayoutY(150 + PALO_HEIGHT / 2 - SBARRA_HEIGHT / 2);

        root.getChildren().addAll(palo, sbarra);

        Scene scene = new Scene(root, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Sbarra Simulation");
        primaryStage.show();
    }

    public synchronized void toggleSbarra(boolean x) {
        if (isAnimating) return; // Evita conflitti
        Platform.runLater(() -> {
            if (!x) {
                chiudiSbarra();
            } else {
                apriSbarra();
            }
        });
    }

    public void apriSbarra() {
        if (isOpen || isAnimating) return; // Evita doppie chiamate
        isAnimating = true;

        Timeline timeline = new Timeline();
        timeline.getKeyFrames().addAll(
                new KeyFrame(Duration.seconds(1),
                        new KeyValue(sbarra.rotateProperty(), -45),
                        new KeyValue(sbarra.translateYProperty(), -SBARRA_WIDTH / 2),
                        new KeyValue(sbarra.translateXProperty(), SBARRA_HEIGHT / 2)
                )
        );

        isOpen = true;
        isAnimating = false;

        timeline.play();
    }

    public void chiudiSbarra() {
        if (!isOpen || isAnimating) return; // Evita doppie chiamate
        isAnimating = true;

        Timeline timeline = new Timeline();
        timeline.getKeyFrames().addAll(
                new KeyFrame(Duration.seconds(1),
                        new KeyValue(sbarra.rotateProperty(), 0),
                        new KeyValue(sbarra.translateYProperty(), 0),
                        new KeyValue(sbarra.translateXProperty(), 0)
                )
        );

        isOpen = false;
        isAnimating = false;
        timeline.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}