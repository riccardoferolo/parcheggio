package com.example.sbarra;

import com.example.sbarra.ui.SbarraUi;
import javafx.application.Application;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

import java.io.PrintStream;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

@SpringBootApplication
public class SbarraApplication {

        public static void main(String[] args) {
            Thread javafxThread = new Thread(() -> Application.launch(SbarraUi.class));
            javafxThread.setDaemon(true);
            javafxThread.start();

            SpringApplication.run(SbarraApplication.class, args);
        }
    }

