package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.ParkingSpotRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Security.JwtUtil;
import Principale.Parcheggio.Token.JwtTokenHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;
import java.util.Scanner;

@Service
public class AdminService {

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    @Autowired
    private JwtUtil jwtUtil;

    private final JwtTokenHolder token;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    public AdminService(JwtTokenHolder token) {
        this.token = token;
    }

    public String Cancellatutto() {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
        }

        String username;
        String ruolo;

        try {
            username = jwtUtil.validateToken(token.getJwtToken());
            if (username == null || username.isEmpty()) {
                return "Errore: Il token non contiene un username valido.";
            }

            Optional<User> userOpt = userRepository.findByUsername(username);
            if (!userOpt.isPresent()) {
                return "Errore: Utente non trovato.";
            }

            ruolo = userOpt.get().getRuolo().toString();

            if (!ruolo.equalsIgnoreCase("ADMIN")) {
                return "Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.";
            }

            System.out.println("Utente autenticato con ruolo ADMIN: " + username);
        } catch (Exception e) {
            return "Errore durante la validazione del token: " + e.getMessage();
        }

        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
        String[] urls = {
                "https://localhost:8443/Admin/reservation/delete-all",
                "https://localhost:8443/Admin/payment/delete-all",
                "https://localhost:8443/Admin/charge/delete-all",
                "https://localhost:8443/Admin/macchine/deleteALL",
                "https://localhost:8443/Admin/user/delete-all"
        };

        String x = "";

        for (String url : urls) {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT
                HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

                restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, Void.class);
            } catch (Exception e) {
                System.err.println("Errore durante l'eliminazione della risorsa: " + e.getMessage());
                e.printStackTrace();
                return "Errore durante l'eliminazione della risorsa: " + e.getMessage();
            }
        }

        try {
            parkingSpotRepository.deleteAll();
            parkingSpotRepository.resetAutoIncrement();
            x = "Eliminato tutto con successo.";
        } catch (Exception e) {
            System.err.println("Errore durante l'eliminazione della risorsa dal database: " + e.getMessage());
            e.printStackTrace();
            return "Errore durante l'eliminazione delle risorse locali: " + e.getMessage();
        }

        return x;
    }

    public String cancellaPrenotazioni() {
        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
        String Reservation_url = "https://localhost:8443/Admin/reservation/delete-all";
        String payment_url = "https://localhost:8443/Admin/payment/delete-all";
        String charge_url = "https://localhost:8443/Admin/charge/delete-all";
        String x = "";
        //String Reservation_reset = "http://localhost:8080/reservations/reset";

        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
        }

        // Estrai il ruolo dal token e verifica che sia ADMIN
        String username;
        String ruolo;
        try {
            username = jwtUtil.validateToken(token.getJwtToken());
            if (username == null || username.isEmpty()) {
                return "Errore: Il token non contiene un username valido.";
            }

            Optional<User> userOpt = userRepository.findByUsername(username);
            if (!userOpt.isPresent()) {
                return "Errore: Utente non trovato.";
            }

            ruolo = userOpt.get().getRuolo().toString();
            if (!ruolo.equalsIgnoreCase("ADMIN")) {
                return "Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.";
            }

            System.out.println("Utente autenticato con ruolo: " + ruolo);
        } catch (Exception e) {
            return "Errore durante la validazione del token: " + e.getMessage();
        }

        // Configura le intestazioni con il token JWT
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        // Esegui le chiamate per cancellare le prenotazioni, pagamenti e richieste di ricarica
        try {
            restTemplate.exchange(Reservation_url, HttpMethod.DELETE, requestEntity, Void.class);
            restTemplate.exchange(payment_url, HttpMethod.DELETE, requestEntity, Void.class);
            restTemplate.exchange(charge_url, HttpMethod.DELETE, requestEntity, Void.class);

            x = "Eliminate le prenotazioni, i pagamenti e le richieste di ricarica con successo.";
        } catch (Exception e) {
            System.err.println("Errore durante l'eliminazione della risorsa: " + e.getMessage());
            e.printStackTrace();
            return "Errore durante l'eliminazione delle risorse: " + e.getMessage();
        }

        return x;
    }
}
