package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.Ruolo;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import Principale.Parcheggio.Security.JwtUtil;
import Principale.Parcheggio.Token.JwtTokenHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import Principale.Parcheggio.Services.*;
import Principale.Parcheggio.Services.ChargeRequestService;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class UserService {

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    Scanner s = new Scanner(System.in);

    private final JwtTokenHolder token;

    @Autowired
    private JwtUtil jwtUtil;


    private final UserRepository userRepository;
    private final ChargeRequestRepository chargeRequestRepository;

    @Autowired
    public UserService(JwtTokenHolder jwtTokenHolder, UserRepository userRepository, ChargeRequestRepository chargeRequestRepository) {
        this.token = jwtTokenHolder;
        this.userRepository = userRepository;
        this.chargeRequestRepository = chargeRequestRepository;
    }

    // Salva un nuovo utente
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // Metodo per trovare un utente per username
    public Optional<User> findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }


    public void registerUser(User user) throws IllegalArgumentException {

        // Verifica se l'email esiste già
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email già registrata");
        }

        if (!EmailValidator(user.getEmail())) {
            throw new IllegalArgumentException("Email non valida");
        }

        // Verifica se l'username esiste già
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username già esistente");
        }


        // Validazione della password
        validatePassword(user.getPassword());

        // Autocompila il ruolo e lascia che il database gestisca l'ID
        if (user.getRuolo() == null) {
            user.setRuolo(Ruolo.BASE); // Ruolo predefinito
        }

        // Imposta il saldo iniziale a 0 se non è stato specificato
        if (user.getSaldo() == 0) {
            user.setSaldo(0.0); // Imposta un saldo iniziale di 0
        }

        userRepository.save(user);
    }

    public void aggiornaSaldo(String username, double nuovoSaldo) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();
        user.setSaldo(user.getSaldo() + nuovoSaldo);
        userRepository.save(user);
    }

    public void aggiornaCarta(String username, String carta) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();
        user.setCarta_di_credito(carta);
        userRepository.save(user);
    }


    // Metodo per validare la password
    private void validatePassword(String password) {
        if (password.length() < 8) {
            throw new IllegalArgumentException("La password deve essere di almeno 8 caratteri");
        }
        if (!password.matches(".*\\d.*")) {
            throw new IllegalArgumentException("La password deve contenere almeno un numero");
        }
        if (!password.matches(".*[a-zA-Z].*")) {
            throw new IllegalArgumentException("La password deve contenere almeno una lettera");
        }

        if (!password.matches(".*[!@#\\$%\\^&\\*].*")) {
            throw new IllegalArgumentException("La password deve contenere almeno un carattere speciale (!@#$%^&*)");
        }

    }

    public User loginUser(String email, String password) {
        if (!EmailValidator(email)) { // Verifica se l'email è valida
            throw new IllegalArgumentException("Formato email non valido");
        }

        // Trova l'utente nel database
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Email non trovata"));

        // Verifica se la password è corretta
        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Password errata");
        }

        return user; // Restituisce l'utente se tutto è corretto
    }

    // Funzione per eliminare tutti gli utenti
    public void eliminaTuttiGliUtenti() {
        System.out.println("Eliminazione di tutti gli utenti dal database");
        userRepository.deleteAll();
        // Reset del contatore auto-increment per PostgreSQL
        userRepository.resetAutoIncrement();
        System.out.println("Contatore degli ID resettato a 1");
        System.out.println("Tutti gli utenti sono stati eliminati");
    }

    // Elimina un utente in base all'username e tutte le sue richieste di carica associate
    public void deleteUserByUsername(String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            chargeRequestRepository.deleteByUserId((long) userOptional.get().getId());
            userRepository.deleteByUsername(userOptional.get().getUsername());
        } else {
            throw new IllegalArgumentException("Utente non trovato");
        }
    }

    public User getUserById(long userId) {
        return userRepository.findUserById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Utente non trovato con ID: " + userId));
    }

    public Boolean EmailValidator(String email) {

        // Regex per un'email valida
        final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

        if (email == null || email.isEmpty()) {
            return false; // Email nulla o vuota non è valida
        }

        Pattern pattern = Pattern.compile(EMAIL_REGEX);
        Matcher matcher = pattern.matcher(email);
        return ((Matcher) matcher).matches(); // Restituisce true se l'email è valida

    }

    public void aggiornaAbbonamento(String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();

        // Controlla se l'utente è già PREMIUM
        if (user.getRuolo() == Ruolo.PREMIUM) {
            throw new IllegalArgumentException("L'utente è già PREMIUM");
        }

        // Controlla il saldo
        double saldoAttuale = user.getSaldo();
        if (saldoAttuale < 20) {
            throw new IllegalArgumentException("Saldo insufficiente per aggiornare il ruolo a PREMIUM");
        }

        // Aggiorna saldo e ruolo
        user.setSaldo(saldoAttuale - 20);
        user.setRuolo(Ruolo.PREMIUM);

        // Salva l'utente nel database
        userRepository.save(user);
    }

    public String registra() {
        int errore = 0;
        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();		String apiUrl = "https://localhost:8443/api/users/register";

        Map<String, Object> requestBody = new HashMap<>();
        String x = "";

        do {
            try {
                errore = 0;

                System.out.print("Inserisci un username: ");
                requestBody.put("username", s.nextLine().trim());

                System.out.print("Inserisci una password: ");
                requestBody.put("password", s.nextLine().trim());

                System.out.print("Inserisci un'email: ");
                requestBody.put("email", s.nextLine().trim());


                // Invio della richiesta POST
                x = restTemplate.postForObject(apiUrl, requestBody, String.class);

            } catch (Exception e) {
                System.out.println("Errore durante la registrazione: " + e.getMessage());
                errore = 1;
            }

        } while (errore == 1);

        return x;
    }

    public String login() {
        // Usa HttpsRestTemplateConfig per creare un RestTemplate personalizzato
        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

        String apiUrl = "https://localhost:8443/api/users/login"; // URL HTTPS corretto
        Map<String, Object> requestBody = new HashMap<>();

        // Richiedi all'utente di inserire le credenziali
        System.out.println("Inserisci la email: ");
        requestBody.put("email", s.next());

        System.out.println("Inserisci la password: ");
        requestBody.put("password", s.next());

        try {
            String jwt = restTemplate.postForObject(apiUrl, requestBody, String.class);
            if (jwt != null && jwt.contains(".")) { // Controlla che il token abbia almeno 2 punti
                this.token.setJwtToken(jwt);// Salva il token
                return "login effettuato con successo";
            } else {
                return "Errore: Token JWT non valido.";
            }
        } catch (Exception e) {
            return "Errore durante il login: " + e.getMessage();
        }

    }

    public void Cerca_User() {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
            return;
        }

        // Verifica del ruolo tramite il token
        String username;
        String ruolo;
        try {
            username = jwtUtil.validateToken(token.getJwtToken());
            if (username == null || username.isEmpty()) {
                System.out.println("Errore: Il token non contiene un username valido.");
                return;
            }

            Optional<User> userOpt = userRepository.findByUsername(username);
            if (!userOpt.isPresent()) {
                System.out.println("Errore: Utente non trovato.");
                return;
            }

            ruolo = userOpt.get().getRuolo().toString();
            if (!ruolo.equalsIgnoreCase("ADMIN")) {
                System.out.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
                return;
            }

            System.out.println("Utente autenticato con ruolo ADMIN: " + username);
        } catch (Exception e) {
            System.out.println("Errore durante la validazione del token: " + e.getMessage());
            return;
        }

        // Creazione del RestTemplate
        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

        // URL base dell'API
        String apiUrl = "https://localhost:8443/Admin/username";

        // Scanner per leggere l'input utente
        Scanner scanner = new Scanner(System.in);
        System.out.println("Inserisci Username: ");
        String usernameToSearch = scanner.nextLine(); // Legge l'input

        // Aggiunta del parametro di query all'URL
        String urlWithQueryParam = apiUrl + "?username=" + usernameToSearch;

        try {
            // Creazione delle intestazioni HTTP
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT all'intestazione

            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            // Esegue la richiesta GET con le intestazioni
            ResponseEntity<String> response = restTemplate.exchange(urlWithQueryParam, HttpMethod.GET, requestEntity, String.class);

            // Stampa la risposta
            System.out.println("Risultato API: " + response.getBody());
        } catch (HttpClientErrorException.NotFound e) {
            // Gestione specifica per 404
            System.out.println("Errore: L'utente con username '" + usernameToSearch + "' non esiste.");
        } catch (Exception e) {
            // Gestione generica degli errori
            System.out.println("Errore durante la chiamata all'API: " + e.getMessage());
        }
    }


}


