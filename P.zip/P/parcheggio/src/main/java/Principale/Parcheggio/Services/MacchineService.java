package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Security.JwtUtil;
import Principale.Parcheggio.Token.JwtTokenHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

@Service
public class MacchineService {

    @Autowired
    private MacchinaRepository macchineRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MacchineService macchineService;

    @Autowired
    private JwtUtil jwtUtil;

    private final JwtTokenHolder token;

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    public MacchineService(JwtTokenHolder token) {
        this.token = token;
    }

    // Creare una nuova macchina
    public Macchine createMacchina(String targa, double kwBatteria, String modello, int userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Macchine macchina = new Macchine(targa, kwBatteria, modello, user);
        return macchineRepository.save(macchina);
    }

    // Cancellare una macchina
    public void deleteMacchina(String targa) {
        targa = targa.toUpperCase();
        Macchine macchina = macchineRepository.findByTarga(targa);
        if (macchina != null) {
            macchineRepository.delete(macchina);
        } else {
            throw new RuntimeException("Macchina non trovata");
        }
    }

    // Modificare i parametri di una macchina
    public Macchine updateMacchina(String targa, double kwBatteria, String modello) {
        Macchine macchina = macchineRepository.findByTarga(targa);
        if (macchina != null) {
            macchina.setKwBatteria(kwBatteria);
            macchina.setModello(modello);
            return macchineRepository.save(macchina);
        } else {
            throw new RuntimeException("Macchina non trovata");
        }
    }

    // Restituire tutte le macchine per un determinato id utente
    public List<Macchine> getMacchineByUserId(int userId) {
        return macchineRepository.findByUserId(userId);
    }

    // Restituire i dettagli di una macchina tramite targa
    public Macchine getMacchinaByTarga(String targa) {
        targa = targa.toUpperCase();
        return macchineRepository.findByTarga(targa);
    }

    // Funzione per verificare la validità della targa italiana
    public static boolean isValidTargaItaliana(String targa) {
        // RegEx per formato attuale
        String formatoAttuale = "^[A-Z]{2}[0-9]{3}[A-Z]{2}$";

        // RegEx per formato storico
        String formatoStorico = "^[A-Z]{1,2}[0-9]{1,6}$";

        // Verifica che la targa rispetti almeno uno dei formati
        return targa.matches(formatoAttuale) || targa.matches(formatoStorico);
    }


    public void deleteMacchine(){
        System.out.println("eliminazione di tutte le macchine dal database");
        macchineRepository.deleteAll();
        System.out.println("tutte le macchine sono state eliminate");
    }

    public void createMacchina(String risp) {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
            return;
        }

        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
        Scanner scanner = new Scanner(System.in);

        String targa;

        do {
            System.out.print("Inserisci la targa (rispettando gli standard italiani): ");
            targa = scanner.nextLine().trim().toUpperCase();

            if (macchineService.isValidTargaItaliana(targa)) {
                System.out.println("Targa valida: " + targa);
                break;
            } else {
                System.out.println("Errore: La targa non rispetta gli standard italiani. Riprova.");
            }
        } while (true);

        double kwBatteria = 0;
        if(risp.equals("si")) {
            do {
                System.out.print("Inserisci i kW della batteria (se non elettrica mettere 0): ");
                kwBatteria = scanner.nextDouble();
                scanner.nextLine(); // Consuma la newline
                if(kwBatteria == 0) System.out.println("deve essere elettrica");
            }while(kwBatteria == 0);
        }

        if(risp.equals("no")) {
            System.out.print("Inserisci i kW della batteria (se non elettrica mettere 0): ");
            kwBatteria = scanner.nextDouble();
            scanner.nextLine(); // Consuma la newline
        }

        System.out.print("Inserisci il modello dell'auto: ");
        String modello = scanner.nextLine();

        // Estrai l'username dal token
        String username;
        try {
            username = jwtUtil.validateToken(token.getJwtToken());
            if (username == null || username.isEmpty()) {
                System.out.println("Errore: Il token non contiene un username valido.");
                return;
            }
            System.out.println("Utente autenticato: " + username);
        } catch (Exception e) {
            System.out.println("Errore durante la validazione del token: " + e.getMessage());
            return;
        }

        // Trova l'utente nel repository
        User user = userRepository.findByUsername(username).orElse(null);
        if (user == null) {
            System.out.println("Errore: Utente non trovato nel database per username: " + username);
            return;
        }

        System.out.println("Utente trovato: " + user.getUsername());

        int userId = user.getId();

        // Prepara i parametri della richiesta
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("targa", targa);
        params.add("kwBatteria", String.valueOf(kwBatteria));
        params.add("modello", modello);
        params.add("userId", String.valueOf(userId));

        // Prepara le intestazioni
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token.getJwtToken());
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED); // Usa form-urlencoded

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);


        String url = "https://localhost:8443/api/macchine/create";

        try {
            ResponseEntity<Macchine> response = restTemplate.postForEntity(url, request, Macchine.class);
            System.out.println("Macchina creata: " + response.getBody());
        } catch (Exception e) {
            System.err.println("Errore durante la creazione della macchina: " + e.getMessage());
        }
    }

    public void deleteMacchina() {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
            return;
        }

        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Inserisci la targa della macchina da cancellare: ");
        String targa = scanner.nextLine();

        // Costruzione dell'URL con parametro query
        String url = UriComponentsBuilder.fromHttpUrl("https://localhost:8443/Admin/macchine/delete")
                .queryParam("targa", targa)
                .toUriString();

        // Creazione delle intestazioni con il token JWT
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT

        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        try {
            // Esegui la richiesta DELETE con il token
            restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, Void.class);
            System.out.println("Macchina con targa " + targa + " cancellata.");
        } catch (Exception e) {
            System.err.println("Errore durante la cancellazione della macchina: " + e.getMessage());
        }
    }

    //ok
    public void getMacchineByUserId() {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
            return;
        }

        // Extract username from the token
        String username;
        try {
            username = jwtUtil.validateToken(token.getJwtToken());
            if (username == null || username.isEmpty()) {
                System.out.println("Errore: Il token non contiene un username valido.");
                return;
            }
            //System.out.println("Utente autenticato: " + username);
        } catch (Exception e) {
            System.out.println("Errore durante la validazione del token: " + e.getMessage());
            return;
        }

        // Use HTTPS RestTemplate configuration
        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

        // Base URL dell'API
        String baseUrl = "https://localhost:8443/api/macchine/byUser";

        // Costruzione dinamica dell'URL con query string
        String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
                .queryParam("username", username)
                .toUriString();

        try {
            // Creazione delle intestazioni con il token JWT
            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

            // Richiesta HTTP
            ResponseEntity<List<Macchine>> response = restTemplate.exchange(
                    url, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<Macchine>>() {
                    }
            );

            List<Macchine> macchine = response.getBody();
            if (macchine != null && !macchine.isEmpty()) {
                System.out.println("Macchine associate all'utente con ID " + username + ":");
                for (Macchine macchina : macchine) {
                    System.out.println(macchina);
                }
            } else {
                System.out.println("Nessuna macchina trovata per l'utente con ID " + username);
            }
        } catch (HttpClientErrorException.NotFound e) {
            System.out.println("Errore: Utente non trovato o nessuna macchina associata.");
        } catch (Exception e) {
            System.out.println("Errore durante la chiamata all'API: " + e.getMessage());
        }
    }

    //ok
    public void getMacchinaByTarga() {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
            return;
        }


        Optional<User> userOpt = userRepository.findByUsername(jwtUtil.validateToken(token.getJwtToken()));


        String ruolo = userOpt.get().getRuolo().toString();
        if (!ruolo.equalsIgnoreCase("ADMIN")) {
            System.out.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
            return;
        }

        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Inserisci la targa della macchina: ");
        String targa = scanner.nextLine();

        // Base URL dell'API
        String baseUrl = "https://localhost:8443/api/macchine/byTarga";

        // Costruzione dinamica dell'URL con query string
        String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
                .queryParam("targa", targa)
                .toUriString();

        // Creazione delle intestazioni con il token JWT
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT

        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        try {
            // Richiesta HTTP con token e gestione della risposta
            ResponseEntity<Macchine> response = restTemplate.exchange(
                    url, HttpMethod.GET, requestEntity, Macchine.class
            );

            if (response.getStatusCode().is2xxSuccessful()) {
                Macchine macchina = response.getBody();
                System.out.println("Dettagli della macchina con targa " + targa + ": " + macchina);
            } else {
                System.out.println("Macchina con targa " + targa + " non trovata.");
            }
        } catch (Exception e) {
            System.err.println("Errore durante il recupero dei dettagli della macchina: " + e.getMessage());
        }
    }

    public List<Macchine> cercaauto(Integer id, String r) {
        List<Macchine> auto = List.of();
        if (r.matches("si")) {
            auto = macchineRepository.findAllByUserIdElettriche(id);
        } else if (r.matches("")) {
            auto = macchineRepository.findByUserId(id);
        }

        return auto;
    }

}

