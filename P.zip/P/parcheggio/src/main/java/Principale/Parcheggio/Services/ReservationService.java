package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Security.JwtUtil;
import Principale.Parcheggio.Token.JwtTokenHolder;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

@Service
public class ReservationService {

    private static final Logger logger = LoggerFactory.getLogger(ReservationService.class);

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ChargeRequestService cService;

    @Autowired
    private MacchineService macchineService;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    Scanner s = new Scanner(System.in);

    @Autowired
    private JwtUtil jwtUtil;

    private final JwtTokenHolder token;

    String targaScelta;

    public ReservationService(JwtTokenHolder token) {
        this.token = token;
    }

    @Transactional
    public Reservation addReservation(long userId, long chargeRequestId, Payment payment, String Targa, Boolean Ricarica) {
        logger.info("Tentativo di aggiungere una prenotazione: User ID: {}, ChargeRequest ID: {}", userId, chargeRequestId);

        try {
            // Recupera l'utente in base all'ID
            User user = userRepository.findUserById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("Utente con ID " + userId + " non trovato"));
            logger.info("Utente recuperato: {}", user.getUsername());

            // Recupera la richiesta di carica in base all'ID
            ChargeRequest chargeRequest = chargeRequestRepository.findById(chargeRequestId)
                    .orElseThrow(() -> new IllegalArgumentException("Richiesta di carica con ID " + chargeRequestId + " non trovata"));
            logger.info("Richiesta di carica recuperata: {}", chargeRequest.getId());


            // Crea una nuova prenotazione
            Reservation reservation = new Reservation();
            reservation.setUser(user);
            reservation.setChargeRequest(chargeRequest);
            reservation.setTarga(Targa);
            reservation.setRicarica(Ricarica);

            // Associa il pagamento alla prenotazione
            if (payment == null) {
                throw new IllegalArgumentException("Il pagamento non può essere nullo.");
            }
            reservation.setPayment(payment);  // Associa l'oggetto Payment
            logger.info("Prenotazione creata con pagamento, tentativo di salvataggio nel database.");

            // Salva la prenotazione nel database
            Reservation savedReservation = reservationRepository.save(reservation);
            logger.info("Prenotazione salvata con successo, ID: {}", savedReservation.getId());

            return savedReservation;

        } catch (IllegalArgumentException e) {
            logger.error("Errore di validazione nei parametri: {}", e.getMessage());
            throw new RuntimeException("Errore nei parametri forniti: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Errore durante la creazione della prenotazione: {}", e.getMessage());
            throw new RuntimeException("Errore interno del server: " + e.getMessage());
        }
    }

    public String prenotaOra() throws ParseException {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
        }

        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
        String apiUrl = "https://localhost:8443/chargerequests/new";
        Map<String, Object> requestBody = new HashMap<>();

        // Estrazione dell'username dal token
        String username;
        try {
            username = jwtUtil.validateToken(token.getJwtToken());
            if (username == null || username.isEmpty()) {
                return "Errore: Il token non contiene un username valido.";
            }
            //System.out.println("Utente autenticato: " + username);
        } catch (Exception e) {
            return "Errore durante la validazione del token: " + e.getMessage();
        }

        String risposta = "";
        boolean success = false;
        do {
            try {
                success = false;
                System.out.println("Si vuole ricaricare la sua auto? (si o no):");
                risposta = s.next().toLowerCase();
                if (!risposta.equals("si") && !risposta.equals("no")) {
                    System.out.println("Errore nell'inserimento della risposta, riprovare!!!");
                } else if (risposta.equals("si")) {
                    System.out.println("Inserisci la percentuale iniziale: ");
                    int percentualeInizio = s.nextInt();
                    s.nextLine(); // Consuma il carattere newline

                    System.out.println("Inserisci la percentuale richiesta: ");
                    int percentualeRichiesta = s.nextInt();
                    s.nextLine(); // Consuma il carattere newline

                    // Cerca l'utente
                    Optional<User> user = userRepository.findByUsername(username);
                    if (!user.isPresent()) {
                        return "Utente non trovato.";
                    }

                    // Cerca le auto dell'utente
                    List<Macchine> auto = macchineService.cercaauto(user.get().getId(), "si");
                    if (auto.isEmpty()) {
                        System.out.println("Nessuna macchina associata all'utente.");
                        System.out.println("Aggiungere una macchina? (si o no): ");
                        String w = s.next().toLowerCase();
                        if (w.equals("si")) {
                            macchineService.createMacchina(risposta);
                            auto = macchineService.cercaauto(user.get().getId(), "si");
                        } else {
                            return "Non puoi prenotare senza avere un'auto nel tuo account.";
                        }
                    }

                    double kw = scegliAuto(auto);

                    String durataS = cService.calcola(percentualeInizio, percentualeRichiesta, kw);

                    SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
                    Time durata = new Time(timeFormatter.parse(durataS).getTime());
                    LocalDate data = LocalDate.now();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                    String dataStr = data.format(formatter);
                    Time orario = Time.valueOf(LocalTime.now());
                    LocalTime oraFine = orario.toLocalTime().plusHours(durata.toLocalTime().getHour())
                            .plusMinutes(durata.toLocalTime().getMinute())
                            .plusSeconds(durata.toLocalTime().getSecond());

                    if (cService.isReservationAvailableRicarica(data, orario, Time.valueOf(oraFine))) {
                        requestBody.put("giorno", dataStr);
                        requestBody.put("Percentuale_iniziale", percentualeInizio);
                        requestBody.put("Percentuale_richiesta", percentualeRichiesta);
                        requestBody.put("ora", orario.toString());
                        requestBody.put("durata", durata.toString());
                        requestBody.put("oraFine", oraFine.toString());
                        requestBody.put("username", username);
                        requestBody.put("Targa", targaScelta);
                        requestBody.put("Ricarica", true);

                        HttpHeaders headers = new HttpHeaders();
                        headers.set("Authorization", "Bearer " + token.getJwtToken());
                        headers.setContentType(MediaType.APPLICATION_JSON);

                        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

                        try {
                            return restTemplate.postForObject(apiUrl, requestEntity, String.class);
                        } catch (Exception e) {
                            return "Errore durante la prenotazione: " + e.getMessage();
                        }
                    } else {
                        Time x = cService.findEarliestEndTimeRicarica(data, orario, Time.valueOf(oraFine));
                        return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARÀ ALLE: " + x;
                    }
                } else if (risposta.equals("no")) {
                    // Logica per la sosta senza ricarica
                    List<Macchine> auto = macchineService.cercaauto(userRepository.findByUsername(username).get().getId(), "");
                    if (auto.isEmpty()) {
                        System.out.println("Nessuna macchina associata all'utente.");
                        System.out.println("Aggiungere una macchina? (si o no): ");
                        String w = s.next().toLowerCase();
                        if (w.equals("si")) {
                            macchineService.createMacchina(risposta);
                            auto = macchineService.cercaauto(userRepository.findByUsername(username).get().getId(), "");
                        } else {
                            return "Non puoi prenotare senza avere un'auto nel tuo account.";
                        }
                    }

                    double kw = scegliAuto(auto);
                    boolean valido = false;
                    Time durata = null;

                    do {
                        System.out.println("Per quanto tempo desidera sostare? (formato HH:mm:ss)");
                        String durataS = s.next();
                        s.nextLine();
                        SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
                        try {
                            durata = new Time(timeFormatter.parse(durataS).getTime());
                            valido = true;
                        } catch (Exception e) {
                            valido = false;
                            System.out.println("Errore nel formato inserito, riprovare.");
                        }
                    } while (!valido);

                    LocalDate data = LocalDate.now();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                    String dataStr = data.format(formatter);
                    Time orario = Time.valueOf(LocalTime.now());
                    LocalTime oraFine = orario.toLocalTime().plusHours(durata.toLocalTime().getHour())
                            .plusMinutes(durata.toLocalTime().getMinute())
                            .plusSeconds(durata.toLocalTime().getSecond());

                    if (cService.isReservationAvailable(data, orario, Time.valueOf(oraFine))) {
                        requestBody.put("giorno", dataStr);
                        requestBody.put("Percentuale_iniziale", null);
                        requestBody.put("Percentuale_richiesta", null);
                        requestBody.put("ora", orario.toString());
                        requestBody.put("durata", durata.toString());
                        requestBody.put("oraFine", oraFine.toString());
                        requestBody.put("username", username);
                        requestBody.put("Targa", targaScelta);
                        requestBody.put("Ricarica", null);

                        HttpHeaders headers = new HttpHeaders();
                        headers.set("Authorization", "Bearer " + token.getJwtToken());
                        headers.setContentType(MediaType.APPLICATION_JSON);

                        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

                        try {
                            return restTemplate.postForObject(apiUrl, requestEntity, String.class);
                        } catch (Exception e) {
                            return "Errore durante la prenotazione: " + e.getMessage();
                        }
                    } else {
                        Time x = cService.findEarliestEndTimeSosta(data, orario, Time.valueOf(oraFine));
                        return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARÀ ALLE: " + x;
                    }
                }
                success = true;
            }catch(Exception e){
                System.out.println("Errore durante la prenotazione: " + e.getMessage());
                success = false;
            }
        } while (!risposta.matches("si") && !risposta.matches("no") || success == false);

        return "Prenotazione completata.";
    }

    //ok
    public String PrenotaPremium() throws ParseException {
        if (token.getJwtToken() == null || token.getJwtToken().isEmpty()) {
            return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
        }

        // Utilizza RestTemplate configurato per HTTPS
        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
        String apiUrl = "https://localhost:8443/chargerequests/new";

        Scanner scanner = new Scanner(System.in);
        Map<String, Object> requestBody = new HashMap<>();

        // Validazione del token JWT
        String username;
        try {
            username = jwtUtil.validateToken(token.getJwtToken());
            if (username == null || username.isEmpty()) {
                return "Errore: Il token non contiene un username valido.";
            }
            System.out.println("Utente autenticato: " + username);
        } catch (Exception e) {
            return "Errore durante la validazione del token: " + e.getMessage();
        }

        String risposta;
        do {
            System.out.println("si vuole ricaricare la sua auto? (si o no):");
            risposta = s.next().toLowerCase();
            if (!risposta.equals("si") && !risposta.equals("no")) {
                System.out.println("errore nell'inserimento della rispsota, riprovare!!!");
                risposta = "";
            } else if (risposta.equals("si")) {
                System.out.println("Inserisci la percentuale iniziale: ");
                int percentuale_inizio = s.nextInt();
                s.nextLine(); // Consuma il carattere newline

                System.out.println("Inserisci la percentuale richiesta: ");
                int Percentage = s.nextInt();
                s.nextLine(); // Consuma il carattere newline

                //questo poi sarà preso dal token direttamente !!!!!!!!!!!!!!!!!
                //System.out.println("Inserisci l'username per la macchina richiesta: ");
                //String username = s.next();
                //s.nextLine(); // Consuma il carattere newline

                Optional<User> user = userRepository.findByUsername(username);
                if (!user.isPresent()) {
                    return "Utente non trovato.";
                }

                // Cerca le auto dell'utente
                List<Macchine> auto = macchineService.cercaauto(user.get().getId(), "si");
                if (auto.isEmpty()) {
                    System.out.println("Nessuna macchina associata all'utente.");
                    System.out.println("aggiungere una macchina?: (si o no) ");
                    String w = s.next().toLowerCase();
                    if (w.equals("si")) {
                        macchineService.createMacchina(risposta);
                        auto = macchineService.cercaauto(user.get().getId(), "si");
                    } else {
                        return "non puoi prenoare senza avere un'auto nel tuo account";
                    }
                }

                double kw = scegliAuto(auto);

                String durataS = cService.calcola(percentuale_inizio, Percentage, kw);
                SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
                Time durata = new Time(timeFormatter.parse(durataS).getTime());

                String dataStr;
                LocalDate data = null;
                String dataFormattata = "";
                Boolean valido;
                do {
                    System.out.println("Inserisci la data in questo formato (dd/MM/yyyy): ");
                    dataStr = scanner.nextLine();

                    DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

                    LocalDate data2 = null;
                    // Parsing della stringa in LocalDate
                    try {
                        data2 = LocalDate.parse(dataStr, inputFormatter);
                        // Conversione della data in formato LocalDate (yyyy/MM/dd)
                        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                        dataFormattata = data2.format(outputFormatter);
                        try {
                            data = LocalDate.parse(dataFormattata, outputFormatter);
                            valido = true;
                        } catch (Exception e) {
                            valido = false;
                            System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
                        }
                    } catch (Exception e) {
                        valido = false;
                        System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
                    }
                } while (!valido);


                Time orario = null;
                valido = false;
                do {
                    System.out.println("Inserisci l'orario di arrivo in questo formato (HH:mm:ss): ");
                    String orarioS = scanner.nextLine();
                    try {
                        orario = Time.valueOf(orarioS);
                        valido = true;
                    } catch (Exception e) {
                        valido = false;
                        System.out.println("Errore: il formato dell'orario è errato. Usa il formato HH:mm:ss.");
                    }
                } while (!valido);

                // Conversione a LocalTime per effettuare i calcoli
                LocalTime localOraInizio = orario.toLocalTime();
                LocalTime localDurata = durata.toLocalTime();

                // Calcola oraFine
                LocalTime orafine = localOraInizio.plusHours(localDurata.getHour())
                        .plusMinutes(localDurata.getMinute())
                        .plusSeconds(localDurata.getSecond());

                // Assicurati che sia nel formato "HH:mm:ss"
                DateTimeFormatter timeFormatter2 = DateTimeFormatter.ofPattern("HH:mm:ss");
                String oraFineStr = orafine.format(timeFormatter2);
                Time oraFine = new Time(timeFormatter.parse(oraFineStr).getTime());

                if (cService.isReservationAvailableRicarica(data, orario, oraFine)) {
                    requestBody.put("giorno", dataFormattata); // Già una stringa
                    requestBody.put("Percentuale_iniziale", percentuale_inizio); // Integer va bene
                    requestBody.put("Percentuale_richiesta", Percentage); // Integer va bene
                    requestBody.put("ora", orario.toString()); // Converte in String
                    requestBody.put("durata", durata.toString()); // Converte in String
                    requestBody.put("oraFine", oraFine.toString()); // Converte in String
                    requestBody.put("username", username); // Già una stringa
                    requestBody.put("Targa", targaScelta);
                    requestBody.put("Ricarica", true);

                    HttpHeaders headers = new HttpHeaders();
                    headers.set("Authorization", "Bearer " + token);
                    headers.setContentType(MediaType.APPLICATION_JSON);

                    HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

                    try {
                        // Invio della richiesta POST e restituzione della risposta
                        return restTemplate.postForObject(apiUrl, requestEntity, String.class);
                    } catch (Exception e) {
                        // Gestione degli errori del server
                        return "Errore durante il login: " + e.getMessage();
                    }
                }
                else {
                    Time x = cService.findEarliestEndTimeRicarica(data,orario, oraFine);
                    return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARà ALLE:" + x;
                }
            } else if (risposta.equals("no")) {
                //questo poi sarà preso dal token direttamente !!!!!!!!!!!!!!!!!
                //System.out.println("Inserisci l'username per la macchina richiesta: ");
                //String username = s.next();
                s.nextLine(); // Consuma il carattere newline

                Optional<User> user = userRepository.findByUsername(username);
                if (!user.isPresent()) {
                    return "Utente non trovato.";
                }

                // Cerca le auto dell'utente
                List<Macchine> auto = macchineService.cercaauto(user.get().getId(), "");
                if (auto.isEmpty()) {
                    System.out.println("Nessuna macchina associata all'utente.");
                    System.out.println("aggiungere una macchina?: (si o no) ");
                    String w = s.next().toLowerCase();
                    if (w.equals("si")) {
                        macchineService.createMacchina(risposta);
                        auto = macchineService.cercaauto(user.get().getId(), "");
                    } else {
                        return "non puoi prenoare senza avere un'auto nel tuo account";
                    }
                }

                double kw = scegliAuto(auto);

                Boolean valido = false;
                Time durata = null;
                do {
                    System.out.println("quanto vuole restare?:(formato HH:MM:SS) ");
                    String durataS = s.next();
                    s.nextLine();
                    SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
                    try {
                        durata = new Time(timeFormatter.parse(durataS).getTime());
                        valido = true;
                    } catch (Exception e) {
                        System.out.println("errore nel formato della durata riprovare");
                        valido = false;
                    }
                } while (valido == false);

                String dataStr;
                LocalDate data = null;
                String dataFormattata = "";
                valido = false;
                do {
                    System.out.println("Inserisci la data in questo formato (dd/MM/yyyy): ");
                    dataStr = scanner.nextLine();

                    DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

                    LocalDate data2 = null;
                    // Parsing della stringa in LocalDate
                    try {
                        data2 = LocalDate.parse(dataStr, inputFormatter);
                        // Conversione della data in formato LocalDate (yyyy/MM/dd)
                        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
                        dataFormattata = data2.format(outputFormatter);
                        try {
                            data = LocalDate.parse(dataFormattata, outputFormatter);
                            valido = true;
                        } catch (Exception e) {
                            valido = false;
                            System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
                        }
                    } catch (Exception e) {
                        valido = false;
                        System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
                    }
                } while (valido == false);


                Time orario = null;
                valido = false;
                SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
                do {
                    System.out.println("Inserisci l'orario di arrivo in questo formato (HH:mm:ss): ");
                    String orarioS = scanner.nextLine();
                    try {
                        orario = Time.valueOf(orarioS);
                        valido = true;
                    } catch (Exception e) {
                        valido = false;
                        System.out.println("Errore: il formato dell'orario è errato. Usa il formato HH:mm:ss.");
                    }
                } while (valido == false);

                // Conversione a LocalTime per effettuare i calcoli
                LocalTime localOraInizio = orario.toLocalTime();
                LocalTime localDurata = durata.toLocalTime();

                // Calcola oraFine
                LocalTime orafine = localOraInizio.plusHours(localDurata.getHour())
                        .plusMinutes(localDurata.getMinute())
                        .plusSeconds(localDurata.getSecond());

                // Assicurati che sia nel formato "HH:mm:ss"
                DateTimeFormatter timeFormatter2 = DateTimeFormatter.ofPattern("HH:mm:ss");
                String oraFineStr = orafine.format(timeFormatter2);
                Time oraFine = new Time(timeFormatter.parse(oraFineStr).getTime());

                if (cService.isReservationAvailable(data, orario, oraFine)) {
                    requestBody.put("giorno", dataFormattata); // Già una stringa
                    requestBody.put("Percentuale_iniziale", null); // Integer va bene
                    requestBody.put("Percentuale_richiesta", null); // Integer va bene
                    requestBody.put("ora", orario.toString()); // Converte in String
                    requestBody.put("durata", durata.toString()); // Converte in String
                    requestBody.put("oraFine", oraFine.toString()); // Converte in String
                    requestBody.put("username", username); // Già una stringa
                    requestBody.put("Targa", targaScelta);
                    requestBody.put("Ricarica", null);

                    HttpHeaders headers = new HttpHeaders();
                    headers.set("Authorization", "Bearer " + token);
                    headers.setContentType(MediaType.APPLICATION_JSON);

                    HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);


                    try {
                        // Invio della richiesta POST e restituzione della risposta
                        return restTemplate.postForObject(apiUrl,requestEntity, String.class);
                    } catch (Exception e) {
                        // Gestione degli errori del server
                        e.printStackTrace();
                        return "Errore durante il login: " + e.getMessage();
                    }
                }
                else {
                    Time x = cService.findEarliestEndTimeSosta(data,orario, oraFine);
                    return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARà ALLE:" + x;
                }
            }
        } while (!risposta.matches("si") && !risposta.matches("no"));

        return "prenotato";
    }


    // Cancella tutte le prenotazioni
    public void deleteAllReservations() {
        reservationRepository.deleteAll();
        reservationRepository.resetAutoIncrement();
    }


    // Cancella una prenotazione in base all'ID della richiesta di carica
    public boolean deleteReservationByChargeRequestId(long chargeRequestId) {
        Optional<Reservation> reservation = reservationRepository.findByChargeRequestId(chargeRequestId);
        if (reservation.isPresent()) {
            reservationRepository.delete(reservation.get());
            return true;
        }
        return false;
    }

    // Trova tutte le prenotazioni (utile per debugging o future funzioni)
    public List<Reservation> findAllReservations() {
        return reservationRepository.findAllByRicaricaTrue();
    }

    public Map<String, Integer> Occupazione() {
        List<Object[]> results = reservationRepository.Occupazione();

        // Inizializza i contatori
        int totaleRicariche = 0;
        int totaleSoste = 0;

        // Somma i totali da tutti i gruppi
        for (Object[] row : results) {
            totaleRicariche += ((Number) row[2]).intValue(); // Colonna ricariche
            totaleSoste += ((Number) row[3]).intValue();     // Colonna soste
        }

        // Restituisci i totali in una mappa
        Map<String, Integer> summary = new HashMap<>();
        summary.put("ricariche", totaleRicariche);
        summary.put("soste", totaleSoste);
        return summary;
    }

    private double scegliAuto(List<Macchine> auto) {
        if (auto == null || auto.isEmpty()) {
            throw new IllegalArgumentException("La lista delle auto è vuota o nulla.");
        }

        Scanner s = new Scanner(System.in);

        // Stampa le targhe disponibili
        System.out.println("Scegli tra le seguenti targhe:");
        for (Macchine macchina : auto) {
            System.out.println("- " + macchina.getTarga());
        }

        while (true) {
            // Leggi la targa inserita dall'utente
            System.out.print("Inserisci la targa: ");
            targaScelta = s.nextLine().trim().toUpperCase();

            // Cerca la macchina corrispondente
            for (Macchine macchina : auto) {
                if (macchina.getTarga().equalsIgnoreCase(targaScelta)) {
                    // Restituisci i kW della macchina trovata
                    return macchina.getKwBatteria();
                }
            }

            // Se la targa non è valida, chiedi di riprovare
            System.out.println("Targa non trovata. Riprova.");
        }
    }
}

