package Principale.Parcheggio.MQTT;

import org.springframework.stereotype.Component;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;


@Component  // 🔥 Rende questa classe un Bean gestito da Spring
public class MqttPublisher {
    private final MqttConfig mqttConfig;

    public MqttPublisher() {
        this.mqttConfig = new MqttConfig();  // Usa un clientId
    }

    public void publishMessage(String topic, String payload) {
        try {
            mqttConfig.getClient().publish(topic, new MqttMessage(payload.getBytes()));
            System.out.println("📤 Messaggio inviato: " + payload);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



