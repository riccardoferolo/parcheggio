package Principale.Parcheggio.BOT.Main;

import Principale.Parcheggio.BOT.MWBot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication(scanBasePackages = {"Principale.Parcheggio.BOT", "Principale.Parcheggio", "Principale.Parcheggio.BOT.Main"})
@ComponentScan(basePackages = "Principale.Parcheggio") // Assicura che il bot trovi i repository
@EnableJpaRepositories(basePackages = "Principale.Parcheggio.Repository")
@EnableAsync
public class MWBotApplication implements CommandLineRunner {

    @Autowired
    private MWBot bot;

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(MWBotApplication.class);
        app.setAdditionalProfiles("bot"); // 🔥 Attiva il profilo "bot"
        app.run(args);
    }

    @Override
    public void run(String... args) {
        System.out.println("✅ MWBot avviato correttamente!");
        bot.run();
    }
}
