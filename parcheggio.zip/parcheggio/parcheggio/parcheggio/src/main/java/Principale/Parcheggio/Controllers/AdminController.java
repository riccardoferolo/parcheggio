package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Controllers.ChargeRequestController;
import Principale.Parcheggio.DTO.ReservationDTO;
import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Services.ChargeRequestService;
import Principale.Parcheggio.Services.ReservationService;
import Principale.Parcheggio.Services.UserService;
import Principale.Parcheggio.Services.MacchineService;
import Principale.Parcheggio.Services.PaymentService;
import org.antlr.v4.runtime.tree.pattern.ParseTreePattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import Principale.Parcheggio.MQTT.MqttPublisher;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/Admin")
public class AdminController {

    @Autowired
    private ChargeRequestService chargeRequestService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private UserService userService;

    @Autowired
    private MacchineService macchineService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private MqttPublisher mqttPublisher;



    // Endpoint per ottenere tutte le prenotazioni, API NUOVA QUESTA CHE USIAMO NEL C#
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/reservations")
    public ResponseEntity<List<Reservation>> getAllReservations(@RequestHeader(value = "Authorization", required = false) String token) {
       // System.out.println("Token ricevuto dal client: " + token);

        if (token == null || !token.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
        }

        token = token.substring(7); // Rimuove "Bearer "
        //System.out.println("Token dopo pulizia: " + token);

        List<Reservation> reservations = reservationRepository.findAll();

        return ResponseEntity.ok(reservations);
    }


    // Cancella ChargeRequest per ID
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/Aggiorna-Costo-Sosta")
    public void AggiornaSosta(@RequestBody Double Sosta) {
        chargeRequestService.ModificaParametroSosta(Sosta);
        System.out.println("il costo della sosta è stato modificato con:" + Sosta);
        mqttPublisher.publishMessage("charges/sosta", "Costo della sosta aggiornato a: " + Sosta);
    }

    // Cancella ChargeRequest per ID
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/Aggiorna-Costo-ricarica")
    public void AggiornaRicarica(@RequestBody Double ricarica) {
        chargeRequestService.ModificaParametroRicarica(ricarica);
        System.out.println("il costo della ricarica è stato modificato con:" + ricarica);
        mqttPublisher.publishMessage("charges/ricarica", "Costo della ricarica aggiornato a: " + ricarica);
    }

    // Trova un utente per username
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/username")
    public ResponseEntity<User> getUserByUsername(@RequestParam String username) {
        Optional<User> user = userService.findUserByUsername(username);
        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Endpoint per eliminare tutti gli utenti
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("user/delete-all")
    public ResponseEntity<String> eliminaTuttiGliUtenti() {
        try {
            userService.eliminaTuttiGliUtenti();
            mqttPublisher.publishMessage("users/delete", "Tutti gli utenti sono stati eliminati");
            return ResponseEntity.ok("Tutti gli utenti sono stati eliminati");
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/user", "Errore durante l'eliminazione degli utenti: " + e.getMessage());
            return ResponseEntity.status(500).body("Errore durante l'eliminazione degli utenti: " + e.getMessage());
        }
    }

    // Endpoint per cancellare un utente in base all'username
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("user/delete")
    public ResponseEntity<String> deleteUserByUsername(@RequestBody String username) {
        try {
            userService.deleteUserByUsername(username);
            mqttPublisher.publishMessage("users/delete", "Utente eliminato con successo: " + username);
            return ResponseEntity.ok("Utente con username " + username + " cancellato con successo.");
        } catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/user", "Utente non trovato: " + username);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/user", "Errore durante la cancellazione dell'utente: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore durante la cancellazione: " + e.getMessage());
        }
    }


    // Cancellare una macchina
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("macchine/deleteALL")
    public ResponseEntity<Void> deleteMacchine() {
        macchineService.deleteMacchine();
        mqttPublisher.publishMessage("macchine/delete", "Tutte le macchine sono state eliminate");
        return ResponseEntity.noContent().build();
    }

    // Endpoint per eliminare tutti gli utenti
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("payment/delete-all")
    public ResponseEntity<String> eliminaTuttiPagamenti() {
        try {
            paymentService.eliminaTuttiPagamenti();
            mqttPublisher.publishMessage("payments/delete", "Tutti i pagamenti sono stati eliminati");
            return ResponseEntity.ok("tutti i pagamenti sono stati eliminati");
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/payment", "Errore durante l'eliminazione dei pagamenti: " + e.getMessage());
            return ResponseEntity.status(500).body("Errore durante l'eliminazione dei pagamenti: " + e.getMessage());
        }
    }

    // Cancella ChargeRequest per ID
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("charge/delete-per-id")
    public ResponseEntity<String> deleteChargeRequest(@RequestBody Long id) {
        chargeRequestService.deleteChargeRequest(id);
        mqttPublisher.publishMessage("charges/delete", "La richiesta con ID: " + id + " è stata eliminata");
        return ResponseEntity.ok("la richiesta con id:" + id + " è stata eliminata");
    }

    // Endpoint per eliminare tutte le richieste
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("charge/delete-all")
    public ResponseEntity<String> eliminaTutteleRichieste() {
        try {
            chargeRequestService.eliminaTuttelerichieste();
            mqttPublisher.publishMessage("charges/delete", "Tutte le richieste sono state eliminate");
            return ResponseEntity.ok("Tutte le richieste sono state eliminate");
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/charge", "Errore durante l'eliminazione delle richieste: " + e.getMessage());
            return ResponseEntity.status(500).body("Errore durante l'eliminazione delle richieste: " + e.getMessage());
        }
    }

    // Endpoint per cancellare tutte le richieste associate a un ID utente
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("charge/delete/user/id")
    public ResponseEntity<String> deleteRequestsByUserId(@RequestBody Long userId) {
        try {
            chargeRequestService.deleteRequestsByUserId(userId);
            mqttPublisher.publishMessage("charges/delete", "Tutte le richieste per l'utente con ID " + userId + " sono state eliminate");
            return ResponseEntity.ok("Tutte le richieste per l'utente con ID " + userId + " sono state cancellate.");
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/charge", "Errore durante la cancellazione delle richieste per l'utente con ID " + userId + ": " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore durante la cancellazione delle richieste: " + e.getMessage());
        }
    }



    // Cancella tutte le prenotazioni
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("reservation/delete-all")
    public ResponseEntity<String> deleteAllReservations() {
        reservationService.deleteAllReservations();
        mqttPublisher.publishMessage("reservations/delete", "Tutte le prenotazioni sono state cancellate");
        return ResponseEntity.ok("Tutte le prenotazioni sono state cancellate.");
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("delayedreservation/delete-all")
    public ResponseEntity<String> deleteAllDelayedReservations() {
        reservationService.deleteAllDelayedReservations();
        mqttPublisher.publishMessage("reservations/delete", "Tutte le prenotazioni ritardate sono state cancellate");
        return ResponseEntity.ok("Tutte le prenotazioni sono state cancellate.");
    }

    // Cancella una prenotazione per ID della richiesta di carica
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("reservation/delete/charge-request/chargeid")
    public ResponseEntity<String> deleteReservationByChargeRequestId(@RequestBody long chargeRequestId) {
        boolean deleted = reservationService.deleteReservationByChargeRequestId(chargeRequestId);
        if (deleted) {
            mqttPublisher.publishMessage("reservations/delete", "Prenotazione con ID richiesta di carica " + chargeRequestId + " cancellata con successo");
            return ResponseEntity.ok("Prenotazione cancellata con successo.");
        } else {
            mqttPublisher.publishMessage("errors/reservation", "Prenotazione con ID richiesta di carica " + chargeRequestId + " non trovata");
            return ResponseEntity.status(404).body("Prenotazione con ID della richiesta di carica non trovata.");
        }
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/Setritardo")
    public void setRitardo(@RequestBody Reservation reservation) {
        reservationService.SetRitardo(reservation);
        mqttPublisher.publishMessage("reservations/update", "Ritardo impostato per la prenotazione con ID: " + reservation.getId());
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/SpostaSoste")
    public void SpostaSoste() {
        reservationService.CancellaSosteVecchie();
        mqttPublisher.publishMessage("reservations/delete", "Le soste vecchie sono state cancellate");

    }

}
