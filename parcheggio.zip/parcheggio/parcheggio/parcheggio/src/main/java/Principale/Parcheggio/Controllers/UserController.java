package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.JwtUtil;
import Principale.Parcheggio.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.MQTT.MqttPublisher;

import java.util.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;
    private final MqttPublisher mqttPublisher;
    Scanner s = new Scanner(System.in);

    @Autowired
    public UserController(UserService userService, UserRepository userRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.jwtUtil = new JwtUtil();
        this.mqttPublisher = new MqttPublisher();
    }

    // Endpoint per la registrazione di un nuovo utente
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody Map<String, Object> requestBody) {
        System.out.println("🔹 Ricevuta richiesta di registrazione: " + requestBody);
        try {
            User user = new User();
            user.setUsername((String) requestBody.get("username"));
            user.setPassword((String) requestBody.get("password"));
            user.setEmail((String) requestBody.get("email"));
            userService.registerUser(user);
            mqttPublisher.publishMessage("users/register", "Utente registrato con successo: " + user.getUsername());
            return ResponseEntity.ok("Utente registrato con successo");
        }catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/general", "Errore registrazione utente: " + e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/register-admin")
    public ResponseEntity<String> registerAdmin(@RequestBody User user) {
        try {
            userService.registerAdmin(user);
            mqttPublisher.publishMessage("users/register", "Admin registrato con successo " + user.getUsername());
            return ResponseEntity.ok("Utente registrato con successo");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody Map<String, String> loginData) {
        String email = loginData.get("email");
        String password = loginData.get("password");

        try {
            User user = userService.loginUser(email, password);
            String token = jwtUtil.generateToken(user.getUsername(), user.getRuolo().toString());
            mqttPublisher.publishMessage("users/login", "Login effettuato per l'utente: " + user.getUsername());
            return ResponseEntity.ok(token);
        } catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/general", "Errore di login per email: " + email + " - " + e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }



    // Endpoint per aggiornare il saldo di un utente
    @PutMapping("/aggiorna-saldo")
    public ResponseEntity<String> aggiornaSaldo(@RequestBody Map<String, String> requestBody) {
        double nuovoSaldo = Double.parseDouble(requestBody.get("saldo"));
        String username = requestBody.get("username");
        try {
            userService.aggiornaSaldo(username, nuovoSaldo);
            mqttPublisher.publishMessage("users/saldo", "Saldo aggiornato per l'utente: " + username + " a " + nuovoSaldo);
            return ResponseEntity.ok("Saldo aggiornato con successo");
        } catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/general", "Errore aggiornamento saldo per " + username + ": " + e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/general", "Errore interno durante l'aggiornamento saldo per " + username);
            return ResponseEntity.status(500).body("Errore del server interno");
        }
    }

    // Endpoint per aggiornare il saldo di un utente
    @PutMapping("/aggiorna-carta")
    public ResponseEntity<String> aggiornaCarta(@RequestBody Map<String, String> requestBody) {
        String username = requestBody.get("username");
        String carta = requestBody.get("carta");
        try {
            userService.aggiornaCarta(username, carta);
            mqttPublisher.publishMessage("users/carta", "Carta aggiornata per l'utente: " + username);
            return ResponseEntity.ok("carta salvata con successo");
        } catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/general", "Errore aggiornamento carta per " + username + ": " + e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/general", "Errore interno durante l'aggiornamento carta per " + username);
            return ResponseEntity.status(500).body("Errore del server interno");
        }
    }


    @GetMapping("/username-to-id")
    public ResponseEntity<Integer> getUserId(@RequestParam String username) {
        Optional<User>  user = userService.findUserByUsername(username);
        Integer userId = user.get().getId();
            if (userId != null) {
                return ResponseEntity.ok(userId);
            }
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }



    @PutMapping("/abbonamento")
    public ResponseEntity<String> aggiornaAbbonamento(@RequestBody Map<String, String> requestBody) {
        String username = requestBody.get("username");

        try {
            userService.aggiornaAbbonamento(username);
            mqttPublisher.publishMessage("users/abbonamento", "Abbonamento aggiornato a PREMIUM per l'utente: " + username);
            return ResponseEntity.ok("Ruolo aggiornato a PREMIUM con successo");
        } catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/general", "Errore aggiornamento abbonamento per " + username + ": " + e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/general", "Errore interno durante l'aggiornamento abbonamento per " + username);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore del server interno");
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    @PostMapping("/saldo")
    public ResponseEntity<?> getSaldo(@RequestBody Map<String, String> request) {
        System.out.println("Username ricevuto: " + request.get("username"));

        String username = request.get("username");

        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Errore: Utente non trovato.");
        }

        User user = userOptional.get();
        return ResponseEntity.ok(user.getSaldo());
    }

    @PostMapping("/carta")
    public ResponseEntity<?> getCarta(@RequestBody Map<String, String> request) {
        System.out.println("Username ricevuto: " + request.get("username"));

        String username = request.get("username");

        // Controlla se l'utente esiste
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Errore: Utente non trovato.");
        }

        // Controlla se l'utente ha una carta registrata
        User user = userOptional.get();
        boolean cartaPresente = user.getCarta_di_credito() != null && !user.getCarta_di_credito().trim().isEmpty();

        return ResponseEntity.ok(cartaPresente);
    }








    }



