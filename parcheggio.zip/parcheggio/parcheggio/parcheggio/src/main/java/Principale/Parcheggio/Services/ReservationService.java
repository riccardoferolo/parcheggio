package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.*;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Security.JwtUtil;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import static Principale.Parcheggio.ParcheggioApplication.isValidCreditCard;

@Service
public class ReservationService {

    private static final Logger logger = LoggerFactory.getLogger(ReservationService.class);

    @Autowired
    private ReservationRepository reservationRepository;

    Scanner s = new Scanner(System.in);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private DelayedReservationRepository delayedReservationRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private StoricoService storicoService;

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    @Autowired
    private JwtUtil jwtUtil;

    private String token; // Variabile globale per il token JWT


    @Transactional
    public Reservation addReservation(long userId, long chargeRequestId, Payment payment, String Targa, Boolean Ricarica) {
        logger.info("Tentativo di aggiungere una prenotazione: User ID: {}, ChargeRequest ID: {}", userId, chargeRequestId);

        try {
            // Recupera l'utente in base all'ID
            User user = userRepository.findUserById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("Utente con ID " + userId + " non trovato"));
            logger.info("Utente recuperato: {}", user.getUsername());

            // Recupera la richiesta di carica in base all'ID
            ChargeRequest chargeRequest = chargeRequestRepository.findById(chargeRequestId)
                    .orElseThrow(() -> new IllegalArgumentException("Richiesta di carica con ID " + chargeRequestId + " non trovata"));
            logger.info("Richiesta di carica recuperata: {}", chargeRequest.getId());


            // Crea una nuova prenotazione
            Reservation reservation = new Reservation();
            reservation.setUser(user);
            reservation.setChargeRequest(chargeRequest);
            reservation.setTarga(Targa);
            reservation.setRicarica(Ricarica);

            // Associa il pagamento alla prenotazione
            if (payment == null) {
                throw new IllegalArgumentException("Il pagamento non può essere nullo.");
            }
            reservation.setPayment(payment);  // Associa l'oggetto Payment
            logger.info("Prenotazione creata con pagamento, tentativo di salvataggio nel database.");

            // Salva la prenotazione nel database
            Reservation savedReservation = reservationRepository.save(reservation);
            logger.info("Prenotazione salvata con successo, ID: {}", savedReservation.getId());

            return savedReservation;

        } catch (IllegalArgumentException e) {
            logger.error("Errore di validazione nei parametri: {}", e.getMessage());
            throw new RuntimeException("Errore nei parametri forniti: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Errore durante la creazione della prenotazione: {}", e.getMessage());
            throw new RuntimeException("Errore interno del server: " + e.getMessage());
        }
    }


    // Cancella tutte le prenotazioni
    public void deleteAllReservations() {
        reservationRepository.deleteAll();
        reservationRepository.resetAutoIncrement();
    }

    public void deleteAllDelayedReservations(){
        delayedReservationRepository.deleteAll();
    }


    // Cancella una prenotazione in base all'ID della richiesta di carica
    public boolean deleteReservationByChargeRequestId(long chargeRequestId) {
        Optional<Reservation> reservation = reservationRepository.findByChargeRequestId(chargeRequestId);
        if (reservation.isPresent()) {
            reservationRepository.delete(reservation.get());
            return true;
        }
        return false;
    }

    // Trova tutte le prenotazioni (utile per debugging o future funzioni)
    public List<Reservation> findAllReservations() {
        return reservationRepository.findAllByRicaricaTrue();
    }

    public Map<String, Integer> Occupazione() {
        List<Object[]> results = reservationRepository.Occupazione();

        // Inizializza i contatori
        int totaleRicariche = 0;
        int totaleSoste = 0;

        // Somma i totali da tutti i gruppi
        for (Object[] row : results) {
            totaleRicariche += ((Number) row[2]).intValue(); // Colonna ricariche
            totaleSoste += ((Number) row[3]).intValue();     // Colonna soste
        }

        // Restituisci i totali in una mappa
        Map<String, Integer> summary = new HashMap<>();
        summary.put("ricariche", totaleRicariche);
        summary.put("soste", totaleSoste);
        return summary;
    }

    public void SetRitardo(Reservation reservation) {
        Optional<Reservation> r = reservationRepository.findById(reservation.getId());
        if (r.isPresent()) {
            r.get().setRitardo(true);
            reservationRepository.save(r.get());

            DelayedReservation DR = new DelayedReservation(r.get());
            // Sposta la prenotazione nella tabella DelayedReservation
            delayedReservationRepository.save(DR);
        } else {
            System.out.println("reservation non trovato");
        }
    }


    public void completeReservation(Reservation reservation) {
        Long reservationId = reservation.getId();

        try {
            storicoService.completeReservation(reservationId);
            System.out.println("Uscita completata e spostata nello storico con successo!");
        } catch (IllegalArgumentException e) {
            System.out.println("Errore: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Errore durante il completamento della prenotazione: " + e.getMessage());
        }
    }

    @Transactional
    public String esciPrimaDalParcheggio(Long id) {
        Optional<Reservation> r = reservationRepository.findById(id);

        // Impostiamo che la prenotazione è terminata (logica da definire, es. eliminazione o flag)
        completeReservation(r.get());

        return "✅ Uscita anticipata registrata con successo per la targa: " + r.get().getTarga() + "e per l'utente " + r.get().getUser().getUsername();
    }

    public void RitardoTrue(Reservation reservation) {
        DelayedReservation d = new DelayedReservation(reservation);
        delayedReservationRepository.save(d);
        storicoService.completeReservation(reservation.getId());
    }

    public void RitardoFalse(Reservation reservation) {
        storicoService.completeReservation(reservation.getId());
    }

    public void CancellaSosteVecchie() {
        List<Reservation> reservations = reservationRepository.findExpiredReservations();
        for (Reservation r : reservations) {
            // Qui puoi aggiungere la tua logica per elaborare le prenotazioni
            System.out.println("📢 DEBUG: Prenotazione trovata: " + r.getId());
            if(r.getRitardo().equals(Boolean.TRUE)){
                DelayedReservation d = new DelayedReservation(r);
                delayedReservationRepository.save(d);
                storicoService.completeReservation(r.getId());
            }
            else{
                storicoService.completeReservation(r.getId());
            }
        }
    }

    //------------------------------------------------------------------------------------------------------------------------
    public void PagareRitardo(DelayedReservation delayedReservation) {
        double costoRitardo = 20.0;
        // String conferma;

        /*
       do {
            System.out.println("Il costo del ritardo per la prenotazione ID " + delayedReservation.getId() + " è di: " + costoRitardo + "€.");
            System.out.print("Confermi il pagamento? (si/no): ");
            conferma = s.nextLine().toLowerCase();

            if (conferma.equals("no")) {
                System.out.println("Pagamento annullato.");
                return;
            }

            if (!conferma.matches("si") && !conferma.matches("no")) {
                System.out.println("Errore: la risposta inserita non è valida, riprovare.");
                continue;
            }
            */
        //if (conferma.equals("si")) {
        String u = delayedReservation.getUsername();
        Optional<User> user = userRepository.findByUsername(u);
        // 🔹 Rimuove la prenotazione dalla tabella DelayedReservation
        user.get().setSaldo(user.get().getSaldo()-costoRitardo);
        userRepository.save(user.get());

        delayedReservationRepository.delete(delayedReservation);
        System.out.println("Pagamento effettuato con successo! Prenotazione ID " + delayedReservation.getId() + " rimossa.");
        //  }
        // }while(!conferma.matches("si") && !conferma.matches("no"));
    }

    public void aggiornaLampadine(int postiTotSosta, int postiTotRicarica, Long postiSostaOccupati, Long postiRicaricaOccupati) {
        String UsernameHUE = registraUtenteHUE();
        String hueBridgeUrl = "http://localhost:8000/api/" + UsernameHUE + "/lights";
        RestTemplate restTemplate = new RestTemplate();

        // Lampadina 1 -> Sosta, Lampadina 2 -> Ricarica
        aggiornaStatoLampadina(restTemplate, hueBridgeUrl, 1, postiSostaOccupati < postiTotSosta); // Verde se ci sono posti liberi
        aggiornaStatoLampadina(restTemplate, hueBridgeUrl, 2, postiRicaricaOccupati < postiTotRicarica); // Verde se ci sono posti liberi
    }

    private void aggiornaStatoLampadina(RestTemplate restTemplate, String hueBridgeUrl, int lampId, boolean disponibile) {
        String lampUrl = hueBridgeUrl + "/" + lampId + "/state";

        // Prepara il corpo della richiesta
        Map<String, Object> lampState = new HashMap<>();
        lampState.put("on", true); // La lampadina è sempre accesa
        lampState.put("bri", 254); // Luminosità massima
        lampState.put("hue", disponibile ? 25500 : 0); // Verde se disponibile, rosso altrimenti

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(lampState, headers);

            restTemplate.put(lampUrl, request);
            System.out.println("Lampadina " + lampId + " aggiornata: " + (disponibile ? "Verde" : "Rossa"));
        } catch (Exception e) {
            System.err.println("Errore durante l'aggiornamento della lampadina " + lampId + ": " + e.getMessage());
        }
    }

    public void OccupazioneLampadine(Optional<ParkingSpot> optionalParkingSpot, List<Reservation> reservations) {
        if (!optionalParkingSpot.isPresent()) {
            System.out.println("Nessun record di parcheggio trovato.");
            return;
        }
        ParkingSpot parkingSpot = optionalParkingSpot.get();
        int postiTotRicarica = parkingSpot.getPosti_totali_ricarica();
        int postiTotSosta = parkingSpot.getPosti_totali_sosta();

        long postiRicaricaOccupati = reservations.stream()
                .filter(reservation -> Boolean.TRUE.equals(reservation.getRicarica()))
                .count();

        long postiSostaOccupati = reservations.stream()
                .filter(reservation -> reservation.getRicarica() == null)
                .count();

        aggiornaLampadine(postiTotSosta, postiTotRicarica, postiSostaOccupati, postiRicaricaOccupati);
    }

    private String registraUtenteHUE() {
        String hueBridgeUrl = "http://localhost:8000/api";
        RestTemplate restTemplate = new RestTemplate();

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("devicetype", "my_hue_app");

        try {
            ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
                    hueBridgeUrl,
                    HttpMethod.POST,
                    new HttpEntity<>(requestBody),
                    new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
                    }
            );

            // Estrai il nome utente dalla risposta
            List<Map<String, Map<String, String>>> body = response.getBody();
            if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
                String username = body.get(0).get("success").get("username");
                System.out.println("Utente registrato con successo: " + username);
                return username;
            } else {
                System.err.println("Errore durante la registrazione dell'utente. Risposta API: " + body);
            }
        } catch (Exception e) {
            System.err.println("Errore durante la registrazione dell'utente: " + e.getMessage());
        }
        return null;
    }

    public List<Reservation> findAllByUsername(String username) {
        return reservationRepository.findByUserUsername(username);
    }

}

