package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Models.ParkingSpot;
import Principale.Parcheggio.ParcheggioApplication;
import Principale.Parcheggio.Repository.ParkingSpotRepository;
import Principale.Parcheggio.Services.ReservationService;
import Principale.Parcheggio.MQTT.MqttPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.Models.Reservation;

import java.util.Map;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private MqttPublisher mqttPublisher;

    @GetMapping("/all")
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();
        mqttPublisher.publishMessage("reservations/fetch", "Tutte le prenotazioni sono state recuperate");
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/occupazione")
    public ResponseEntity<String> getActiveReservationsSummary() {
        Map<String, Integer> summary = reservationService.Occupazione();
        String message = String.format(
                "In questo momento nel parcheggio abbiamo:\n- in ricarica ci sono %d macchine\n- in sosta ci sono %d macchine",
                summary.get("ricariche"),
                summary.get("soste")
        );
        mqttPublisher.publishMessage("reservations/summary", "Occupazione aggiornata: " + message);
        return ResponseEntity.ok(message);
    }

    @PostMapping("/uscita-anticipata")
    public ResponseEntity<String> esciPrimaDalParcheggio(@RequestBody Long id) {
        String response = reservationService.esciPrimaDalParcheggio(id);
        mqttPublisher.publishMessage("reservations/update", response);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/GestioneReservation")
    public void gestioneReservation(@RequestBody Reservation r) {
        reservationService.completeReservation(r);
        mqttPublisher.publishMessage("reservations/manage", "Gestione completata per la prenotazione con ID: " + r.getId());
    }

    @GetMapping("/coda")
    public ResponseEntity<?> getProvaReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();

        reservations.sort(Comparator
                .comparing((Reservation r) -> r.getChargeRequest().getGiorno())
                .thenComparing(r -> r.getChargeRequest().getOra()));

        if (reservations.isEmpty()) {
            mqttPublisher.publishMessage("reservations/queue", "Nessuna prenotazione trovata nella coda.");
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Nessuna prenotazione trovata.");
        }

        mqttPublisher.publishMessage("reservations/queue", "Prossima prenotazione trovata con ID: " + reservations.get(0).getId());
        return ResponseEntity.ok(reservations.get(0));
    }

    @PostMapping("/RitardoTrue")
    public void RitardoTrue(@RequestBody Reservation r) {
        reservationService.RitardoTrue(r);
        mqttPublisher.publishMessage("reservations/delay", "Ritardo impostato per la prenotazione con ID: " + r.getId());
    }

    @PostMapping("/RitardoFalse")
    public void RitardoFalse(@RequestBody Reservation r) {
        reservationService.RitardoFalse(r);
        mqttPublisher.publishMessage("reservations/delay", "Ritardo rimosso per la prenotazione con ID: " + r.getId());
    }

    @PostMapping("/PagaRitardo")
    public void PagaRitardo(@RequestBody Map<String, DelayedReservation> requestBody) {
        if (requestBody.get("Prenotazione") == null) {
            mqttPublisher.publishMessage("errors/reservations", "Errore: Nessuna prenotazione ricevuta per il pagamento del ritardo.");
            System.out.println(ResponseEntity.badRequest().body("Errore: Nessuna prenotazione ricevuta."));
            return;
        }

        reservationService.PagareRitardo(requestBody.get("Prenotazione"));
        mqttPublisher.publishMessage("reservations/delay", "Pagamento ritardo effettuato per la prenotazione.");
    }

    @PostMapping("/lampadine")
    public void lampadine() {
        List<Reservation> reservations = reservationService.findAllReservations();
        Optional<ParkingSpot> optionalParkingSpot = parkingSpotRepository.findById(1);
        reservationService.OccupazioneLampadine(optionalParkingSpot, reservations);
        mqttPublisher.publishMessage("reservations/lights", "Aggiornamento stato lampadine in base alle prenotazioni.");
    }
}
