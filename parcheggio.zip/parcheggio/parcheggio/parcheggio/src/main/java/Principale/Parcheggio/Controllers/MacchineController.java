package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Services.MacchineService;
import Principale.Parcheggio.MQTT.MqttPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/macchine")
public class MacchineController {

    @Autowired
    private MacchineService macchineService;

    @Autowired
    private MacchinaRepository macchinaRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MqttPublisher mqttPublisher;

    // Creare una nuova macchina
    @PostMapping("/create")
    public ResponseEntity<Macchine> createMacchina(@RequestParam String targa, @RequestParam double kwBatteria, @RequestParam String modello, @RequestParam String username) {
        try {
            Macchine macchina = macchineService.createMacchina(targa, kwBatteria, modello, username);
            mqttPublisher.publishMessage("macchine/create", "Macchina creata con targa: " + targa);
            return new ResponseEntity<>(macchina, HttpStatus.CREATED);
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/macchine", "Errore durante la creazione della macchina: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Modificare i parametri di una macchina
    @PutMapping("/update")
    public ResponseEntity<Macchine> updateMacchina(@RequestParam String targa, @RequestParam double kwBatteria, @RequestParam String modello) {
        try {
            Macchine macchina = macchineService.updateMacchina(targa, kwBatteria, modello);
            mqttPublisher.publishMessage("macchine/update", "Macchina aggiornata con targa: " + targa);
            return ResponseEntity.ok(macchina);
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/macchine", "Errore durante l'aggiornamento della macchina: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Restituire tutte le macchine per un determinato id utente
    @GetMapping("/byUser")
    public ResponseEntity<List<Macchine>> getMacchineByUser(@RequestParam String username) {
        List<Macchine> macchine = macchineService.getMacchineByUser(username);

        if (macchine.isEmpty()) {
            mqttPublisher.publishMessage("macchine/fetch", "Nessuna macchina trovata per l'utente: " + username);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }

        mqttPublisher.publishMessage("macchine/fetch", "Macchine recuperate per l'utente: " + username);
        return ResponseEntity.ok(macchine);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<Void> deleteMacchina(@RequestParam String targa) {
        try {
            macchineService.deleteMacchina(targa);
            mqttPublisher.publishMessage("macchine/delete", "Macchina eliminata con targa: " + targa);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/macchine", "Errore durante l'eliminazione della macchina: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Restituire i dettagli di una macchina tramite targa
    @GetMapping("/byTarga")
    public ResponseEntity<Macchine> getMacchinaByTarga(@RequestParam String targa) {
        try {
            Macchine macchina = macchineService.getMacchinaByTarga(targa);
            if (macchina != null) {
                mqttPublisher.publishMessage("macchine/fetch", "Macchina trovata con targa: " + targa);
                return ResponseEntity.ok(macchina);
            }
            mqttPublisher.publishMessage("macchine/fetch", "Macchina non trovata con targa: " + targa);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/macchine", "Errore durante il recupero della macchina: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/ById")
    public ResponseEntity<List<Macchine>> getMacchineById(@RequestParam Integer id) {
        List<Macchine> macchine = macchineService.getMacchineById(id);

        if (macchine.isEmpty()) {
            mqttPublisher.publishMessage("macchine/fetch", "Nessuna macchina trovata per l'ID utente: " + id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }

        mqttPublisher.publishMessage("macchine/fetch", "Macchine recuperate per l'ID utente: " + id);
        return ResponseEntity.ok(macchine);
    }

    @GetMapping("/ElettricheById")
    public ResponseEntity<List<Macchine>> getMacchineElettricheById(@RequestParam Integer id) {
        List<Macchine> macchine = macchineService.getMacchineElettricheById(id);

        if (macchine.isEmpty()) {
            mqttPublisher.publishMessage("macchine/fetch", "Nessuna macchina elettrica trovata per l'ID utente: " + id);
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }

        mqttPublisher.publishMessage("macchine/fetch", "Macchine elettriche recuperate per l'ID utente: " + id);
        return ResponseEntity.ok(macchine);
    }
}
