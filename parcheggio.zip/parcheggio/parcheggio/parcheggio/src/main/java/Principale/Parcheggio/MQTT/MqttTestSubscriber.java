package Principale.Parcheggio.MQTT;

public class MqttTestSubscriber {
    public static void main(String[] args) {
        MqttSubscriber subscriber = new MqttSubscriber();
        subscriber.subscribe("parcheggio/ricarica"); // Sottoscrizione al topic di ricarica
        System.out.println("🟢 Subscriber in ascolto sul topic parcheggio/ricarica...");
    }
}
