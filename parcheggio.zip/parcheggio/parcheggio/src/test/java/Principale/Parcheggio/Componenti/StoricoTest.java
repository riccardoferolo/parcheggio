package Principale.Parcheggio.Componenti;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.StoricoRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import Principale.Parcheggio.Repository.PaymentRepository;
import Principale.Parcheggio.Services.StoricoService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class StoricoTest {

    @Autowired
    private StoricoService storicoService;

    @Autowired
    private StoricoRepository storicoRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MacchinaRepository macchinaRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    private User testUser;
    private ChargeRequest testChargeRequest;
    private Payment testPayment;
    private Reservation testReservation;

    @BeforeEach
    public void setup() {
        testUser = new User("utenteTest", "password123", "email@example.com");
        testUser.setSaldo(200.0);
        testUser.setRuolo(Ruolo.BASE);
        userRepository.save(testUser);

        Macchine macchina1 = new Macchine("AB123CD", 50.0, "Tesla Model S", testUser);
        macchinaRepository.save(macchina1);

        testChargeRequest = new ChargeRequest();
        testChargeRequest.setUser(testUser);
        testChargeRequest.setPagare(50.0);
        testChargeRequest.setData(LocalDate.now());
        testChargeRequest.setOra(Time.valueOf("10:00:00"));
        testChargeRequest.setOraFine(Time.valueOf("12:00:00"));
        testChargeRequest.setTarga("AB123CD");
        testChargeRequest.setRicarica(true);

        testChargeRequest = chargeRequestRepository.save(testChargeRequest);

        testPayment = new Payment();
        testPayment.setUser(testUser);
        testPayment.setChargeRequest(testChargeRequest);
        testPayment.setTotalAmount(50.0);
        testPayment.setPaid(true);
        paymentRepository.save(testPayment);

        testReservation = new Reservation();
        testReservation.setChargeRequest(testChargeRequest);
        testReservation.setPayment(testPayment);
        testReservation.setUser(testUser);
        testReservation.setTarga("AB123CD");
        testReservation.setRicarica(true);
        testReservation = reservationRepository.save(testReservation);
    }

    @Test
    void testSaveToStoricoSuccess() {
        storicoRepository.deleteAll();
        storicoService.saveToStorico(testChargeRequest, testPayment);

        List<Storico> storicoList = storicoRepository.findAll();
        assertEquals(1, storicoList.size());

        Storico storico = storicoList.get(0);
        assertNotNull(storico);
        assertEquals(testChargeRequest.getTarga(), storico.getTarga());
        assertEquals(testPayment.getId(), storico.getPayment());
    }

    @Test
    void testCompleteReservationSuccess() {
        storicoService.completeReservation(testReservation.getId());

        assertEquals(1, storicoRepository.count());
        assertFalse(reservationRepository.findById(testReservation.getId()).isPresent());
    }

    @Test
    void testCompleteReservationNotFound() {
        storicoService.completeReservation(999L);

        assertEquals(0, storicoRepository.count());
    }


    @AfterEach
    public void tearDown() {
        storicoRepository.deleteAll();
        reservationRepository.deleteAll();
        paymentRepository.deleteAll();
        chargeRequestRepository.deleteAll();
        macchinaRepository.deleteAll();
        userRepository.deleteAll();
    }
}

