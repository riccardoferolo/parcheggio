package Principale.Parcheggio.Componenti;

import Principale.Parcheggio.Models.Ruolo;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import Principale.Parcheggio.Services.UserService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class UserTest {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    private User testUser;

    @BeforeEach
    public void setup() {
        testUser = new User("utenteTest", "password123!", "email@example.com");
        testUser.setSaldo(100.0);
        testUser.setRuolo(Ruolo.BASE);
        userRepository.save(testUser);
    }

    @Test
    void testSaveAndFindUserSuccess() {
        Optional<User> user = userService.findUserByUsername("utenteTest");

        assertTrue(user.isPresent());
        assertEquals("utenteTest", user.get().getUsername());
    }

    @Test
    void testFindUserByUsernameNotFound() {
        Optional<User> user = userService.findUserByUsername("utenteNonEsistente");
        assertFalse(user.isPresent());
    }

    @Test
    void testRegisterUserSuccess() {
        User newUser = new User("nuovoUtente", "Password1!", "nuovo@example.com");
        userService.registerUser(newUser);

        assertNotNull(userRepository.findByUsername("nuovoUtente").orElse(null));
    }

    @Test
    void testRegisterUserEmailAlreadyExists() {
        User duplicateUser = new User("altroUtente", "Password1!", "email@example.com");

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            userService.registerUser(duplicateUser);
        });

        assertEquals("Email già registrata", exception.getMessage());
    }

    @Test
    void testRegisterUserInvalidPassword() {
        User weakPasswordUser = new User("weakUser", "pass", "weak@example.com");

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            userService.registerUser(weakPasswordUser);
        });

        assertEquals("La password deve essere di almeno 8 caratteri", exception.getMessage());
    }

    @Test
    void testAggiornaSaldoSuccess() {
        userService.aggiornaSaldo("utenteTest", 50.0);

        User updatedUser = userRepository.findByUsername("utenteTest").orElseThrow();
        assertEquals(150.0, updatedUser.getSaldo());
    }

    @Test
    void testAggiornaCartaSuccess() {
        userService.aggiornaCarta("utenteTest", "1234567812345678");

        User updatedUser = userRepository.findByUsername("utenteTest").orElseThrow();
        assertEquals("1234567812345678", updatedUser.getCarta_di_credito());
    }


    @Test
    void testLoginUserSuccess() {
        User user = userService.loginUser("email@example.com", "password123!");

        assertNotNull(user);
        assertEquals("utenteTest", user.getUsername());
    }

    @Test
    void testLoginUserWrongPassword() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            userService.loginUser("email@example.com", "wrongPass!");
        });

        assertEquals("Password errata", exception.getMessage());
    }

    @Test
    void testEliminaTuttiGliUtenti() {
        userService.eliminaTuttiGliUtenti();
        assertEquals(0, userRepository.count());
    }

    @Test
    void testAggiornaAbbonamentoSuccess() {
        userService.aggiornaAbbonamento("utenteTest");

        User updatedUser = userRepository.findByUsername("utenteTest").orElseThrow();
        assertEquals(Ruolo.PREMIUM, updatedUser.getRuolo());
        assertEquals(80.0, updatedUser.getSaldo()); // Detratti 20€
    }

    @Test
    void testAggiornaAbbonamentoAlreadyPremium() {
        testUser.setRuolo(Ruolo.PREMIUM);
        userRepository.save(testUser);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            userService.aggiornaAbbonamento("utenteTest");
        });

        assertEquals("L'utente è già PREMIUM", exception.getMessage());
    }

    @Test
    void testAggiornaAbbonamentoSaldoInsufficiente() {
        testUser.setSaldo(10.0);
        userRepository.save(testUser);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            userService.aggiornaAbbonamento("utenteTest");
        });

        assertEquals("Saldo insufficiente per aggiornare il ruolo a PREMIUM", exception.getMessage());
    }

    @AfterEach
    public void tearDown() {
        userRepository.deleteAll();
    }
}

