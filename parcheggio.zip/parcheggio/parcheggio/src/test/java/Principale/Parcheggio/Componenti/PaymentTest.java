package Principale.Parcheggio.Componenti;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Repository.PaymentRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Services.PaymentService;
import Principale.Parcheggio.Services.UserService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Time;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")  // Usa il profilo test
public class PaymentTest {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private MacchinaRepository macchinaRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    private User testUser;
    private ChargeRequest testChargeRequest;
    private Payment testPayment;

    @BeforeEach
    public void setup() {
        // Creiamo un utente di test con ruolo USER
        testUser = new User("utenteTest", "password123", "email@example.com");
        testUser.setSaldo(200.0);
        testUser.setRuolo(Ruolo.BASE);
        userRepository.save(testUser);

        Macchine macchina1 = new Macchine("AB123CD", 50.0, "Tesla Model S", testUser);
        macchinaRepository.save(macchina1);

        // Creiamo e SALVIAMO una ChargeRequest simulata
        testChargeRequest = new ChargeRequest();
        testChargeRequest.setUser(testUser);
        testChargeRequest.setPagare(50.0);
        testChargeRequest.setData(LocalDate.now());
        testChargeRequest.setOra(Time.valueOf("10:00:00"));
        testChargeRequest.setOraFine(Time.valueOf("12:00:00"));
        testChargeRequest.setTarga("AB123CD");
        testChargeRequest.setRicarica(true);

        // **Salva prima la ChargeRequest nel database**
        testChargeRequest = chargeRequestRepository.save(testChargeRequest);

        // Creiamo e salviamo un pagamento simulato, ora con una ChargeRequest persistita
        testPayment = new Payment();
        testPayment.setUser(testUser);
        testPayment.setChargeRequest(testChargeRequest);
        testPayment.setTotalAmount(50.0);
        testPayment.setPaid(true);
        paymentRepository.save(testPayment);
    }


    @Test
    void testGetPaymentByIdSuccess() {
        Payment payment = paymentService.getPaymentById(testPayment.getId());

        assertNotNull(payment);
        assertEquals(50.0, payment.getTotalAmount());
        assertEquals(testUser.getId(), payment.getUser().getId());
        assertTrue(payment.isPaid());
    }

    @Test
    void testGetPaymentByIdNotFound() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            paymentService.getPaymentById(999L);
        });

        assertEquals("Pagamento non trovato con ID: 999", exception.getMessage());
    }

    @Test
    void testCreatePaymentSuccess() {
        Payment newPayment = paymentService.createPayment(testChargeRequest);

        assertNotNull(newPayment);
        assertEquals(testChargeRequest.getUser().getId(), newPayment.getUser().getId());
        assertEquals(50.0, newPayment.getTotalAmount());
        assertTrue(newPayment.isPaid());
    }

    @Test
    void testEliminaTuttiPagamenti() {
        assertEquals(1, paymentRepository.count());

        paymentService.eliminaTuttiPagamenti();

        assertEquals(0, paymentRepository.count());
    }

    @Test
    void testGetPaymentsByTypeRicaricaTrue() {
        List<Payment> payments = paymentService.getPaymentsByType(true);

        assertEquals(1, payments.size());
        assertTrue(payments.get(0).getChargeRequest().getRicarica());
    }

    @Test
    void testGetPaymentsByUserRoleBASE() {
        List<Payment> payments = paymentService.getPaymentsByUserRole(Ruolo.BASE);

        assertEquals(1, payments.size());
        assertEquals(Ruolo.BASE, payments.get(0).getUser().getRuolo());
    }

    @AfterEach
    public void tearDown() {
        paymentRepository.deleteAll();
        chargeRequestRepository.deleteAll();
        macchinaRepository.deleteAll();
        userRepository.deleteAll();
    }
}

