package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.*;
import Principale.Parcheggio.Services.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")  // Usa il profilo 'test' per caricare application-test.properties
public class ChargeRequestControllerTest {

    @Autowired
    private ChargeRequestService chargeRequestService;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private MacchinaRepository macchinaRepository;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        // Prepara i dati reali nel database prima di ogni test
        User user = new User("utenteTest", "password123", "email@example.com");
        user.setSaldo(100.0); // Imposta un saldo sufficiente per il test
        userRepository.save(user);

        ParkingSpot parkingSpot = new ParkingSpot();
        parkingSpot.setPosti_totali_sosta(3);
        parkingSpot.setPosti_totali_ricarica(2);
        parkingSpotRepository.save(parkingSpot);

        Macchine car = new Macchine("XYZ123", 50.0, "Tesla Model S", user);
        macchinaRepository.save(car);

        mockMvc = MockMvcBuilders.standaloneSetup(chargeRequestService).build();
    }

    @Test
    void testCreateChargeRequestSuccess() {
        // Utilizzando un utente creato precedentemente nel database
        User user = userRepository.findByUsername("utenteTest").orElseThrow();

        // Chiamata al metodo del service per creare una ChargeRequest
        ChargeRequest chargeRequest = chargeRequestService.createChargeRequest(
                "utenteTest",
                LocalDate.now(),
                Time.valueOf("10:00:00"),
                Time.valueOf("02:00:00"),
                50,
                80,
                Time.valueOf("12:00:00"),
                "XYZ123",
                true);

        // Verifica che la ChargeRequest non sia nulla
        assertNotNull(chargeRequest);
        assertEquals("XYZ123", chargeRequest.getTarga());
        assertEquals(100.0, user.getSaldo()); // Verifica che il saldo sia stato aggiornato
    }

    @Test
    void testCreateChargeRequestInsufficientFunds() {
        // Mocking the user with insufficient balance
        User user = userRepository.findByUsername("utenteTest").orElseThrow();
        user.setSaldo(0.0);  // Saldo inferiore al costo
        userRepository.save(user);

        // Test che l'eccezione venga lanciata
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            chargeRequestService.createChargeRequest(
                    "utenteTest",
                    LocalDate.now(),
                    Time.valueOf("10:00:00"),
                    Time.valueOf("02:00:00"),
                    50,
                    80,
                    Time.valueOf("12:00:00"),
                    "XYZ123",
                    true);
        });

        // Verifica che l'eccezione contenga il messaggio giusto
        assertEquals("Saldo insufficiente per completare il pagamento. Impossibile mandare la richiesta, prima ricaricare il saldo.", exception.getMessage());
    }

    @Test
    void testGetChargeRequestsByUserId() {
        // Crea un utente e alcune ChargeRequests
        User user = userRepository.findByUsername("utenteTest").orElseThrow();
        ChargeRequest chargeRequest1 = new ChargeRequest();
        chargeRequest1.setUser(user);
        chargeRequestRepository.save(chargeRequest1);

        ChargeRequest chargeRequest2 = new ChargeRequest();
        chargeRequest2.setUser(user);
        chargeRequestRepository.save(chargeRequest2);

        // Recupera tutte le ChargeRequests associate a quell'utente
        List<ChargeRequest> chargeRequests = chargeRequestService.getChargeRequestsByUserId(user.getId());

        // Verifica che siano state recuperate le giuste richieste
        assertEquals(2, chargeRequests.size());
    }

    @Test
    void testEliminaTuttelerichieste() {
        // Crea alcune ChargeRequests
        User user = userRepository.findByUsername("utenteTest").orElseThrow();
        ChargeRequest chargeRequest1 = new ChargeRequest();
        chargeRequest1.setUser(user);
        chargeRequestRepository.save(chargeRequest1);

        ChargeRequest chargeRequest2 = new ChargeRequest();
        chargeRequest2.setUser(user);
        chargeRequestRepository.save(chargeRequest2);

        // Verifica che ci siano richieste nel database
        assertEquals(2, chargeRequestRepository.count());

        // Elimina tutte le richieste
        chargeRequestService.eliminaTuttelerichieste();

        // Verifica che tutte le richieste siano state eliminate
        assertEquals(0, chargeRequestRepository.count());
    }

    @AfterEach
    public void tearDown() {
        reservationRepository.deleteAll();
        paymentRepository.deleteAll();
        chargeRequestRepository.deleteAll();
        macchinaRepository.deleteAll();
        userRepository.deleteAll();
        parkingSpotRepository.deleteAll();
    }
}
