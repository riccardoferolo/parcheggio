package Principale.Parcheggio.Componenti;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.*;
import Principale.Parcheggio.Services.ReservationService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class ReservationTest {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MacchinaRepository macchinaRepository;

    @Autowired
    private DelayedReservationRepository delayedReservationRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    private User testUser;
    private ChargeRequest testChargeRequest;
    private Payment testPayment;
    private Reservation testReservation;

    @BeforeEach
    public void setup() {
        testUser = new User("utenteTest", "password123", "email@example.com");
        testUser.setSaldo(200.0);
        testUser.setRuolo(Ruolo.BASE);
        userRepository.save(testUser);

        Macchine macchina1 = new Macchine("AB123CD", 50.0, "Tesla Model S", testUser);
        macchinaRepository.save(macchina1);

        testChargeRequest = new ChargeRequest();
        testChargeRequest.setUser(testUser);
        testChargeRequest.setPagare(50.0);
        testChargeRequest.setData(LocalDate.now());
        testChargeRequest.setOra(Time.valueOf("10:00:00"));
        testChargeRequest.setOraFine(Time.valueOf("12:00:00"));
        testChargeRequest.setTarga("AB123CD");
        testChargeRequest.setRicarica(true);

        testChargeRequest = chargeRequestRepository.save(testChargeRequest);

        testPayment = new Payment();
        testPayment.setUser(testUser);
        testPayment.setChargeRequest(testChargeRequest);
        testPayment.setTotalAmount(50.0);
        testPayment.setPaid(true);
        paymentRepository.save(testPayment);

        testReservation = new Reservation();
        testReservation.setChargeRequest(testChargeRequest);
        testReservation.setPayment(testPayment);
        testReservation.setUser(testUser);
        testReservation.setTarga("AB123CD");
        testReservation.setRicarica(true);
        testReservation = reservationRepository.save(testReservation);
    }

    @Test
    void testAddReservationSuccess() {
        Reservation newReservation = reservationService.addReservation(testUser.getId(), testChargeRequest.getId(), testPayment, "AB123CD", true);

        assertNotNull(newReservation);
        assertEquals(testUser.getId(), newReservation.getUser().getId());
        assertEquals(testChargeRequest.getId(), newReservation.getChargeRequest().getId());
    }

    @Test
    void testDeleteAllReservations() {
        reservationService.deleteAllReservations();
        assertEquals(0, reservationRepository.count());
    }

    @Test
    void testDeleteReservationByChargeRequestIdSuccess() {
        boolean result = reservationService.deleteReservationByChargeRequestId(testChargeRequest.getId());
        assertTrue(result);
        assertEquals(0, reservationRepository.count());
    }

    @Test
    void testDeleteReservationByChargeRequestIdNotFound() {
        boolean result = reservationService.deleteReservationByChargeRequestId(999L);
        assertFalse(result);
    }

    @Test
    void testFindAllReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();
        assertEquals(1, reservations.size());
    }

    @Test
    void testSetRitardo() {
        reservationService.SetRitardo(testReservation);

        Optional<Reservation> updatedReservation = reservationRepository.findById(testReservation.getId());
        assertTrue(updatedReservation.isPresent());
        assertTrue(updatedReservation.get().getRitardo());
    }

    @Test
    void testCompleteReservationSuccess() {
        reservationService.completeReservation(testReservation);
        assertEquals(0, reservationRepository.count());
    }

    @Test
    void testEsciPrimaDalParcheggio() {
        String response = reservationService.esciPrimaDalParcheggio(testReservation.getId());

        assertEquals("Uscita anticipata registrata con successo per la targa: AB123CDe per l'utente utenteTest", response);
    }

    @AfterEach
    public void tearDown() {
        reservationRepository.deleteAll();
        paymentRepository.deleteAll();
        chargeRequestRepository.deleteAll();
        macchinaRepository.deleteAll();
        userRepository.deleteAll();
    }
}
