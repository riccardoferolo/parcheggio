package Principale.Parcheggio.Componenti;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.ParcheggioApplication;
import Principale.Parcheggio.Repository.*;
import Principale.Parcheggio.Services.ChargeRequestService;
import Principale.Parcheggio.Services.ReservationService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
public class ChargeRequestTest {

    @Autowired
    private ChargeRequestService chargeRequestService;

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MacchinaRepository macchinaRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    private User testUser;
    private ChargeRequest testChargeRequest;
    private Payment testPayment;

    @BeforeEach
    public void setup() {
        testUser = new User("utenteTest", "password123", "email@example.com");
        testUser.setSaldo(200.0);
        testUser.setRuolo(Ruolo.BASE);
        userRepository.save(testUser);

        Macchine macchina1 = new Macchine("AB123CD", 50.0, "Tesla Model S", testUser);
        macchinaRepository.save(macchina1);

        testChargeRequest = new ChargeRequest();
        testChargeRequest.setUser(testUser);
        testChargeRequest.setPagare(50.0);
        testChargeRequest.setData(LocalDate.now());
        testChargeRequest.setOra(Time.valueOf("10:00:00"));
        testChargeRequest.setOraFine(Time.valueOf("12:00:00"));
        testChargeRequest.setTarga("AB123CD");
        testChargeRequest.setRicarica(true);

        testChargeRequest = chargeRequestRepository.save(testChargeRequest);

        testPayment = new Payment();
        testPayment.setUser(testUser);
        testPayment.setChargeRequest(testChargeRequest);
        testPayment.setTotalAmount(50.0);
        testPayment.setPaid(true);
        paymentRepository.save(testPayment);
    }

    @Test
    void testCreateChargeRequestSuccess() {
        ChargeRequest newChargeRequest = chargeRequestService.createChargeRequest(
                "utenteTest",
                LocalDate.now(),
                Time.valueOf("10:00:00"),
                Time.valueOf("02:00:00"),
                20,
                80,
                Time.valueOf("12:00:00"),
                "AB123CD",
                true
        );

        assertNotNull(newChargeRequest);
        assertEquals("AB123CD", newChargeRequest.getTarga());
    }

    @Test
    void testCreateChargeRequestUserNotFound() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            chargeRequestService.createChargeRequest(
                    "utenteNonEsistente",
                    LocalDate.now(),
                    Time.valueOf("10:00:00"),
                    Time.valueOf("02:00:00"),
                    20,
                    80,
                    Time.valueOf("12:00:00"),
                    "AB123CD",
                    true
            );
        });

        assertEquals("Utente non trovato", exception.getMessage());
    }

    @Test
    void testGetChargeRequestById() {
        Optional<ChargeRequest> foundChargeRequest = chargeRequestService.getChargeRequestById(testChargeRequest.getId());
        assertTrue(foundChargeRequest.isPresent());
    }

    @Test
    void testCalculateTotalAmountSosta() {
        Time durata = Time.valueOf("02:30:00");
        double costo = chargeRequestService.calculateTotalAmountSosta(durata);
        assertEquals(3.00, costo);
    }

    @Test
    void testCalculateTotalAmountRicarica() {
        Time durata = Time.valueOf("02:00:00");
        double costo = chargeRequestService.calculateTotalAmountRicarica("AB123CD", durata);
        assertEquals(17.4, costo);
    }

    @Test
    void testCalcolaTempoRicarica() {
        String tempoRicarica = chargeRequestService.calcola(20, 80, 50.0);
        assertEquals("00:04:04", tempoRicarica);
    }

    @AfterEach
    public void tearDown() {
        reservationRepository.deleteAll();
        paymentRepository.deleteAll();
        chargeRequestRepository.deleteAll();
        macchinaRepository.deleteAll();
        userRepository.deleteAll();
    }
}
