package Principale.Parcheggio.Componenti;

import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Services.MacchineService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test") // Usa il profilo test
public class MacchineTest {

    @Autowired
    private MacchineService macchineService;

    @Autowired
    private MacchinaRepository macchinaRepository;

    @Autowired
    private UserRepository userRepository;

    private User testUser;

    @BeforeEach
    public void setup() {
        // Creiamo un utente di test
        testUser = new User("utenteTest", "password123", "email@example.com");
        userRepository.save(testUser);

        // Creiamo una macchina di test
        Macchine macchina1 = new Macchine("AB123CD", 50.0, "Tesla Model S", testUser);
        macchinaRepository.save(macchina1);

        Macchine macchina2 = new Macchine("XY987ZY", 60.0, "Nissan Leaf", testUser);
        macchinaRepository.save(macchina2);
    }

    @Test
    void testCreateMacchinaSuccess() {
        Macchine newMacchina = macchineService.createMacchina("ZZ111YY", 75.0, "Audi e-tron", "utenteTest");

        assertNotNull(newMacchina);
        assertEquals("ZZ111YY", newMacchina.getTarga());
        assertEquals(75.0, newMacchina.getKwBatteria());
        assertEquals("Audi e-tron", newMacchina.getModello());
        assertEquals(testUser.getId(), newMacchina.getUser().getId());
    }

    @Test
    void testCreateMacchinaUserNotFound() {
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            macchineService.createMacchina("BB222CC", 50.0, "BMW i4", "utenteSconosciuto");
        });

        assertEquals("User not found", exception.getMessage());
    }

    @Test
    void testDeleteMacchinaSuccess() {
        macchineService.deleteMacchina("AB123CD");
        assertNull(macchinaRepository.findByTarga("AB123CD"));
    }

    @Test
    void testDeleteMacchinaNotFound() {
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            macchineService.deleteMacchina("WW999QQ");
        });

        assertEquals("Macchina non trovata", exception.getMessage());
    }

    @Test
    void testUpdateMacchinaSuccess() {
        Macchine updatedMacchina = macchineService.updateMacchina("AB123CD", 80.0, "Tesla Model X");

        assertNotNull(updatedMacchina);
        assertEquals(80.0, updatedMacchina.getKwBatteria());
        assertEquals("Tesla Model X", updatedMacchina.getModello());
    }

    @Test
    void testUpdateMacchinaNotFound() {
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            macchineService.updateMacchina("WW999QQ", 90.0, "Porsche Taycan");
        });

        assertEquals("Macchina non trovata", exception.getMessage());
    }

    @Test
    void testGetMacchineByUserId() {
        List<Macchine> macchine = macchineService.getMacchineByUserId(testUser.getId());

        assertEquals(2, macchine.size());
    }

    @Test
    void testGetMacchineByUserIdEmpty() {
        User nuovoUser = new User("utenteVuoto", "password456", "empty@example.com");
        userRepository.save(nuovoUser);

        List<Macchine> macchine = macchineService.getMacchineByUserId(nuovoUser.getId());
        assertTrue(macchine.isEmpty());
    }

    @Test
    void testGetMacchinaByTargaSuccess() {
        Macchine macchina = macchineService.getMacchinaByTarga("AB123CD");
        assertNotNull(macchina);
        assertEquals("AB123CD", macchina.getTarga());
    }

    @Test
    void testGetMacchinaByTargaNotFound() {
        Macchine macchina = macchineService.getMacchinaByTarga("WW999QQ");
        assertNull(macchina);
    }

    @Test
    void testIsValidTargaItaliana() {
        assertTrue(MacchineService.isValidTargaItaliana("AB123CD"));
        assertTrue(MacchineService.isValidTargaItaliana("MI123456"));
        assertFalse(MacchineService.isValidTargaItaliana("123ABC"));
        assertFalse(MacchineService.isValidTargaItaliana("XYZ 9876"));
    }

    @Test
    void testDeleteAllMacchine() {
        assertEquals(2, macchinaRepository.count());

        macchineService.deleteMacchine();

        assertEquals(0, macchinaRepository.count());
    }

    @AfterEach
    public void tearDown() {
        macchinaRepository.deleteAll();
        userRepository.deleteAll();
    }
}
