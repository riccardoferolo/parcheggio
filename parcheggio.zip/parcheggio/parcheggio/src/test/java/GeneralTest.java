import Principale.Parcheggio.ParcheggioApplication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Models.ParkingSpot;
import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Repository.ParkingSpotRepository;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Models.Ruolo;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(classes = ParcheggioApplication.class) // Aggiungi questa riga
@Transactional
public class GeneralTest {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private MacchinaRepository macchineRepository;

    @BeforeEach
    public void setup() {
        // Creazione di utenti
        User user1 = new User("user1", "password1", "user1@example.com");
        user1.setSaldo(100.0);
        user1.setCarta_di_credito("1234567890123456");
        user1.setRuolo(Ruolo.BASE);
        userRepository.save(user1);

        User user2 = new User("user2", "password2", "user2@example.com");
        user2.setSaldo(200.0);
        user2.setCarta_di_credito("9876543210987654");
        user2.setRuolo(Ruolo.ADMIN);
        userRepository.save(user2);

        // Creazione di parcheggi
        ParkingSpot parkingSpot1 = new ParkingSpot();
        parkingSpot1.setPosti_totali_sosta(50);
        parkingSpot1.setPosti_totali_ricarica(20);
        parkingSpotRepository.save(parkingSpot1);

        ParkingSpot parkingSpot2 = new ParkingSpot();
        parkingSpot2.setPosti_totali_sosta(100);
        parkingSpot2.setPosti_totali_ricarica(30);
        parkingSpotRepository.save(parkingSpot2);

        // Creazione di macchine
        Macchine macchina1 = new Macchine("ABC123", 50.0, "Modello A", user1);
        Macchine macchine2 = new Macchine("XYZ789", 75.0, "Modello B", user2);
        macchineRepository.save(macchina1);
        macchineRepository.save(macchine2);
    }

    @Test
    public void testUserRepository() {
        // Recupera un utente e testalo
        Optional<User> u = userRepository.findByUsername("user1");
        User user = u.get();
        assertEquals("user1", user.getUsername());
    }

    @Test
    public void testMacchineRepository() {
        // Recupera una macchina associata a un utente e testala
        Macchine macchina = macchineRepository.findByTarga("ABC123");
        assertEquals("ABC123", macchina.getTarga());
    }

    @Test
    public void testParkingSpotRepository() {
        // Test per verificare il parcheggio
        ParkingSpot spot = parkingSpotRepository.findById(1).orElse(null);
        assertEquals(50, spot.getPosti_totali_sosta());
    }
}

