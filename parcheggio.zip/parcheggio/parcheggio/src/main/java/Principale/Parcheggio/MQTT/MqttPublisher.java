package Principale.Parcheggio.MQTT;

import org.eclipse.paho.client.mqttv3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MqttPublisher {
    private final MqttClient client;

    @Autowired
    public MqttPublisher(MqttConfig mqttConfig) {
        this.client = mqttConfig.getClient();
    }

    public void publishMessage(String topic, String payload) {
        try {
            if (client == null || !client.isConnected()) {
                System.err.println("❌ MQTT Client non connesso! Impossibile inviare messaggi.");
                return;
            }

            MqttMessage message = new MqttMessage(payload.getBytes());
            message.setQos(1);

            client.publish(topic, message);
            System.out.println("📤 Messaggio inviato su " + topic + ": " + payload);
        } catch (MqttException e) {
            System.err.println("❌ Errore nell'invio del messaggio MQTT: " + e.getMessage());
        }
    }
}

