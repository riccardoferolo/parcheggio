package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MacchineService {

    @Autowired
    private MacchinaRepository macchineRepository;

    @Autowired
    private UserRepository userRepository;

    public Macchine createMacchina(String targa, double kwBatteria, String modello, String username) {
        User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
        Macchine macchina = new Macchine(targa, kwBatteria, modello, user);
        return macchineRepository.save(macchina);
    }

    public void deleteMacchina(String targa) {
        targa = targa.toUpperCase();
        Macchine macchina = macchineRepository.findByTarga(targa);
        if (macchina != null) {
            macchineRepository.delete(macchina);
        } else {
            throw new RuntimeException("Macchina non trovata");
        }
    }

    public Macchine updateMacchina(String targa, double kwBatteria, String modello) {
        Macchine macchina = macchineRepository.findByTarga(targa);
        if (macchina != null) {
            macchina.setKwBatteria(kwBatteria);
            macchina.setModello(modello);
            return macchineRepository.save(macchina);
        } else {
            throw new RuntimeException("Macchina non trovata");
        }
    }

    public List<Macchine> getMacchineByUserId(int userId) {
        return macchineRepository.findByUserId(userId);
    }

    public Macchine getMacchinaByTarga(String targa) {
        targa = targa.toUpperCase();
        return macchineRepository.findByTarga(targa);
    }

    public static boolean isValidTargaItaliana(String targa) {
        String formatoAttuale = "^[A-Z]{2}[0-9]{3}[A-Z]{2}$";

        String formatoStorico = "^[A-Z]{1,2}[0-9]{1,6}$";

        return targa.matches(formatoAttuale) || targa.matches(formatoStorico);
    }


    public void deleteMacchine(){
        macchineRepository.deleteAll();
    }

    public List<Macchine> getMacchineByUser(String username) {
        return macchineRepository.findByUsername(username);
    }

    public List<Macchine> getMacchineById(Integer id) {
        return macchineRepository.findByUserId(id);
    }

    public List<Macchine> getMacchineElettricheById(Integer id) {
        return macchineRepository.findAllByUserIdElettriche(id);
    }
}

