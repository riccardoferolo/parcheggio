package Principale.Parcheggio.MQTT;

import org.eclipse.paho.client.mqttv3.*;

public class MqttSubscriber {
    private MqttConfig mqttConfig;

    public MqttSubscriber() {
        this.mqttConfig = new MqttConfig();
    }

    public void subscribe(String topic) {
        try {
            mqttConfig.getClient().subscribe(topic, (t, message) -> {
                System.out.println(" Messaggio ricevuto su " + t + ": " + new String(message.getPayload()));
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
