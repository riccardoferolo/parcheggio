package Principale.Parcheggio.BOT.Main;

import Principale.Parcheggio.BOT.MWBot;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Services.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"Principale.Parcheggio.BOT"})
@ComponentScan(basePackages = "Principale.Parcheggio") // Assicura che il bot trovi i repository
@EnableJpaRepositories(basePackages = "Principale.Parcheggio.Repository") // Abilita i repository
public class MWBotApplication implements CommandLineRunner {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private DelayedReservationRepository delayedReservationRepository;

    @Autowired
    private ReservationService reservationService;

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(MWBotApplication.class);
        app.setAdditionalProfiles("bot"); // Attiva il profilo "bot"
        app.run(args);
    }

    @Override
    public void run(String... args) {
        System.out.println("✅ MWBot avviato correttamente!");
        MWBot bot = new MWBot(reservationRepository, delayedReservationRepository, reservationService);
        bot.run(); // Esegue il bot in loop infinito
    }
}
