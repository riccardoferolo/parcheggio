package Principale.Parcheggio.MQTT;

public class MqttTestPublisher {
    public static void main(String[] args) {
        MqttPublisher publisher = new MqttPublisher();
        publisher.publishMessage("parcheggio/ricarica", "🔌 Test: richiesta di ricarica ricevuta per veicolo ID 1234");
    }
}
