package Principale.Parcheggio.Security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Base64;
import java.util.Date;

@Component
public class JwtUtil {

   // private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);


    @Value("${jwt.secret:non-impostata}")
    private String secretKey;

   // private static final long EXPIRATION_TIME = 86400000; // 1 giorno

    @PostConstruct
    public void init() {
        if ("non-impostata".equals(secretKey)) {
            secretKey = System.getenv("JWT_SECRET");
        }

        if (secretKey == null || secretKey.isEmpty()) {
            throw new IllegalArgumentException("La chiave segreta non è configurata!");
        }
    }

    private Key getKey() {
        if (secretKey == null) {
            secretKey = System.getenv("JWT_SECRET");
        }
        if (secretKey == null || secretKey.length() < 32) {
            throw new IllegalStateException("La chiave segreta non è valida o non è stata caricata.");
        }

        byte[] decodedKey = Base64.getDecoder().decode(secretKey);
        return Keys.hmacShaKeyFor(decodedKey);
    }

    @PostConstruct
    public void logSecretKey() {
        //System.out.println("JWT_SECRET usata dal server: " + secretKey);
    }


    @PostConstruct
    public void validateSecretKey() {
        if (secretKey == null || secretKey.isEmpty()) {
            throw new IllegalArgumentException("La chiave segreta non è stata configurata correttamente.");
        }
        if (secretKey.length() < 32) {
            throw new IllegalArgumentException("La chiave segreta deve avere almeno 32 caratteri.");
        }
    }


    public String generateToken(String username, String role) {
        return Jwts.builder()
                .setSubject(username)
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000))
                .signWith(getKey(), SignatureAlgorithm.HS256)
                .compact();
    }


    public String validateToken(String token) {
        try {
            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(getKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();


            return claims.getSubject();
        } catch (ExpiredJwtException e) {
            throw new IllegalArgumentException("Token scaduto");
        } catch (JwtException | IllegalArgumentException e) {
            throw new IllegalArgumentException("Token non valido");
        }
    }


    public String extractRole(String token) {
        try {
            Claims claims = Jwts.parserBuilder()
            .setSigningKey(getKey())
            .build()
            .parseClaimsJws(token)
            .getBody();

            return claims.get("role", String.class);
        } catch (JwtException | IllegalArgumentException e) {
            throw new IllegalArgumentException("Token non valido");
        }
    }


}



