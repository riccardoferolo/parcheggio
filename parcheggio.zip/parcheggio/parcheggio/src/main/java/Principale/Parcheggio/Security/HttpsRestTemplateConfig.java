package Principale.Parcheggio.Security;




import jakarta.annotation.PostConstruct;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.socket.ConnectionSocketFactory;
import org.apache.hc.client5.http.socket.PlainConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;


import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.ssl.SSLContexts;
import org.apache.hc.core5.ssl.TrustStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.io.InputStream;
import java.security.KeyStore;

@Configuration
@PropertySource("classpath:application.properties")
public class HttpsRestTemplateConfig {

    @Value("${server.ssl.trust-store:classpath:keystore.jks}")
    private String trustStorePath;

    @Value("${server.ssl.trust-store-password:changeit}")
    private String trustStorePassword;


    @PostConstruct
    public void debugProperties() {
        //System.out.println("Truststore Path: " + trustStorePath);
        //System.out.println("Truststore Password: " + trustStorePassword);
    }


    @Bean
    public RestTemplate createRestTemplate() {
        String normalizedPath1 = trustStorePath.replace("classpath:", "");
        InputStream is = getClass().getClassLoader().getResourceAsStream(normalizedPath1);

        if (is == null) {
            throw new RuntimeException("Truststore non trovato nel classpath: " + normalizedPath1);
        } else {
           // System.out.println("Truststore trovato e caricato correttamente: " + normalizedPath1);
        }

        try {
            if (trustStorePath == null || trustStorePassword == null) {
                throw new IllegalStateException("Truststore path o password non configurati correttamente.");
            }

            //System.out.println("Truststore Path (debug): " + trustStorePath);
            //System.out.println("Truststore Password (debug): " + trustStorePassword);

            String normalizedPath = trustStorePath.replace("classpath:", "");

            KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
            try (InputStream trustStoreStream = getClass().getClassLoader().getResourceAsStream(normalizedPath)) {
                if (trustStoreStream == null) {
                    throw new RuntimeException("Truststore non trovato: " + trustStorePath);
                }
                trustStore.load(trustStoreStream, trustStorePassword.toCharArray());
            }

            SSLContext sslContext = SSLContexts.custom()
                    .loadTrustMaterial(trustStore, null)
                    .build();

            CloseableHttpClient httpClient = HttpClients.custom()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(
                            RegistryBuilder.<ConnectionSocketFactory>create()
                                    .register("https", new SSLConnectionSocketFactory(sslContext))
                                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                                    .build()))
                    .build();

            HttpComponentsClientHttpRequestFactory requestFactory =
                    new HttpComponentsClientHttpRequestFactory(httpClient);

            return new RestTemplate(requestFactory);

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Errore nella configurazione di RestTemplate con HTTPS: " + e.getMessage(), e);
        }
    }



}









