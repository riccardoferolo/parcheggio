package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;


import java.sql.Time;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.server.ResponseStatusException;


@Service
public class ChargeRequestService {

    double potenzaCaricatore = 100.0;
    double fattorePotenza = 0.9;
    double costoSosta = 0.02;
    double tariffaPerKwh = 0.30;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private PaymentRepository paymentRepository;

    private static final Logger logger = LoggerFactory.getLogger(ChargeRequestService.class);
    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private MacchinaRepository macchinaRepository;

    @Transactional
    public ChargeRequest createChargeRequest(String nome, LocalDate giorno, Time ora, Time durata, Integer Percentuale_iniziale, Integer Percentuale_richiesta, Time oraFine, String Targa, Boolean r) {
        try {
            ChargeRequest chargeRequest = new ChargeRequest();
            if(r == null) {
                chargeRequest.setPagare(calculateTotalAmountSosta(durata));
            }
            else{
                chargeRequest.setPagare(calculateTotalAmountRicarica(Targa,durata));
            }

            Optional<User> userOptional = userRepository.findByUsername(nome);
            if (!userOptional.isPresent()) {
                throw new IllegalArgumentException("Utente non trovato");
            }

            User user = userOptional.get();

            if (user.getSaldo() < chargeRequest.getPagare()) {
                throw new IllegalArgumentException("Saldo insufficiente per completare il pagamento. Impossibile mandare la richiesta, prima ricaricare il saldo.");
            }

            user.setSaldo(user.getSaldo() - chargeRequest.getPagare());
            userService.saveUser(user);

            chargeRequest.setOra(ora);
            chargeRequest.setdurata(durata);
            chargeRequest.setGiorno(giorno);
            chargeRequest.setOra(ora);
            chargeRequest.setUser(user);
            chargeRequest.setPercentuale_iniziale(Percentuale_iniziale);
            chargeRequest.setPercentuale_richiesta(Percentuale_richiesta);
            chargeRequest.setOraFine(oraFine);
            chargeRequest.setTarga(Targa);
            chargeRequest.setRicarica(r);

            chargeRequest.setPagare(chargeRequest.getPagare());

            ChargeRequest savedRequest = chargeRequestRepository.save(chargeRequest);

            paymentService.createPayment(chargeRequest);

            Payment payment = paymentRepository.findByChargeRequestId(chargeRequest.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Pagamento non trovato per la richiesta di carica con ID " + chargeRequest.getId()));

            reservationService.addReservation(user.getId(),chargeRequest.getId(), payment, Targa, r);

            return savedRequest;
        } catch (IllegalArgumentException e) {
            logger.error("Errore: " + e.getMessage());
            throw new IllegalArgumentException(e.getMessage());
        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            logger.error("Errore durante la creazione della richiesta di carica: " + e.getMessage());
            throw new RuntimeException("Errore durante la creazione della richiesta di carica: " + e.getMessage());
        }
        }

    public Optional<ChargeRequest> getChargeRequestById(Long id) {
        return chargeRequestRepository.findById(id);
    }

    public List<ChargeRequest> getAllChargeRequests() {
        return chargeRequestRepository.findAll();
    }

    public void deleteChargeRequest(Long id) {
        chargeRequestRepository.deleteById(id);
        System.out.println("richiesta di carica con id" + id + "eliminata");
    }

    public List<ChargeRequest> getChargeRequestsByUserId(long userId) {
        User user = userService.getUserById(userId);

        return chargeRequestRepository.findByUser(user);
    }

    public void eliminaTuttelerichieste() {
        chargeRequestRepository.deleteAll();

        chargeRequestRepository.resetAutoIncrement();
    }

    @Transactional
    public void deleteRequestsByUserId(Long userId) {
        chargeRequestRepository.deleteByUserId(userId);
    }

    public List<ChargeRequest> getRequestsByUserId(Long userid) {
        return chargeRequestRepository.findByUserId(userid);
    }

    public double calculateTotalAmountSosta(Time durata) {
        double ore =  durata.getHours() * 60;
        double minuti = ore + durata.getMinutes();
        double calcolo =  minuti * costoSosta;

        return Math.round(calcolo * 100.0) / 100.0;
    }

    public double calculateTotalAmountRicarica(String targa, Time durata) {
        Macchine macchina = macchinaRepository.findById(targa)
                .orElseThrow(() -> new IllegalArgumentException("Targa non trovata nella tabella macchine."));

        double kwBatteria = macchina.getKwBatteria();

        double minuti = durata.getHours() * 60 + durata.getMinutes();

        double costoSosta = calculateTotalAmountSosta(durata);

        double energiaTrasferita = (kwBatteria / 2.0) * (minuti / 60.0);

        double costoTotale = costoSosta + (energiaTrasferita * tariffaPerKwh);

        return Math.round(costoTotale * 100.0) / 100.0;
    }

    public boolean isReservationAvailable(LocalDate giorno, Time ora, Time oraFine) {
        ParkingSpot p = parkingSpotRepository.findById(1).orElse(null);

        String jpql = "SELECT COUNT(r) " +
                "FROM Reservation r " +
                "WHERE r.chargeRequest.Giorno = :giorno " +
                "AND (" +
                "  r.chargeRequest.Ora < :oraFine AND " +
                "  r.chargeRequest.OraFine > :oraInizio" +
                ") " +
                "AND r.chargeRequest.ricarica IS NULL";

        Query query = entityManager.createQuery(jpql);
        query.setParameter("giorno", giorno);
        query.setParameter("oraInizio", ora);
        query.setParameter("oraFine", oraFine);

        Long count = (Long) query.getSingleResult();

        if (p.getPosti_totali_sosta() <= 0) {
            throw new IllegalStateException("Posti totali non inizializzati.");
        }

        return count < p.getPosti_totali_sosta();
    }

    public Boolean isReservationAvailableRicarica(LocalDate giorno, Time ora, Time oraFine) {
        ParkingSpot p = parkingSpotRepository.findById(1).orElse(null);

        String jpql = "SELECT COUNT(r) " +
                "FROM Reservation r " +
                "WHERE r.chargeRequest.Giorno = :giorno " +
                "AND (" +
                "  r.chargeRequest.Ora < :oraFine AND " +
                "  r.chargeRequest.OraFine > :oraInizio" +
                ") " +
                "AND r.chargeRequest.ricarica = true ";

        Query query = entityManager.createQuery(jpql);
        query.setParameter("giorno", giorno);
        query.setParameter("oraInizio", ora);
        query.setParameter("oraFine", oraFine);

        Long count = (Long) query.getSingleResult();

        if (p.getPosti_totali_ricarica() <= 0) {
            throw new IllegalStateException("Posti totali non inizializzati.");
        }

        return count < p.getPosti_totali_ricarica();
    }

    public String calcola(Integer percentualeIniziale, Integer percentualeFinale, double kwAuto) {
        if (percentualeIniziale >= percentualeFinale || percentualeIniziale < 0 || percentualeFinale > 100) {
            throw new IllegalArgumentException("Le percentuali devono essere valide e rispettare percentualeIniziale < percentualeFinale.");
        }

        int percentualeDaCaricare = percentualeFinale - percentualeIniziale;

        double fattoreScala = 1 + (kwAuto / 140);
        int tempoTotaleSecondi = (int) ((percentualeDaCaricare / 10) * 30 * fattoreScala);

        int ore = tempoTotaleSecondi / 3600;
        int minuti = (tempoTotaleSecondi % 3600) / 60;
        int secondi = tempoTotaleSecondi % 60;

        return String.format("%02d:%02d:%02d", ore, minuti, secondi);
    }

    public Time findEarliestEndTimeSosta(LocalDate giorno, Time oraInizio, Time oraFine) {
        String jpql = "SELECT MIN(r.chargeRequest.OraFine) " +
                "FROM Reservation r " +
                "WHERE r.chargeRequest.Giorno = :giorno " +
                "AND (" +
                "  r.chargeRequest.Ora < :oraFine AND " +
                "  r.chargeRequest.OraFine > :oraInizio" +
                ") " +
                "AND r.chargeRequest.ricarica IS NULL";

        Query query = entityManager.createQuery(jpql);
        query.setParameter("giorno", giorno);
        query.setParameter("oraInizio", oraInizio);
        query.setParameter("oraFine", oraFine);

        Time earliestEndTime = (Time) query.getSingleResult();

        return earliestEndTime;
    }

    public Time findEarliestEndTimeRicarica(LocalDate giorno, Time oraInizio, Time oraFine) {
        String jpql = "SELECT MIN(r.chargeRequest.OraFine) " +
                "FROM Reservation r " +
                "WHERE r.chargeRequest.Giorno = :giorno " +
                "AND (" +
                "  r.chargeRequest.Ora < :oraFine AND " +
                "  r.chargeRequest.OraFine > :oraInizio" +
                ") " +
                "AND r.chargeRequest.ricarica = true";

        Query query = entityManager.createQuery(jpql);
        query.setParameter("giorno", giorno);
        query.setParameter("oraInizio", oraInizio);
        query.setParameter("oraFine", oraFine);

        Time earliestEndTime = (Time) query.getSingleResult();

        return earliestEndTime;
    }

    public void ModificaParametroSosta(double nuovoCostoSosta) {
        costoSosta = nuovoCostoSosta;
    }

    public void ModificaParametroRicarica(double nuovaTariffaPerKwh) {
        tariffaPerKwh = nuovaTariffaPerKwh;
    }


        /*
    public String calcolaTempoReale(Integer percentualeIniziale, Integer percentualeFinale, double kwAuto) {
        if (percentualeIniziale >= percentualeFinale || percentualeIniziale < 0 || percentualeFinale > 100) {
            throw new IllegalArgumentException("Le percentuali devono essere valide e rispettare percentualeIniziale < percentualeFinale.");
        }

        int percentualeDaCaricare = percentualeFinale - percentualeIniziale;

        double energiaNecessaria = (kwAuto * percentualeDaCaricare) / 100.0;

        double fattoreDiRiduzione = 10.0; // Riduce il tempo calcolato di un fattore di 10

        double tempoTotaleOre = (energiaNecessaria / (potenzaCaricatore * fattorePotenza)) / fattoreDiRiduzione;

        int tempoTotaleSecondi = (int) (tempoTotaleOre * 3600);

        int ore = tempoTotaleSecondi / 3600;
        int minuti = (tempoTotaleSecondi % 3600) / 60;
        int secondi = tempoTotaleSecondi % 60;

        return String.format("%02d:%02d:%02d", ore, minuti, secondi);
    }

     */ //funzione per caloclo con tempo reale (max 2 ore)
}


