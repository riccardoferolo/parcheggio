package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.*;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Security.JwtUtil;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

@Service
public class ReservationService {

    private static final Logger logger = LoggerFactory.getLogger(ReservationService.class);

    @Autowired
    private ReservationRepository reservationRepository;

    Scanner s = new Scanner(System.in);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private DelayedReservationRepository delayedReservationRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private StoricoService storicoService;

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    @Autowired
    private JwtUtil jwtUtil;

    private String token;

    @Transactional
    public Reservation addReservation(long userId, long chargeRequestId, Payment payment, String Targa, Boolean Ricarica) {
        try {
            User user = userRepository.findUserById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("Utente con ID " + userId + " non trovato"));

            ChargeRequest chargeRequest = chargeRequestRepository.findById(chargeRequestId)
                    .orElseThrow(() -> new IllegalArgumentException("Richiesta di carica con ID " + chargeRequestId + " non trovata"));

            Reservation reservation = new Reservation();
            reservation.setUser(user);
            reservation.setChargeRequest(chargeRequest);
            reservation.setTarga(Targa);
            reservation.setRicarica(Ricarica);


            if (payment == null) {
                throw new IllegalArgumentException("Il pagamento non può essere nullo.");
            }
            reservation.setPayment(payment);

            Reservation savedReservation = reservationRepository.save(reservation);

            return savedReservation;

        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Errore nei parametri forniti: " + e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException("Errore interno del server: " + e.getMessage());
        }
    }

    public void deleteAllReservations() {
        reservationRepository.deleteAll();
        reservationRepository.resetAutoIncrement();
    }

    public void deleteAllDelayedReservations(){
        delayedReservationRepository.deleteAll();
    }

    public boolean deleteReservationByChargeRequestId(long chargeRequestId) {
        Optional<Reservation> reservation = reservationRepository.findByChargeRequestId(chargeRequestId);
        if (reservation.isPresent()) {
            reservationRepository.delete(reservation.get());
            return true;
        }
        return false;
    }

    public List<Reservation> findAllReservations() {
        return reservationRepository.findAllByRicaricaTrue();
    }

    public Map<String, Integer> Occupazione() {
        List<Object[]> results = reservationRepository.Occupazione();

        int totaleRicariche = 0;
        int totaleSoste = 0;

        for (Object[] row : results) {
            totaleRicariche += ((Number) row[2]).intValue();
            totaleSoste += ((Number) row[3]).intValue();
        }

        Map<String, Integer> summary = new HashMap<>();
        summary.put("ricariche", totaleRicariche);
        summary.put("soste", totaleSoste);
        return summary;
    }

    public void SetRitardo(Reservation reservation) {
        Optional<Reservation> r = reservationRepository.findById(reservation.getId());
        if (r.isPresent()) {
            r.get().setRitardo(true);
            reservationRepository.save(r.get());

            DelayedReservation DR = new DelayedReservation(r.get());
            delayedReservationRepository.save(DR);
        }
    }


    public void completeReservation(Reservation reservation) {
        Long reservationId = reservation.getId();

        try {
            storicoService.completeReservation(reservationId);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("errore: " + e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException("Errore interno nel completamento della prenotazione: " + e.getMessage());
        }
    }

    @Transactional
    public String esciPrimaDalParcheggio(Long id) {
        Optional<Reservation> r = reservationRepository.findById(id);
        long attive = 0;
        attive = reservationRepository.countPrenotazioniAttive();

        if (r.isPresent() && attive > 0 ){
            storicoService.completeReservation(r.get().getId());
        } else if (r.isPresent() && attive == 0) {
            storicoService.completeReservation(r.get().getId());
            Optional<User> u = userRepository.findUserById(r.get().getUser().getId());
            if (u.isPresent()) {
                double saldo = u.get().getSaldo();
                userService.aggiornaSaldo(u.get().getUsername(), r.get().getChargeRequest().getPagare());
            }
        }

        return "Uscita anticipata registrata con successo per la targa: " + r.get().getTarga() + "e per l'utente " + r.get().getUser().getUsername();
    }

    public void RitardoTrue(Reservation reservation) {
        DelayedReservation d = new DelayedReservation(reservation);
        delayedReservationRepository.save(d);
        storicoService.completeReservation(reservation.getId());
    }

    public void RitardoFalse(Reservation reservation) {
        storicoService.completeReservation(reservation.getId());
    }

    public void CancellaSosteVecchie() {
        List<Reservation> reservations = reservationRepository.findExpiredReservations();
        for (Reservation r : reservations) {
            if(r.getRitardo().equals(Boolean.TRUE)){
                DelayedReservation d = new DelayedReservation(r);
                delayedReservationRepository.save(d);
                storicoService.completeReservation(r.getId());
            }
            else{
                storicoService.completeReservation(r.getId());
            }
        }
    }

    //------------------------------------------------------------------------------------------------------------------------
    public void PagareRitardo(DelayedReservation delayedReservation) {
        double costoRitardo = 20.0;

        String u = delayedReservation.getUsername();
        Optional<User> user = userRepository.findByUsername(u);

        user.get().setSaldo(user.get().getSaldo()-costoRitardo);
        userRepository.save(user.get());

        delayedReservationRepository.delete(delayedReservation);
        System.out.println("Pagamento effettuato con successo! Prenotazione ID " + delayedReservation.getId() + " rimossa.");

    }

    public void aggiornaLampadine(int postiTotSosta, int postiTotRicarica, Long postiSostaOccupati, Long postiRicaricaOccupati) {
        String UsernameHUE = registraUtenteHUE();
        String hueBridgeUrl = "http://localhost:8000/api/" + UsernameHUE + "/lights";
        RestTemplate restTemplate = new RestTemplate();

        aggiornaStatoLampadina(restTemplate, hueBridgeUrl, 1, postiSostaOccupati < postiTotSosta);
        aggiornaStatoLampadina(restTemplate, hueBridgeUrl, 2, postiRicaricaOccupati < postiTotRicarica);
    }

    private void aggiornaStatoLampadina(RestTemplate restTemplate, String hueBridgeUrl, int lampId, boolean disponibile) {
        String lampUrl = hueBridgeUrl + "/" + lampId + "/state";

        Map<String, Object> lampState = new HashMap<>();
        lampState.put("on", true);
        lampState.put("bri", 254);
        lampState.put("hue", disponibile ? 25500 : 0);

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(lampState, headers);

            restTemplate.put(lampUrl, request);
        } catch (Exception e) {
           throw new RuntimeException(e);
        }
    }

    public void OccupazioneLampadine(Optional<ParkingSpot> optionalParkingSpot, List<Reservation> reservations) {
        if (!optionalParkingSpot.isPresent()) {
            return;
        }
        ParkingSpot parkingSpot = optionalParkingSpot.get();
        int postiTotRicarica = parkingSpot.getPosti_totali_ricarica();
        int postiTotSosta = parkingSpot.getPosti_totali_sosta();

        List<Object[]> results = reservationRepository.Occupazione();

        long totaleRicariche = 0;
        long totaleSoste = 0;

        for (Object[] row : results) {
            totaleRicariche += ((Number) row[2]).intValue();
            totaleSoste += ((Number) row[3]).intValue();
        }

        aggiornaLampadine(postiTotSosta, postiTotRicarica, totaleSoste, totaleRicariche);
    }

    private String registraUtenteHUE() {
        String hueBridgeUrl = "http://localhost:8000/api";
        RestTemplate restTemplate = new RestTemplate();

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("devicetype", "my_hue_app");

        try {
            ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
                    hueBridgeUrl,
                    HttpMethod.POST,
                    new HttpEntity<>(requestBody),
                    new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
                    }
            );

            List<Map<String, Map<String, String>>> body = response.getBody();
            if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
                String username = body.get(0).get("success").get("username");

                return username;
            } else {
                System.err.println("Errore durante la registrazione dell'utente. Risposta API: " + body);
            }
        } catch (Exception e) {
            System.err.println("Errore durante la registrazione dell'utente: " + e.getMessage());
        }
        return null;
    }

}

