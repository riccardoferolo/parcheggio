package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Security.JwtUtil;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import static Principale.Parcheggio.ParcheggioApplication.isValidCreditCard;

@Service
public class ReservationService {

    private static final Logger logger = LoggerFactory.getLogger(ReservationService.class);

    @Autowired
    private ReservationRepository reservationRepository;

    Scanner s = new Scanner(System.in);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private DelayedReservationRepository delayedReservationRepository;

    @Autowired
    private ChargeRequestRepository chargeRequestRepository;

    @Autowired
    private StoricoService storicoService;

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    @Autowired
    private JwtUtil jwtUtil;

    private String token; // Variabile globale per il token JWT


    @Transactional
    public Reservation addReservation(long userId, long chargeRequestId, Payment payment, String Targa, Boolean Ricarica) {
        logger.info("Tentativo di aggiungere una prenotazione: User ID: {}, ChargeRequest ID: {}", userId, chargeRequestId);

        try {
            // Recupera l'utente in base all'ID
            User user = userRepository.findUserById(userId)
                    .orElseThrow(() -> new IllegalArgumentException("Utente con ID " + userId + " non trovato"));
            logger.info("Utente recuperato: {}", user.getUsername());

            // Recupera la richiesta di carica in base all'ID
            ChargeRequest chargeRequest = chargeRequestRepository.findById(chargeRequestId)
                    .orElseThrow(() -> new IllegalArgumentException("Richiesta di carica con ID " + chargeRequestId + " non trovata"));
            logger.info("Richiesta di carica recuperata: {}", chargeRequest.getId());


            // Crea una nuova prenotazione
            Reservation reservation = new Reservation();
            reservation.setUser(user);
            reservation.setChargeRequest(chargeRequest);
            reservation.setTarga(Targa);
            reservation.setRicarica(Ricarica);

            // Associa il pagamento alla prenotazione
            if (payment == null) {
                throw new IllegalArgumentException("Il pagamento non può essere nullo.");
            }
            reservation.setPayment(payment);  // Associa l'oggetto Payment
            logger.info("Prenotazione creata con pagamento, tentativo di salvataggio nel database.");

            // Salva la prenotazione nel database
            Reservation savedReservation = reservationRepository.save(reservation);
            logger.info("Prenotazione salvata con successo, ID: {}", savedReservation.getId());

            return savedReservation;

        } catch (IllegalArgumentException e) {
            logger.error("Errore di validazione nei parametri: {}", e.getMessage());
            throw new RuntimeException("Errore nei parametri forniti: " + e.getMessage());
        } catch (Exception e) {
            logger.error("Errore durante la creazione della prenotazione: {}", e.getMessage());
            throw new RuntimeException("Errore interno del server: " + e.getMessage());
        }
    }


    // Cancella una prenotazione per ID
    public boolean deleteReservationById(long id) {
        Optional<Reservation> reservation = reservationRepository.findById(id);
        if (reservation.isPresent()) {
            reservationRepository.deleteById(id);
            return true;
        }
        return false;
    }

    // Cancella tutte le prenotazioni
    public void deleteAllReservations() {
        reservationRepository.deleteAll();
        reservationRepository.resetAutoIncrement();
    }

    public void deleteAllDelayedReservations(){
        delayedReservationRepository.deleteAll();
    }


    // Cancella una prenotazione in base all'ID della richiesta di carica
    public boolean deleteReservationByChargeRequestId(long chargeRequestId) {
        Optional<Reservation> reservation = reservationRepository.findByChargeRequestId(chargeRequestId);
        if (reservation.isPresent()) {
            reservationRepository.delete(reservation.get());
            return true;
        }
        return false;
    }

    // Trova tutte le prenotazioni (utile per debugging o future funzioni)
    public List<Reservation> findAllReservations() {
        return reservationRepository.findAllByRicaricaTrue();
    }

    public Map<String, Integer> Occupazione() {
        List<Object[]> results = reservationRepository.Occupazione();

        // Inizializza i contatori
        int totaleRicariche = 0;
        int totaleSoste = 0;

        // Somma i totali da tutti i gruppi
        for (Object[] row : results) {
            totaleRicariche += ((Number) row[2]).intValue(); // Colonna ricariche
            totaleSoste += ((Number) row[3]).intValue();     // Colonna soste
        }

        // Restituisci i totali in una mappa
        Map<String, Integer> summary = new HashMap<>();
        summary.put("ricariche", totaleRicariche);
        summary.put("soste", totaleSoste);
        return summary;
    }

    public void SetRitardo(Reservation reservation) {
        Optional<Reservation> r = reservationRepository.findById(reservation.getId());
        if (r.isPresent()) {
            r.get().setRitardo(true);
            reservationRepository.save(r.get());

            DelayedReservation DR = new DelayedReservation(r.get());
            // Sposta la prenotazione nella tabella DelayedReservation
            delayedReservationRepository.save(DR);
        } else {
            System.out.println("reservation non trovato");
        }
    }

    public void PagareRitardo(DelayedReservation delayedReservation) {
        double costoRitardo = 20.0;
        String conferma;

        do {
            System.out.println("Il costo del ritardo per la prenotazione ID " + delayedReservation.getId() + " è di: " + costoRitardo + "€.");
            System.out.print("Confermi il pagamento? (si/no): ");
            conferma = s.nextLine().toLowerCase();

            if (conferma.equals("no")) {
                System.out.println("Pagamento annullato.");
                return;
            }

            if (!conferma.matches("si") && !conferma.matches("no")) {
                System.out.println("Errore: la risposta inserita non è valida, riprovare.");
                continue;
            }

            if (conferma.equals("si")) {
                String u = delayedReservation.getUsername();
                Optional<User> user = userRepository.findByUsername(u);
                // 🔹 Rimuove la prenotazione dalla tabella DelayedReservation
                user.get().setSaldo(user.get().getSaldo()-costoRitardo);
                userRepository.save(user.get());

                delayedReservationRepository.delete(delayedReservation);
                System.out.println("Pagamento effettuato con successo! Prenotazione ID " + delayedReservation.getId() + " rimossa.");
            }
        }while(!conferma.matches("si") && !conferma.matches("no"));
    }

    public void completeReservation(Reservation reservation) {
        Long reservationId = reservation.getId();

        try {
            storicoService.completeReservation(reservationId);
            System.out.println("Prenotazione completata e spostata nello storico con successo!");
        } catch (IllegalArgumentException e) {
            System.out.println("Errore: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Errore durante il completamento della prenotazione: " + e.getMessage());
        }
    }

    @Transactional
    public String esciPrimaDalParcheggio(String username) {
        // Troviamo le prenotazioni attive per l'utente
        List<Reservation> activeReservations = reservationRepository.findActiveReservationsWithoutDelay(username);

        if (activeReservations.isEmpty()) {
            return "❌ Nessuna prenotazione attiva trovata per l'utente.";
        }

        // Prendiamo la prima prenotazione attiva
        Reservation reservation = activeReservations.get(0);

        // Impostiamo che la prenotazione è terminata (logica da definire, es. eliminazione o flag)
        reservationRepository.delete(reservation);

        return "✅ Uscita anticipata registrata con successo per la targa: " + reservation.getTarga();
    }
}

