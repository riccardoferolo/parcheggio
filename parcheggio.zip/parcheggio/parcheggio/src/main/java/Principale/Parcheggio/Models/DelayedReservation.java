package Principale.Parcheggio.Models;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "delayed_reservations")
public class DelayedReservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private String username;

    @Column
    private LocalDate giorno;

    @Column
    private String Targa;

    @Column
    private Boolean ricarica;

    @Column
    private LocalDateTime dataSpostamento;

    public DelayedReservation() {}

    public DelayedReservation(Reservation reservation) {
        this.username = reservation.getUser().getUsername();
        this.giorno = reservation.getChargeRequest().getGiorno();
        this.Targa = reservation.getTarga();
        this.ricarica = reservation.getRicarica();
        this.dataSpostamento = LocalDateTime.now();
    }

    public long getId() { return id; }

    public void setId(long id) { this.id = id; }

    public String getUsername() { return username; }

    public void setUsername(String user) { this.username = user; }

    public LocalDate getGiorno() { return giorno; }

    public void setGiorno(LocalDate chargeRequest) { this.giorno = giorno; }

    public String getTarga() { return Targa; }

    public void setTarga(String targa) { this.Targa = targa; }

    public Boolean getRicarica() { return ricarica; }

    public void setRicarica(Boolean ricarica) { this.ricarica = ricarica; }

    public LocalDateTime getDataSpostamento() { return dataSpostamento; }

    public void setDataSpostamento(LocalDateTime dataSpostamento) { this.dataSpostamento = dataSpostamento; }
}

