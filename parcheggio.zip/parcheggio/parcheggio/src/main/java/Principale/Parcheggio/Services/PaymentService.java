package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Repository.*;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private UserService userService;

    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Pagamento non trovato con ID: " + id));
    }

    public Payment createPayment(ChargeRequest chargeRequest) {
        User user = chargeRequest.getUser();
        double totalAmount = chargeRequest.getPagare();

        Payment payment = new Payment();
        payment.setChargeRequest(chargeRequest);
        payment.setUser(user);
        payment.setPaid(true);
        payment.setTotalAmount(totalAmount);

        return paymentRepository.save(payment);
    }

    public void eliminaTuttiPagamenti() {
        paymentRepository.deleteAll();

        paymentRepository.resetAutoIncrement();
    }

    public List<Payment> getPaymentsByType(Boolean ricarica) {
        return paymentRepository.findPaymentsByType(ricarica);
    }

    public List<Payment> getPaymentsByUserRole(Ruolo ruolo) {
        return paymentRepository.findPaymentsByUserRole(ruolo);
    }

}

