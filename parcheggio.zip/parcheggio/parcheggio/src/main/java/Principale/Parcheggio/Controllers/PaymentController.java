package Principale.Parcheggio.Controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.Models.*;
import Principale.Parcheggio.Services.*;
import org.springframework.http.HttpStatus;
import Principale.Parcheggio.MQTT.MqttPublisher;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/payments")
@Tag(name = "PaymentController", description = "Controller per i pagamenti")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ChargeRequestService chargeRequestService;

    @Autowired
    private MqttPublisher mqttPublisher;

    @Operation(summary = "Crea un pagamento",
            description = "Crea un pagamento per un Id di una richiesta.")
    @PostMapping("/create")
    public ResponseEntity<?> createPayment(@RequestBody Long chargeRequestId) {
        try {
            Optional<ChargeRequest> chargeRequestOpt = chargeRequestService.getChargeRequestById(chargeRequestId);

            if (!chargeRequestOpt.isPresent()) {
                mqttPublisher.publishMessage("errors/payment", "ChargeRequest con ID " + chargeRequestId + " non trovata.");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("ChargeRequest con ID " + chargeRequestId + " non trovata.");
            }

            ChargeRequest chargeRequest = chargeRequestOpt.get();
            Payment payment = paymentService.createPayment(chargeRequest);

            mqttPublisher.publishMessage("payments/create", "Pagamento creato con successo per la ChargeRequest ID: " + chargeRequestId);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/payment", "Errore durante la creazione del pagamento: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore durante la creazione del pagamento: " + e.getMessage());
        }
    }

    @Operation(summary = "Recupera un pagamento",
            description = "Recupera un pagamento tramite il suo ID.")
    @GetMapping("/recuper_id")
    public ResponseEntity<Payment> getPaymentById(@RequestBody Long id) {
        try {
            Payment payment = paymentService.getPaymentById(id);
            mqttPublisher.publishMessage("payments/fetch", "Pagamento recuperato con ID: " + id);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/payment", "Errore nel recupero del pagamento con ID " + id + ": " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @Operation(summary = "Restituisce i pagamanti",
            description = "Restituisce i pagamenti in base al ruolo oppure in base a sosta oppure a ricarica.")
    @PostMapping("/listaPagamenti")
    public ResponseEntity<List<Payment>> getPayments(@RequestBody Map<String, Object> params) {
        try {
            Boolean ricarica = (Boolean) params.get("ricarica");
            String ruolo = (String) params.get("ruolo");

            if (ricarica != null) {
                List<Payment> payments = paymentService.getPaymentsByType(ricarica);
                mqttPublisher.publishMessage("payments/filter", "Pagamenti filtrati per tipo di ricarica: " + ricarica);
                return ResponseEntity.ok(payments);
            } else if (ruolo != null) {
                Ruolo userRole = Ruolo.valueOf(ruolo.toUpperCase());
                List<Payment> payments = paymentService.getPaymentsByUserRole(userRole);
                mqttPublisher.publishMessage("payments/filter", "Pagamenti filtrati per ruolo utente: " + ruolo);
                return ResponseEntity.ok(payments);
            } else {
                mqttPublisher.publishMessage("errors/payment", "Parametri insufficienti per il filtraggio dei pagamenti.");
                return ResponseEntity.badRequest().build();
            }
        } catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/payment", "Ruolo utente non valido: " + e.getMessage());
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/payment", "Errore durante il recupero dei pagamenti: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
