package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Controllers.ChargeRequestController;
import Principale.Parcheggio.Services.ChargeRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/Admin")
public class AdminController {

    @Autowired
    private ChargeRequestService chargeRequestService;

    // Cancella ChargeRequest per ID
    @PutMapping("/Aggiorna-Costo-Sosta")
    public void AggiornaSosta(@RequestBody Double Sosta) {
        chargeRequestService.ModificaParametroSosta(Sosta);
        System.out.println("il costo della sosta è stato modificato con:" + Sosta);
    }

    // Cancella ChargeRequest per ID
    @PutMapping("/Aggiorna-Costo-ricarica")
    public void AggiornaRicarica(@RequestBody Double ricarica) {
        chargeRequestService.ModificaParametroRicarica(ricarica);
        System.out.println("il costo della ricarica è stato modificato con:" + ricarica);
    }
}
