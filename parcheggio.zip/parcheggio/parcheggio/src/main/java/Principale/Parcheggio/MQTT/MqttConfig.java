package Principale.Parcheggio.MQTT;

import org.eclipse.paho.client.mqttv3.*;

import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class MqttConfig {
    private static final String BROKER_URL = "tcp://localhost:1883"; //  Connessione senza TLS
    private static final String USERNAME = "Utente1";  //  Username configurato in Mosquitto
    private static final String PASSWORD = "ciao";  //  Password configurata
    private static final String CLIENT_ID = "MqttClient-" + UUID.randomUUID(); // //  Genera un clientId univoco per evitare disconnessioni se più client si connettono

    private MqttClient client;

    public MqttConfig() {
        try {
            client = new MqttClient(BROKER_URL, CLIENT_ID, new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setUserName(USERNAME);
            options.setPassword(PASSWORD.toCharArray());

            if (!client.isConnected()) {
                client.connect(options);
                System.out.println("✅ Connesso a MQTT senza TLS (" + BROKER_URL + ")");
            }
        } catch (MqttException e) {
            System.err.println("❌ Errore nella connessione MQTT: " + e.getMessage());

            if (e.getReasonCode() == MqttException.REASON_CODE_FAILED_AUTHENTICATION) {
                System.err.println("⛔ ERRORE: Username o password errati!");
            }
        }
    }

    public MqttClient getClient() {
        return client;
    }

    // 🔹 Metodo per chiudere la connessione
    public void disconnect() {
        try {
            if (client.isConnected()) {
                client.disconnect();
                System.out.println("🔌 MQTT disconnesso.");
            }
        } catch (MqttException e) {
            System.err.println("❌ Errore durante la disconnessione: " + e.getMessage());
        }
    }
}
