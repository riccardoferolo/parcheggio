package Principale.Parcheggio.MQTT;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component  // 🔥+
public class MqttConfig {
    private static final String BROKER_URL = "tcp://localhost:1883";
    private MqttClient client;

    public MqttConfig() {  //
        String clientId = "MqttClient-" + UUID.randomUUID(); // 🔥 Genera un clientId unico
        try {
            client = new MqttClient(BROKER_URL, clientId, new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            client.connect(options);
            System.out.println("✅ Connesso al broker MQTT come " + clientId);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public MqttClient getClient() {
        return client;
    }
}

