package Principale.Parcheggio.MQTT;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.springframework.stereotype.Component;

@Component
public class MqttConfig {
    private static MqttClient client;
    private static final String BROKER_URL = "tcp://localhost:1883";

    public MqttConfig() {
        try {
            if (client != null && client.isConnected()) {
                System.out.println("MQTT Client già connesso, non riconnetto.");
                return;
            }

            System.out.println("Inizializzazione MqttConfig...");

            String clientId = "MqttClient-" + java.util.UUID.randomUUID();
            client = new MqttClient(BROKER_URL, clientId, new MemoryPersistence());

            String username = "Utente1";
            String password = "ciao";
            char[] pwd = password.toCharArray();

            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(false);
            options.setUserName(username);
            options.setPassword(pwd);
            options.setAutomaticReconnect(true);

            System.out.println(" Tentativo di connessione al broker MQTT...");
            client.connect(options);
            System.out.println(" MQTT Connesso con successo!");

        } catch (MqttException e) {

        }
    }

    public MqttClient getClient() {
        return client;
    }
}


