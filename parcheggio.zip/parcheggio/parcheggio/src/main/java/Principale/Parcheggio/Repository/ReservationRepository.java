package Principale.Parcheggio.Repository;

import Principale.Parcheggio.Models.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    Optional<Reservation> findByChargeRequestId(long chargeRequestId);

    @Modifying
    @Transactional
    @Query(value = "ALTER TABLE Reservations ALTER COLUMN id RESTART WITH 1;\n", nativeQuery = true)
    void resetAutoIncrement();


    @Query("SELECT r FROM Reservation r WHERE r.ricarica = true")
    List<Reservation> findAllByRicaricaTrue();


    @Query("SELECT r.chargeRequest.Ora as ora, r.chargeRequest.Giorno as giorno, " +
            "SUM(CASE WHEN r.ricarica = true THEN 1 ELSE 0 END) as ricariche, " +
            "SUM(CASE WHEN r.ricarica IS NULL OR r.ricarica = false THEN 1 ELSE 0 END) as soste " +
            "FROM Reservation r " +
            "WHERE CURRENT_TIMESTAMP BETWEEN r.chargeRequest.Ora AND r.chargeRequest.OraFine " +
            "AND r.chargeRequest.Giorno = CURRENT_DATE " +
            "GROUP BY r.chargeRequest.Giorno, r.chargeRequest.Ora " +
            "ORDER BY r.chargeRequest.Giorno, r.chargeRequest.Ora")
    List<Object[]> Occupazione();

    @Query("SELECT COUNT(r) FROM Reservation r " +
            "WHERE CURRENT_TIMESTAMP BETWEEN r.chargeRequest.Ora AND r.chargeRequest.OraFine " +
            "AND r.chargeRequest.Giorno = CURRENT_DATE")
    long countPrenotazioniAttive();

    @Query("SELECT r FROM Reservation r WHERE r.user.username = :username")
    List<Reservation> findByUserUsername(@Param("username") String username);


    @Query("SELECT r FROM Reservation r WHERE r.user.username = :username AND r.Ritardo IS NULL")
    List<Reservation> findActiveReservationsWithoutDelay(@Param("username") String username);


    @Transactional
    @Query("SELECT r FROM Reservation r WHERE r.id = :id")
    Optional<Reservation> findReservationById(@Param("id") Long id);


    @Query("""
    SELECT r 
    FROM Reservation r 
    JOIN ChargeRequest c ON r.chargeRequest.id = c.id
    WHERE r.ricarica IS NULL 
      AND (
        c.Giorno < CURRENT_DATE
        OR (c.Giorno = CURRENT_DATE AND c.OraFine < CURRENT_TIME)
      )
""")
    List<Reservation> findExpiredReservations();




}


