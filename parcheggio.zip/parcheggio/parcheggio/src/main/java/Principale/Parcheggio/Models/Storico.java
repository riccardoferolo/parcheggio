package Principale.Parcheggio.Models;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.sql.Time;

@Entity
public class Storico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idStorico;

    private LocalDate Giorno;
    private Integer Percentuale_iniziale;
    private Integer Percentuale_richiesta;
    private Time durata;
    private Time Ora;
    private Time OraFine;
    private double Pagare;
    private String Targa;
    private Boolean ricarica;
    private Long userId;
    private long chargeRequest;
    private long payment;

    public Long getIdStorico() {
        return idStorico;
    }

    public void setIdStorico(Long idStorico) {
        this.idStorico = idStorico;
    }

    public long getChargeRequest() {
        return chargeRequest;
    }

    public void setChargeRequest(long chargeRequest) {
        this.chargeRequest = chargeRequest;
    }

    public long getPayment() {
        return payment;
    }

    public void setPayment(long payment) {
        this.payment = payment;
    }

    public LocalDate getGiorno() {
        return Giorno;
    }

    public Boolean getRicarica() {
        return ricarica;
    }

    public String getTarga() {
        return Targa;
    }

    public double getPagare() {
        return Pagare;
    }

    public Time getOraFine() {
        return OraFine;
    }

    public Time getOra() {
        return Ora;
    }

    public Time getDurata() {
        return durata;
    }

    public Integer getPercentuale_richiesta() {
        return Percentuale_richiesta;
    }

    public Integer getPercentuale_iniziale() {
        return Percentuale_iniziale;
    }

    public void setGiorno(LocalDate giorno) {
        Giorno = giorno;
    }

    public void setPercentuale_iniziale(Integer percentuale_iniziale) {
        Percentuale_iniziale = percentuale_iniziale;
    }

    public void setPercentuale_richiesta(Integer percentuale_richiesta) {
        Percentuale_richiesta = percentuale_richiesta;
    }

    public void setDurata(Time durata) {
        this.durata = durata;
    }

    public void setOra(Time ora) {
        Ora = ora;
    }

    public void setOraFine(Time oraFine) {
        OraFine = oraFine;
    }

    public void setPagare(double pagare) {
        Pagare = pagare;
    }

    public void setTarga(String targa) {
        Targa = targa;
    }

    public void setRicarica(Boolean ricarica) {
        this.ricarica = ricarica;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}


