package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.Models.ChargeRequest;
import Principale.Parcheggio.Services.ChargeRequestService;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

 /*
    "percentuale_inizio": 20,
  "percentuale_fine": 80,
  "nome": "MarioRossi"
     */

@RestController
@RequestMapping("/chargerequests")
public class ChargeRequestController {

    @Autowired
    private ChargeRequestService chargeRequestService;

    @PostMapping("/new")
    public ResponseEntity<?> createChargeRequest(@RequestBody Map<String, Object> requestBody) {
        try {
            String nome = (String) requestBody.get("username"); // Deve essere una stringa

            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd"); // Specifica il formato corretto
            String dataStr = (String) requestBody.get("giorno");
            LocalDate data;
            try {
                data = LocalDate.parse(dataStr, dateFormatter);
            } catch (Exception e) {
                return ResponseEntity.status(500).body("Errore nella data : " + e.getMessage());

            }

            String oraStr = (String) requestBody.get("ora");
            Time ora = Time.valueOf(oraStr); // Conversione in Time

            Integer percentuale_iniziale = (Integer) requestBody.get("Percentuale_iniziale"); // Deve essere un intero

            Integer percentuale_richiesta = (Integer) requestBody.get("Percentuale_richiesta"); // Deve essere un intero


            String dStr = (String) requestBody.get("durata");
            Time durata = Time.valueOf(dStr); // Conversione in Time

            String FStr = (String) requestBody.get("oraFine");
            Time oraFine = Time.valueOf(FStr); // Conversione in Time

            String Targa = (String) requestBody.get("Targa");

            Boolean r = (Boolean) requestBody.get("Ricarica");

            // Crea e salva la richiesta di carica
            ChargeRequest chargeRequest = chargeRequestService.createChargeRequest(nome, data, ora, durata, percentuale_iniziale, percentuale_richiesta, oraFine, Targa, r);
            return ResponseEntity.ok(chargeRequest);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Errore del server interno : " + e.getMessage());
        }
    }

    // Ottieni tutte le ChargeRequest
    @GetMapping("/all")
    public List<ChargeRequest> getAllChargeRequests() {
        return chargeRequestService.getAllChargeRequests();
    }

    // Ottieni ChargeRequest per ID
    @GetMapping("/charge-per-id")
    public ResponseEntity<ChargeRequest> getChargeRequestById(@RequestBody Long id) {
        Optional<ChargeRequest> chargeRequest = chargeRequestService.getChargeRequestById(id);
        return chargeRequest.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }


    @GetMapping("/user/trova-per-userid")
    public ResponseEntity<?> getRequestsByUserId(@RequestBody Long Userid) {
        try {
            List<ChargeRequest> chargeRequests = chargeRequestService.getChargeRequestsByUserId(Userid);

            // Controlla se ci sono richieste associate all'utente
            if (chargeRequests.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Nessuna richiesta trovata per l'id " + Userid);
            }

            return ResponseEntity.ok(chargeRequests);

        } catch (Exception e) {
            // Gestisce eventuali errori durante il processo
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore del server interno: " + e.getMessage());
        }
    }

    //------------------------------------------------------------------------------------

    @GetMapping("/calcola")
    public String calcolaRicarica(
            @RequestParam Integer percentualeIniziale,
            @RequestParam Integer percentualeFinale,
            @RequestParam double kwAuto) {
        return chargeRequestService.calcola(percentualeIniziale, percentualeFinale, kwAuto);
    }

    @GetMapping("/DisponibileRicarica")
    public Boolean isReservationAvailableRicarica(@RequestParam LocalDate giorno, @RequestParam Time ora, @RequestParam  Time oraFine){
        return chargeRequestService.isReservationAvailableRicarica(giorno, ora, oraFine);
    }

    @GetMapping("/DisponibileSosta")
    public Boolean isReservationAvailable(@RequestParam LocalDate giorno, @RequestParam Time ora, @RequestParam  Time oraFine){
        return chargeRequestService.isReservationAvailable(giorno, ora, oraFine);
    }

    @GetMapping("/TempoFineSosta")
    public Time findEarliestEndTimeSosta(@RequestParam LocalDate giorno,@RequestParam Time oraInizio,@RequestParam Time oraFine){
        return chargeRequestService.findEarliestEndTimeSosta(giorno, oraInizio, oraFine);
    }

    @GetMapping("/TempoFineRicarica")
    public Time findEarliestEndTimeRicarica(@RequestParam LocalDate giorno,@RequestParam Time oraInizio,@RequestParam Time oraFine) {
        return chargeRequestService.findEarliestEndTimeRicarica(giorno, oraInizio, oraFine);
    }



}

