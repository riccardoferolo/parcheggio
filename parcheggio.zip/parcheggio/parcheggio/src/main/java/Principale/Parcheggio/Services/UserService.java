package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.Ruolo;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final ChargeRequestRepository chargeRequestRepository;

    @Autowired
    public UserService(UserRepository userRepository, ChargeRequestRepository chargeRequestRepository) {
        this.userRepository = userRepository;
        this.chargeRequestRepository = chargeRequestRepository;
    }

    // Salva un nuovo utente
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // Metodo per trovare un utente per username
    public Optional<User> findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }


    public void registerUser(User user) throws IllegalArgumentException {

        // Verifica se l'email esiste già
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email già registrata");
        }

        if (!EmailValidator(user.getEmail())) {
            throw new IllegalArgumentException("Email non valida");
        }

        // Verifica se l'username esiste già
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username già esistente");
        }


        // Validazione della password
        validatePassword(user.getPassword());

        // Autocompila il ruolo e lascia che il database gestisca l'ID
        if (user.getRuolo() == null) {
            user.setRuolo(Ruolo.BASE); // Ruolo predefinito
        }

        // Imposta il saldo iniziale a 0 se non è stato specificato
        if (user.getSaldo() == 0) {
            user.setSaldo(0.0); // Imposta un saldo iniziale di 0
        }

        userRepository.save(user);
    }

    public void aggiornaSaldo(String username, double nuovoSaldo) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();
        user.setSaldo(user.getSaldo() + nuovoSaldo);
        userRepository.save(user);
    }

    public void aggiornaCarta(String username, String carta) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();
        user.setCarta_di_credito(carta);
        userRepository.save(user);
    }


    // Metodo per validare la password
    private void validatePassword(String password) {
        if (password.length() < 8) {
            throw new IllegalArgumentException("La password deve essere di almeno 8 caratteri");
        }
        if (!password.matches(".*\\d.*")) {
            throw new IllegalArgumentException("La password deve contenere almeno un numero");
        }
        if (!password.matches(".*[a-zA-Z].*")) {
            throw new IllegalArgumentException("La password deve contenere almeno una lettera");
        }

        if (!password.matches(".*[!@#\\$%\\^&\\*].*")) {
            throw new IllegalArgumentException("La password deve contenere almeno un carattere speciale (!@#$%^&*)");
        }

    }

    public User loginUser(String email, String password) {
        if (!EmailValidator(email)) { // Verifica se l'email è valida
            throw new IllegalArgumentException("Formato email non valido");
        }

        // Trova l'utente nel database
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Email non trovata"));

        // Verifica se la password è corretta
        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Password errata");
        }

        return user; // Restituisce l'utente se tutto è corretto
    }

    // Funzione per eliminare tutti gli utenti
    public void eliminaTuttiGliUtenti() {
        System.out.println("Eliminazione di tutti gli utenti dal database");
        userRepository.deleteAll();
        // Reset del contatore auto-increment per PostgreSQL
        userRepository.resetAutoIncrement();
        System.out.println("Contatore degli ID resettato a 1");
        System.out.println("Tutti gli utenti sono stati eliminati");
    }

    // Elimina un utente in base all'username e tutte le sue richieste di carica associate
    public void deleteUserByUsername(String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            chargeRequestRepository.deleteByUserId((long) userOptional.get().getId());
            userRepository.deleteByUsername(userOptional.get().getUsername());
        } else {
            throw new IllegalArgumentException("Utente non trovato");
        }
    }

    public User getUserById(long userId) {
        return userRepository.findUserById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Utente non trovato con ID: " + userId));
    }

    public Boolean EmailValidator(String email) {

        // Regex per un'email valida
        final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

        if (email == null || email.isEmpty()) {
            return false; // Email nulla o vuota non è valida
        }

        Pattern pattern = Pattern.compile(EMAIL_REGEX);
        Matcher matcher = pattern.matcher(email);
        return ((Matcher) matcher).matches(); // Restituisce true se l'email è valida

    }

    public static boolean isValidCreditCard(String cardNumber) {
        if (cardNumber == null || cardNumber.isEmpty()) {
            return false;
        }

        // Rimuove eventuali spazi o trattini
        cardNumber = cardNumber.replaceAll("\\s|-", "");

        // Verifica che sia composto solo da cifre
        if (!cardNumber.matches("\\d+")) {
            return false;
        }

        // Algoritmo di Luhn
        int sum = 0;
        boolean alternate = false;
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int n = Character.getNumericValue(cardNumber.charAt(i));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n -= 9;
                }
            }
            sum += n;
            alternate = !alternate;
        }

        // È valido se la somma è divisibile per 10
        return sum % 10 == 0;
    }
}


