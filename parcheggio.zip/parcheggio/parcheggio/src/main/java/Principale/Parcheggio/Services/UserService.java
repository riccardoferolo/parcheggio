package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.Ruolo;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Repository.ChargeRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final ChargeRequestRepository chargeRequestRepository;

    @Autowired
    public UserService(UserRepository userRepository, ChargeRequestRepository chargeRequestRepository) {
        this.userRepository = userRepository;
        this.chargeRequestRepository = chargeRequestRepository;
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }

    public Optional<User> findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }


    public void registerUser(User user) throws IllegalArgumentException {

        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email già registrata");
        }

        if (!EmailValidator(user.getEmail())) {
            throw new IllegalArgumentException("Email non valida");
        }

        if (userRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username già esistente");
        }

        validatePassword(user.getPassword());

        if (user.getRuolo() == null) {
            user.setRuolo(Ruolo.BASE);
        }

        if (user.getSaldo() == 0) {
            user.setSaldo(0.0);
        }

        userRepository.save(user);
    }

    public void registerAdmin(User user) throws IllegalArgumentException {
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new IllegalArgumentException("Email già registrata");
        }

        if (!EmailValidator(user.getEmail())) {
            throw new IllegalArgumentException("Email non valida");
        }

        if (userRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username già esistente");
        }

        validatePassword(user.getPassword());

        user.setRuolo(Ruolo.ADMIN);

        if (user.getSaldo() == 0) {
            user.setSaldo(0.0);
        }

        userRepository.save(user);
    }

    public void aggiornaSaldo(String username, double nuovoSaldo) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();
        user.setSaldo(user.getSaldo() + nuovoSaldo);
        userRepository.save(user);
    }

    public void aggiornaCarta(String username, String carta) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();
        user.setCarta_di_credito(carta);
        userRepository.save(user);
    }

    private void validatePassword(String password) {
        if (password.length() < 8) {
            throw new IllegalArgumentException("La password deve essere di almeno 8 caratteri");
        }
        if (!password.matches(".*\\d.*")) {
            throw new IllegalArgumentException("La password deve contenere almeno un numero");
        }
        if (!password.matches(".*[a-zA-Z].*")) {
            throw new IllegalArgumentException("La password deve contenere almeno una lettera");
        }

        if (!password.matches(".*[!@#\\$%\\^&\\*].*")) {
            throw new IllegalArgumentException("La password deve contenere almeno un carattere speciale (!@#$%^&*)");
        }

    }

    public User loginUser(String email, String password) {
        if (!EmailValidator(email)) {
            throw new IllegalArgumentException("Formato email non valido");
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Email non trovata"));

        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Password errata");
        }

        return user;
    }

    public void eliminaTuttiGliUtenti() {
        userRepository.deleteAll();

        userRepository.resetAutoIncrement();
    }

    public void deleteUserByUsername(String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            chargeRequestRepository.deleteByUserId((long) userOptional.get().getId());
            userRepository.deleteByUsername(userOptional.get().getUsername());
        } else {
            throw new IllegalArgumentException("Utente non trovato");
        }
    }

    public User getUserById(long userId) {
        return userRepository.findUserById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Utente non trovato con ID: " + userId));
    }

    public Boolean EmailValidator(String email) {
        final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

        if (email == null || email.isEmpty()) {
            return false;
        }

        Pattern pattern = Pattern.compile(EMAIL_REGEX);
        Matcher matcher = pattern.matcher(email);
        return ((Matcher) matcher).matches();

    }

    public void aggiornaAbbonamento(String username) {
        Optional<User> userOptional = userRepository.findByUsername(username);

        if (!userOptional.isPresent()) {
            throw new IllegalArgumentException("Utente non trovato");
        }

        User user = userOptional.get();

        if (user.getRuolo() == Ruolo.PREMIUM) {
            throw new IllegalArgumentException("L'utente è già PREMIUM");
        }

        double saldoAttuale = user.getSaldo();
        if (saldoAttuale < 20) {
            throw new IllegalArgumentException("Saldo insufficiente per aggiornare il ruolo a PREMIUM");
        }

        user.setSaldo(saldoAttuale - 20);
        user.setRuolo(Ruolo.PREMIUM);

        userRepository.save(user);
    }


}


