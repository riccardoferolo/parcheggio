package Principale.Parcheggio.Models;

public enum Ruolo {
    ADMIN,
    PREMIUM,
    BASE;

    public static Ruolo fromValue(String value) {
        for (Ruolo role : Ruolo.values()) {
            if (role.name().equalsIgnoreCase(value)) {
                return role;
            }
        }
        throw new IllegalArgumentException("Valore non valido per Ruolo: " + value);
    }

    public static boolean exists(String value) {
        for (Ruolo role : Ruolo.values()) {
            if (role.name().equalsIgnoreCase(value)) {
                return true;
            }
        }
        return false;
    }

}






