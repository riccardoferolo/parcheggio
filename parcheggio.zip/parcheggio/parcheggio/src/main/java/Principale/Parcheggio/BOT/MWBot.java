package Principale.Parcheggio.BOT;

import java.util.Optional;

import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Services.ReservationService;

public class MWBot implements Runnable {
    private final ReservationRepository reservationRepository;
    private final DelayedReservationRepository delayedReservationRepository;
    private final ReservationService reservationService;
    private volatile boolean running = true;

    public MWBot(ReservationRepository reservationRepository,
                 DelayedReservationRepository delayedReservationRepository,
                 ReservationService reservationService) {
        this.reservationRepository = reservationRepository;
        this.delayedReservationRepository = delayedReservationRepository;
        this.reservationService = reservationService;
    }

    private boolean isSpringContextActive() {
        // Metodo per verificare se il contesto di Spring è attivo
        return true; // Modifica in base alle tue necessità
    }

    private Reservation stampaCodaPrenotazioni(boolean printLog) {
        // Implementa questa logica per ottenere la prossima prenotazione
        return null; // Placeholder
    }

    private void AvviaBot() {
        try {
            while (running && !Thread.currentThread().isInterrupted()) {
                System.out.println("ciao");
                if (!isSpringContextActive()) {
                    return; // Se Spring sta chiudendo, interrompi il bot
                }

                Reservation x = stampaCodaPrenotazioni(true);
                if (x != null) {
                    Thread.sleep(2000);
                    if (x.getRicarica()) {
                        Optional<Reservation> r = reservationRepository.findById(x.getId());
                        if (r.isPresent()) {
                            DelayedReservation DR = new DelayedReservation(r.get());
                            delayedReservationRepository.save(DR);
                            reservationService.completeReservation(r.get());
                        }
                    } else {
                        reservationService.completeReservation(x);
                    }
                } else {
                    Thread.sleep(5000); // Attendi 5 secondi prima di controllare di nuovo
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Segnala l'interruzione correttamente
        } catch (Exception e) {
            if (running) { // Evita di loggare errori se il bot è stato fermato manualmente
                System.err.println("❌ Errore nel bot: " + e.getMessage());
            }
        }
    }

    @Override
    public void run() {
        AvviaBot();
    }

    public void stop() {
        running = false;
    }
}
