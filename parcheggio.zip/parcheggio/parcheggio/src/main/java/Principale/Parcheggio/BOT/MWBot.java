package Principale.Parcheggio.BOT;

import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Services.ReservationService;
import Principale.Parcheggio.ParcheggioApplication;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.TrustAllStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import java.sql.Time;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

@Service
public class MWBot implements Runnable {

    private final ReservationRepository reservationRepository;
    private final DelayedReservationRepository delayedReservationRepository;
    private final ReservationService reservationService;
    private final ParcheggioApplication application;

    @Value("${bot.token}")
    private String botToken;

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    @Autowired
    private ApplicationContext context; // Contesto di Spring per ottenere bean

    @Autowired
    public MWBot(ReservationRepository reservationRepository,
                 DelayedReservationRepository delayedReservationRepository,
                 ReservationService reservationService,
                 ParcheggioApplication application) {
        this.reservationRepository = reservationRepository;
        this.delayedReservationRepository = delayedReservationRepository;
        this.reservationService = reservationService;
        this.application = application;
    }

    private boolean isSpringContextActive() {
        return true; // Verifica se Spring è attivo (può essere migliorato)
    }

    public static RestTemplate createUnsafeRestTemplate() {
        try {
            // Ignora tutti i certificati SSL
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] x509Certificates, String s) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] x509Certificates, String s) {
                }

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            }}, new java.security.SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);

            // Configura RestTemplate con questo SSL ignorato
            HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
            return new RestTemplate(factory);

        } catch (Exception e) {
            throw new RuntimeException("Errore nella configurazione SSL: " + e.getMessage(), e);
        }
    }

    @Async("taskExecutor")
    @Transactional
    public void AvviaBot() {
        try {
            while (true) {
                if (!isSpringContextActive()) {
                    return; // Se Spring sta chiudendo, interrompi il bot
                }

                Reservation x = application.stampaCodaPrenotazioni(true);

                if (x != null) {
                    // Conversione da stringa a Duration
                    Time durata = x.getChargeRequest().getdurata();

                    long millis = convertTimeToMilliseconds(durata);

                    System.out.println("INIZIO LA CARICA DELL'AUTO CON TARGA " + x.getChargeRequest().getTarga());
                    Thread.sleep(millis); // Ritardo per evitare richieste continue
                    System.out.println("HO FINITO LA RICARICA DELL'AUTO CON TARGA " + x.getChargeRequest().getTarga());
                    application.apriSbarra();
                    System.out.println("APRO LA SBARRA PER FAR USCIRE L'AUTO CON TARGA " + x.getChargeRequest().getTarga());
                    Thread.sleep(5000);
                    application.chiudiSbarra();
                    System.out.println("CHIUDO LA SBARRA");
                    application.OccupazioneLampadine();
                    try {
                        // Creazione di un RestTemplate normale
                        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

                        if (Boolean.TRUE.equals(x.getRitardo())) {
                            HttpHeaders headers = new HttpHeaders();
                            headers.set("Authorization", "Bearer " + botToken);
                            headers.setContentType(MediaType.APPLICATION_JSON);

                            HttpEntity<Reservation> entity = new HttpEntity<>(x, headers);

                            ResponseEntity<Void> response = restTemplate.exchange(
                                    "https://localhost:8443/reservations/RitardoTrue",
                                    HttpMethod.POST,
                                    entity,
                                    Void.class
                            );
                        } else {
                            HttpHeaders headers = new HttpHeaders();
                            headers.set("Authorization", "Bearer " + botToken);
                            headers.setContentType(MediaType.APPLICATION_JSON);

                            HttpEntity<Reservation> entity = new HttpEntity<>(x, headers);

                            ResponseEntity<Void> response = restTemplate.exchange(
                                    "https://localhost:8443/reservations/RitardoFalse",
                                    HttpMethod.POST,
                                    entity,
                                    Void.class
                            );
                        }
                    } catch (Exception e) {
                        System.err.println("❌ Errore durante la chiamata alle API: " + e.getMessage());
                        e.printStackTrace();
                    }
                } else {
                    System.out.println("NESSUNA AUTO DA RICARICARE, RIPROVO TRA 1 MINUTO....");
                    Thread.sleep(60000);
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            System.err.println("❌ Errore nel bot: " + e.getMessage());
        }
    }


    @Override
    public void run() {
        MWBot proxyBean = context.getBean(MWBot.class); // Ottieni il bean tramite il contesto Spring
        proxyBean.AvviaBot();
    }

    /**
     * Metodo per calcolare i millisecondi a partire da un oggetto java.sql.Time.
     * @param time Oggetto java.sql.Time
     * @return Durata in millisecondi
     */
    public static long convertTimeToMilliseconds(Time time) {
        // Ottieni ore, minuti e secondi dal Time
        int hours = time.getHours();      // Ore
        int minutes = time.getMinutes(); // Minuti
        int seconds = time.getSeconds(); // Secondi

        // Converte tutto in millisecondi
        return (hours * 3600 + minutes * 60 + seconds) * 1000L;
    }

}
