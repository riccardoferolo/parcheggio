package Principale.Parcheggio.BOT;

import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import Principale.Parcheggio.Services.ReservationService;
import Principale.Parcheggio.ParcheggioApplication;
import Principale.Parcheggio.MQTT.MqttPublisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.sql.Time;

@Service
public class MWBot implements Runnable {

    private final ReservationRepository reservationRepository;
    private final DelayedReservationRepository delayedReservationRepository;
    private final ReservationService reservationService;
    private final ParcheggioApplication application;

    @Value("${bot.token}")
    private String botToken;

    @Autowired
    private HttpsRestTemplateConfig httpsRestTemplateConfig;

    @Autowired
    private ApplicationContext context;

    @Autowired
    private MqttPublisher mqttPublisher;

    @Autowired
    public MWBot(ReservationRepository reservationRepository,
                 DelayedReservationRepository delayedReservationRepository,
                 ReservationService reservationService,
                 ParcheggioApplication application) {
        this.reservationRepository = reservationRepository;
        this.delayedReservationRepository = delayedReservationRepository;
        this.reservationService = reservationService;
        this.application = application;
    }

    private boolean isSpringContextActive() {
        return true;
    }

    @Async("taskExecutor")
    @Transactional
    public void AvviaBot() {
        try {
            while (true) {
                if (!isSpringContextActive()) {
                    return;
                }

                Reservation x = application.stampaCodaPrenotazioni(true);

                if (x != null) {
                    Time durata = x.getChargeRequest().getdurata();
                    long millis = convertTimeToMilliseconds(durata);

                    mqttPublisher.publishMessage("bot/charging", "Inizio ricarica per l'auto con targa: " + x.getChargeRequest().getTarga() + "della durata di:" + x.getChargeRequest().getdurata());
                    System.out.println("Inizio ricarica per l'auto con targa: " + x.getChargeRequest().getTarga() + "della durata di:" + x.getChargeRequest().getdurata());
                    Thread.sleep(millis);
                    mqttPublisher.publishMessage("bot/charging", "Fine ricarica per l'auto con targa: " + x.getChargeRequest().getTarga());
                    System.out.println("Fine ricarica per l'auto con targa: " + x.getChargeRequest().getTarga());

                    application.apriSbarra();
                    mqttPublisher.publishMessage("bot/gate", "Sbarra aperta per l'auto con targa: " + x.getChargeRequest().getTarga());
                    Thread.sleep(5000);
                    application.chiudiSbarra();
                    mqttPublisher.publishMessage("bot/gate", "Sbarra chiusa dopo l'uscita dell'auto con targa: " + x.getChargeRequest().getTarga());
                    mqttPublisher.publishMessage("bot/lights", "Aggiornamento stato lampadine dopo la ricarica.");

                    try {
                        RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
                        HttpHeaders headers = new HttpHeaders();
                        headers.set("Authorization", "Bearer " + botToken);
                        headers.setContentType(MediaType.APPLICATION_JSON);
                        HttpEntity<Reservation> entity = new HttpEntity<>(x, headers);

                        String url = "https://localhost:8443/reservations/lampadine";
                        ResponseEntity<Reservation> response = restTemplate.exchange(
                                url, HttpMethod.POST, entity, Reservation.class);

                        url = Boolean.TRUE.equals(x.getRitardo()) ?
                                "https://localhost:8443/reservations/RitardoTrue" :
                                "https://localhost:8443/reservations/RitardoFalse";

                        restTemplate.exchange(url, HttpMethod.POST, entity, Void.class);
                    } catch (Exception e) {
                        mqttPublisher.publishMessage("errors/bot", "Errore durante la chiamata alle API: " + e.getMessage());
                        System.err.println(" Errore durante la chiamata alle API: " + e.getMessage());
                    }
                } else {
                    System.out.println("Nessuna auto da ricaricare, riprovo tra 1 minuto");
                    mqttPublisher.publishMessage("bot/charging", "Nessuna auto da ricaricare, riprovo tra 1 minuto.");
                    Thread.sleep(60000);
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            mqttPublisher.publishMessage("errors/bot", "Bot interrotto: " + e.getMessage());
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/bot", "Errore generale nel bot: " + e.getMessage());
            System.err.println(" Errore nel bot: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        MWBot proxyBean = context.getBean(MWBot.class);
        proxyBean.AvviaBot();
    }

    public static long convertTimeToMilliseconds(Time time) {
        int hours = time.getHours();
        int minutes = time.getMinutes();
        int seconds = time.getSeconds();
        return (hours * 3600 + minutes * 60 + seconds) * 1000L;
    }
}

