package Principale.Parcheggio.BOT;

import java.util.List;
import java.util.Optional;

import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.ParcheggioApplication;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Services.ReservationService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;

public class MWBot implements Runnable {
    private final ReservationRepository reservationRepository;
    private final DelayedReservationRepository delayedReservationRepository;
    private final ReservationService reservationService;
    private final ParcheggioApplication application;
    private volatile boolean running = true;

    public MWBot(ReservationRepository reservationRepository,
                 DelayedReservationRepository delayedReservationRepository,
                 ReservationService reservationService, ParcheggioApplication application) {
        this.reservationRepository = reservationRepository;
        this.delayedReservationRepository = delayedReservationRepository;
        this.reservationService = reservationService;
        this.application = application;
    }

    private boolean isSpringContextActive() {
        // Metodo per verificare se il contesto di Spring è attivo
        return true; // Modifica in base alle tue necessità
    }

    @Transactional
    public void AvviaBot() {
        try {
            while (running && !Thread.currentThread().isInterrupted()) {
                if (!isSpringContextActive()) {
                    return; // Se Spring sta chiudendo, interrompi il bot
                }

                Reservation x = application.stampaCodaPrenotazioni(true);
                System.out.println(x.getChargeRequest().getGiorno());
                if (x != null) {
                    Thread.sleep(10000);
                    application.GestisciReservation(x);
                } else {
                    Thread.sleep(5000); // Attendi 5 secondi prima di controllare di nuovo
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Segnala l'interruzione correttamente
        } catch (Exception e) {
            if (running) { // Evita di loggare errori se il bot è stato fermato manualmente
                System.err.println("❌ Errore nel bot: " + e.getMessage());
            }
        }
    }

    @Override
    public void run() {
        AvviaBot();
    }

    public void stop() {
        running = false;
    }
}
