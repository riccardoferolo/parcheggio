package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Models.Storico;
import Principale.Parcheggio.Models.ChargeRequest;
import Principale.Parcheggio.Models.Payment;
import Principale.Parcheggio.Repository.StoricoRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Principale.Parcheggio.Repository.ReservationRepository;

import java.util.Optional;

@Service
public class StoricoService {

    @Autowired
    private StoricoRepository storicoRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    public void saveToStorico(ChargeRequest chargeRequest, Payment payment) {
        Storico storico = new Storico();
        storico.setChargeRequest(chargeRequest.getId());
        storico.setPayment(payment.getId());

        storico.setGiorno(chargeRequest.getGiorno());
        storico.setPercentuale_iniziale(chargeRequest.getpercentuale_iniziale());
        storico.setPercentuale_richiesta(chargeRequest.getPercentuale_richiesta());
        storico.setDurata(chargeRequest.getdurata());
        storico.setOra(chargeRequest.getOra());
        storico.setOraFine(chargeRequest.getOraFine());
        storico.setPagare(chargeRequest.getPagare());
        storico.setTarga(chargeRequest.getTarga());
        storico.setRicarica(chargeRequest.getRicarica());
        storico.setUserId(chargeRequest.getId());

        storicoRepository.save(storico);
    }

    @Transactional
    public void completeReservation(long reservationId) {
        Optional<Reservation> resOpt = reservationRepository.findById(reservationId);
        if (!resOpt.isPresent()) {
            return;
        }

        Reservation reservation = resOpt.get();

        ChargeRequest chargeRequest = reservation.getChargeRequest();
        Payment payment = reservation.getPayment();

        if (chargeRequest == null || payment == null) {
            return;
        }

        saveToStorico(chargeRequest, payment);

        reservationRepository.deleteById(reservationId);
    }


}


