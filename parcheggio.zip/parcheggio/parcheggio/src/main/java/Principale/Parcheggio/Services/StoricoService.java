package Principale.Parcheggio.Services;

import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Models.Storico;
import Principale.Parcheggio.Models.ChargeRequest;
import Principale.Parcheggio.Models.Payment;
import Principale.Parcheggio.Repository.StoricoRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Principale.Parcheggio.Repository.ReservationRepository;

@Service
public class StoricoService {

    @Autowired
    private StoricoRepository storicoRepository;

    @Autowired
    private ReservationRepository reservationRepository;
    /**
     * Salva una ChargeRequest nello storico con il pagamento associato.
     *
     * @param chargeRequest La ChargeRequest da spostare nello storico.
     * @param payment Il pagamento associato alla ChargeRequest.
     */
    public void saveToStorico(ChargeRequest chargeRequest, Payment payment) {
        Storico storico = new Storico();
        storico.setChargeRequest(chargeRequest.getId());
        storico.setPayment(payment.getId());

        // Copia i campi della ChargeRequest nel Storico
        storico.setGiorno(chargeRequest.getGiorno());
        storico.setPercentuale_iniziale(chargeRequest.getpercentuale_iniziale());
        storico.setPercentuale_richiesta(chargeRequest.getPercentuale_richiesta());
        storico.setDurata(chargeRequest.getdurata());
        storico.setOra(chargeRequest.getOra());
        storico.setOraFine(chargeRequest.getOraFine());
        storico.setPagare(chargeRequest.getPagare());
        storico.setTarga(chargeRequest.getTarga());
        storico.setRicarica(chargeRequest.getRicarica());
        storico.setUserId(chargeRequest.getId());

        // Salva lo Storico
        storicoRepository.save(storico);
    }

    public void deleteAllStorico() {
        storicoRepository.deleteAll();
    }

    @Transactional
    public void completeReservation(long reservationId) {
        // Recupera la Reservation
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("Reservation non trovata"));

        // Recupera la ChargeRequest associata
        ChargeRequest chargeRequest = reservation.getChargeRequest();

        // Recupera il Payment associato
        Payment payment = reservation.getPayment();

        // Salva la ChargeRequest nello Storico
        saveToStorico(chargeRequest, payment);

        // Elimina la Reservation
        reservationRepository.deleteById(reservationId);

        System.out.println("Reservation eliminata e ChargeRequest salvata nello Storico.");
    }

}


