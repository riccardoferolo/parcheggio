package Principale.Parcheggio;

import Principale.Parcheggio.Models.*;

import java.io.*;
import java.text.ParseException;
import Principale.Parcheggio.Repository.*;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;
import java.util.List;

@SpringBootApplication(scanBasePackages = {
		"Principale.Parcheggio.Controllers",
		"Principale.Parcheggio.DTO",
		"Principale.Parcheggio.Models",
		"Principale.Parcheggio.Repository",
		"Principale.Parcheggio.Services",
		"Principale.Parcheggio.Security",
		"Principale.Parcheggio.MQTT"

})
public class ParcheggioApplication {

	@Autowired
	private ApplicationContext applicationContext;

	Scanner s = new Scanner(System.in);

	@Autowired
	private ParkingSpotRepository parkingSpotRepository;

	@Autowired
	private HttpsRestTemplateConfig httpsRestTemplateConfig;


	String UsernameHUE;

	private String token; // Variabile globale per il token JWT

	@Value("${bot.token}")
	private String botToken;
    @Autowired
    private StoricoRepository storicoRepository;

	public static void main(String[] args) throws ParseException {
		int scelta;
		//SpringApplication.run(ParcheggioApplication.class, args);
		Scanner sc = new Scanner(System.in);

		// Avvia il contesto di Spring e ottieni un'istanza gestita di ParcheggioApplication
		System.out.println("🚀 Metodo main avviato!"); // Debug iniziale
		ApplicationContext context = SpringApplication.run(ParcheggioApplication.class, args);
		System.out.println("✅ Contesto Spring avviato correttamente.");

		// Ottieni l'istanza di ParcheggioApplication dal contesto di Spring
		ParcheggioApplication app = context.getBean(ParcheggioApplication.class);

		app.initializeParkingSpot();

		do {
			// Mostra il menu
			System.out.println("MENU:");
			System.out.println("1. avvia emulatore");
			System.out.println("2. avvia App Sbarra");
			System.out.println("3. apri sbarra");
			System.out.println("4. chiudi sbarra");
			System.out.println("5. Registra Admin");
			System.out.println("6. avvia Bot");
			System.out.println("10. Esci");
			System.out.print("Scegli un'opzione: ");

			// Gestisci input dell'utente
			while (!sc.hasNextInt()) {
				System.out.println("Per favore, inserisci un numero valido.");
				sc.next(); // Consuma l'input non valido
			}
			scelta = sc.nextInt();
			sc.nextLine(); // Pulisce il buffer dopo nextInt()
			String x;
			switch (scelta) {
				case 1:
					app.avviaHueEmulator();
					break;

				case 2:
					app.eseguiSbarra();
					break;

				case 3:
					app.apriSbarra();
					break;

				case 4:
					app.chiudiSbarra();
					break;

				case 5:
					app.registraAdmin();
					break;

				case 6:
					app.startBot();
					break;

				case 10:
					break;

				default:
					System.out.println("Errore: opzione non valida.");
			}
		} while (scelta != 10);
	}

	public void initializeParkingSpot() {
		if (parkingSpotRepository.count() > 0) { // Controlla se la tabella è vuota
			List<ParkingSpot> x = parkingSpotRepository.findAll();
			for (ParkingSpot p : x) {
				parkingSpotRepository.delete(p);
			}
			parkingSpotRepository.resetAutoIncrement();
			//System.out.println("Record aggiunto con id=1 e posti_totali=2");
		}
		ParkingSpot parkingSpot = new ParkingSpot();
		parkingSpot.setId(1); // ID predefinito
		parkingSpot.setPosti_totali_ricarica(1);
		parkingSpot.setPosti_totali_sosta(3);
		parkingSpotRepository.save(parkingSpot);
	}

	public String registraAdmin() {
		int errore = 0;
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String apiUrl = "https://localhost:8443/api/users/register-admin";

		Map<String, Object> requestBody = new HashMap<>();
		String x = "";

		do {
			try {
				errore = 0;

				System.out.print("Inserisci un username: ");
				requestBody.put("username", s.nextLine().trim());

				System.out.print("Inserisci una password: ");
				requestBody.put("password", s.nextLine().trim());

				System.out.print("Inserisci un'email: ");
				requestBody.put("email", s.nextLine().trim());

				// Invio della richiesta POST
				x = restTemplate.postForObject(apiUrl, requestBody, String.class);

			} catch (Exception e) {
				System.out.println("Errore durante la registrazione: " + e.getMessage());
				errore = 1;
			}

		} while (errore == 1);

		return x;
	}

	public Reservation stampaCodaPrenotazioni(Boolean bot) {
		String tk = bot ? botToken : token;

		if (tk == null || tk.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
		}

		String username;
		String ruolo;

		/*
		try {
			username = jwtUtil.validateToken(tk);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.out.println("Errore: Utente non trovato.");
			}

			System.out.println("Utente autenticato con ruolo ADMIN: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
		}
*/

		// Crea un nuovo RestTemplate con configurazione personalizzata
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		// Verifica se Spring è ancora attivo
		if (!isSpringContextActive()) {
			System.out.println("⚠️ Spring sta chiudendo, interrompendo richiesta.");
			return null;
		}

		// Configura le intestazioni della richiesta con il token
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + tk);  // Aggiungi il token JWT
		headers.set("Content-Type", "application/json");

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		try {
			String url = "https://localhost:8443/reservations/coda";
			ResponseEntity<Reservation> response = restTemplate.exchange(
					url, HttpMethod.GET, requestEntity, Reservation.class);

			if (response.getStatusCode() == HttpStatus.NO_CONTENT) {
				System.out.println("⚠️ Nessuna prenotazione trovata nella coda.");
				return null;
			}

			return response.getBody();

		} catch (Exception e) {
			System.out.println("❌ Errore durante il recupero delle prenotazioni: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	private boolean isSpringContextActive() {
		if (applicationContext instanceof ConfigurableApplicationContext) {
			return ((ConfigurableApplicationContext) applicationContext).isRunning();
		}
		return false;
	}

	public void avviaHueEmulator() {
		try {
			String[] command = {
					"java", "-jar",
					"HueEmulator-v0.8.jar"
			};

			File projectRoot = new File(".").getCanonicalFile(); // Salire dalla directory corrente 'src' a 'Parcheggio'
			File emulatorDirectory = new File(projectRoot, "Hue-Emulator");

			ProcessBuilder processBuilder = new ProcessBuilder(command);
			processBuilder.directory(emulatorDirectory);
			processBuilder.redirectErrorStream(true);

			Process process = processBuilder.start();

			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line;
			System.out.println("Log dell'emulatore:");

			// Attendi che l'emulatore sia pronto e che il "Link Button" sia premuto
			aspettaEmulatore();

			// Registra un nuovo utente e ottieni l'username
			UsernameHUE = registraUtenteHUE();
			if (UsernameHUE == null) {
				throw new IllegalStateException("Impossibile registrare un utente. Controlla l'emulatore.");
			}

			System.out.println("L'emulatore è stato avviato con successo. Username: " + UsernameHUE);

			// Pulisci le lampadine
			pulisciLampadine();
		} catch (Exception e) {
			System.err.println("Errore durante l'avvio dell'emulatore Hue: " + e.getMessage());
		}
	}

	private void aspettaEmulatore() {
		String hueBridgeUrl = "http://localhost:8000/api";
		RestTemplate restTemplate = new RestTemplate();
		boolean pronto = false;

		System.out.println("Attesa che l'emulatore sia pronto (premi 'Start' nell'emulatore e poi il pulsante 'Link Button')...");

		while (!pronto) {
			try {
				// Tentativo di registrare un utente per verificare lo stato del pulsante "Link Button"
				Map<String, String> requestBody = new HashMap<>();
				requestBody.put("devicetype", "my_hue_app");

				ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
						hueBridgeUrl,
						HttpMethod.POST,
						new HttpEntity<>(requestBody),
						new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
						}
				);

				List<Map<String, Map<String, String>>> body = response.getBody();
				if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
					System.out.println("Pulsante 'Link Button' premuto. L'emulatore è pronto.");
					pronto = true;
					break;
				}
			} catch (Exception e) {
				if (e.getMessage().contains("link button not pressed")) {
					System.out.println("Il pulsante 'Link Button' non è stato premuto. Aspetto...");
				} else {
					System.out.println("L'emulatore non è ancora pronto. Riprovo tra 2 secondi...");
				}
			}

			try {
				Thread.sleep(2000); // Aspetta 2 secondi prima di riprovare
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
				throw new RuntimeException("Attesa interrotta.", ex);
			}
		}
	}

	private void pulisciLampadine() {
		String hueBridgeUrl = "http://localhost:8000/api/" + UsernameHUE + "/lights";
		RestTemplate restTemplate = new RestTemplate();

		try {
			ResponseEntity<String> response = restTemplate.exchange(
					hueBridgeUrl,
					HttpMethod.GET,
					null,
					String.class
			);

			System.out.println("Risposta API grezza: " + response.getBody());

			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> lights = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {
			});

			if (lights != null) {
				for (String id : lights.keySet()) {
					int lampId = Integer.parseInt(id);
					if (lampId > 2) {
						// Spegni la lampadina
						try {
							String lampUrl = hueBridgeUrl + "/" + lampId + "/state";

							Map<String, Object> lampState = new HashMap<>();
							lampState.put("on", false); // Spegni la lampadina

							HttpHeaders headers = new HttpHeaders();
							headers.setContentType(MediaType.APPLICATION_JSON);
							HttpEntity<Map<String, Object>> request = new HttpEntity<>(lampState, headers);

							restTemplate.put(lampUrl, request);
							System.out.println("Lampadina " + lampId + " spenta.");
						} catch (Exception e) {
							System.err.println("Errore durante lo spegnimento della lampadina " + lampId + ": " + e.getMessage());
						}
					}
				}
			}
		} catch (Exception e) {
			System.err.println("Errore durante la pulizia delle lampadine: " + e.getMessage());
		}
	}

	public void OccupazioneLampadine(){
		String tk = botToken;

		if (tk == null || tk.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
		}

		String username;
		String ruolo;

		/*
		try {
			username = jwtUtil.validateToken(tk);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.out.println("Errore: Utente non trovato.");
			}

			System.out.println("Utente autenticato con ruolo ADMIN: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
		}
*/

		// Crea un nuovo RestTemplate con configurazione personalizzata
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		// Verifica se Spring è ancora attivo
		if (!isSpringContextActive()) {
			System.out.println("⚠️ Spring sta chiudendo, interrompendo richiesta.");
		}

		// Configura le intestazioni della richiesta con il token
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + tk);  // Aggiungi il token JWT
		headers.set("Content-Type", "application/json");

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		try {
			String url = "https://localhost:8443/reservations/lampadine";
			ResponseEntity<Reservation> response = restTemplate.exchange(
					url, HttpMethod.POST, requestEntity, Reservation.class);

			if (response.getStatusCode() == HttpStatus.NO_CONTENT) {
				System.out.println("⚠️ Nessuna prenotazione trovata nella coda.");
			}

		} catch (Exception e) {
			System.out.println("❌ Errore durante il recupero delle prenotazioni: " + e.getMessage());
			e.printStackTrace();
		}
	}

	private String registraUtenteHUE() {
		String hueBridgeUrl = "http://localhost:8000/api";
		RestTemplate restTemplate = new RestTemplate();

		Map<String, String> requestBody = new HashMap<>();
		requestBody.put("devicetype", "my_hue_app");

		try {
			ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
					hueBridgeUrl,
					HttpMethod.POST,
					new HttpEntity<>(requestBody),
					new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
					}
			);

			// Estrai il nome utente dalla risposta
			List<Map<String, Map<String, String>>> body = response.getBody();
			if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
				String username = body.get(0).get("success").get("username");
				System.out.println("Utente registrato con successo: " + username);
				return username;
			} else {
				System.err.println("Errore durante la registrazione dell'utente. Risposta API: " + body);
			}
		} catch (Exception e) {
			System.err.println("Errore durante la registrazione dell'utente: " + e.getMessage());
		}
		return null;
	}

	public void eseguiSbarra() {
		try {
			File directory = new File(System.getProperty("user.dir"), "Sbarra");

			// Esegui 'mvn clean install'
			ProcessBuilder cleanInstallBuilder = new ProcessBuilder("mvn", "clean", "install");
			cleanInstallBuilder.directory(directory);
			cleanInstallBuilder.redirectErrorStream(true);
			Process cleanInstallProcess = cleanInstallBuilder.start();
			int exitCode = cleanInstallProcess.waitFor(); // Aspetta che termini
			if (exitCode != 0) {
				System.err.println("Errore durante 'mvn clean install': Codice di uscita " + exitCode);
				return;
			}

			// Esegui 'mvn exec:java' in un nuovo thread
			new Thread(() -> {
				try {
					ProcessBuilder execJavaBuilder = new ProcessBuilder("mvn", "exec:java");
					execJavaBuilder.directory(directory);
					execJavaBuilder.redirectErrorStream(true);
					Process execJavaProcess = execJavaBuilder.start();
					execJavaProcess.waitFor(); // Aspetta la fine del processo
				} catch (IOException | InterruptedException e) {
					e.printStackTrace();
					System.err.println("Errore durante l'esecuzione di 'mvn exec:java': " + e.getMessage());
				}
			}).start();

		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
			System.err.println("Errore durante l'esecuzione di 'mvn clean install': " + e.getMessage());
		}
	}

	public void apriSbarra() {
		String barrierOpenUrl = "http://localhost:9090/api/barrier/open";
		RestTemplate restTemplate = new RestTemplate();

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<>(null, headers);

			ResponseEntity<String> response = restTemplate.exchange(
					barrierOpenUrl,
					HttpMethod.POST,
					request,
					String.class
			);
			System.out.println("Sbarra aperta. Risposta API: " + response.getBody());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Errore durante l'apertura della sbarra: " + e.getMessage());
		}
	}

	public void chiudiSbarra() {
		String barrierCloseUrl = "http://localhost:9090/api/barrier/close";
		RestTemplate restTemplate = new RestTemplate();

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<>(null, headers);

			ResponseEntity<String> response = restTemplate.exchange(
					barrierCloseUrl,
					HttpMethod.POST,
					request,
					String.class
			);
			System.out.println("Sbarra chiusa. Risposta API: " + response.getBody());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Errore durante la chiusura della sbarra: " + e.getMessage());
		}
	}

	private void startBot() {
		try {
			// Ottieni il percorso assoluto della directory del progetto
			String projectDir = System.getProperty("user.dir"); // Directory corrente del progetto

			// Costruisci il percorso completo del JAR
			String jarPath = projectDir + "/target/mwbot.jar";

			// Rilevamento del sistema operativo
			String os = System.getProperty("os.name").toLowerCase();

			ProcessBuilder processBuilder;

			if (os.contains("win")) {
				// Windows: utilizza cmd.exe per aprire una nuova finestra di terminale
				processBuilder = new ProcessBuilder("cmd.exe", "/c", "start cmd /k java -jar mwbot.jar");
			} else if (os.contains("mac")) {
				// macOS: utilizza AppleScript per aprire una nuova scheda del terminale
				processBuilder = new ProcessBuilder(
						"osascript", "-e",
						"tell application \"Terminal\" to do script \"java -jar " + jarPath + "\""
				);
			} else if (os.contains("nix") || os.contains("nux")) {
				// Linux: utilizza gnome-terminal o x-terminal-emulator per aprire una nuova finestra
				processBuilder = new ProcessBuilder("sh", "-c", "gnome-terminal -- java -jar " + jarPath);
			} else {
				throw new UnsupportedOperationException("Sistema operativo non supportato");
			}

			// Avvia il processo
			processBuilder.start();
			System.out.println("✅ Bot avviato correttamente in una nuova scheda!");

			// Ritardo prima di tornare al menu
			Thread.sleep(1000); // Ritardo di 1 secondo (1000 millisecondi)
			System.out.println("🔄 Ritorno al menu...");
		} catch (IOException e) {
			System.err.println("❌ Errore durante l'avvio del bot: " + e.getMessage());
			e.printStackTrace();
		} catch (InterruptedException e) {
			System.err.println("❌ Errore durante l'attesa: " + e.getMessage());
			Thread.currentThread().interrupt();
		}
	}

}
