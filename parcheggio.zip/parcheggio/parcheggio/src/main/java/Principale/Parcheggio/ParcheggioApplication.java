package Principale.Parcheggio;

import Principale.Parcheggio.Models.*;

import java.io.*;
import java.nio.file.Paths;
import java.text.ParseException;
import Principale.Parcheggio.Repository.*;
import Principale.Parcheggio.Security.JwtUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.core.env.Environment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;
import java.util.List;

@SpringBootApplication(scanBasePackages = {
		"Principale.Parcheggio.Controllers",
		"Principale.Parcheggio.DTO",
		"Principale.Parcheggio.Models",
		"Principale.Parcheggio.Repository",
		"Principale.Parcheggio.Services",
		"Principale.Parcheggio.Security",
		"Principale.Parcheggio.MQTT"

})
@EnableScheduling
public class ParcheggioApplication {

	@Autowired
	private ApplicationContext applicationContext;

	Scanner s = new Scanner(System.in);

	@Autowired
	private ParkingSpotRepository parkingSpotRepository;

	@Autowired
	private HttpsRestTemplateConfig httpsRestTemplateConfig;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private Environment environment; // 🔥 Recupera i profili attivi

	String UsernameHUE;

	private String token;

	@Value("${bot.token}")
	private String botToken;

    @Autowired
    private StoricoRepository storicoRepository;

    @Autowired
    private UserRepository userRepository;

	public static void main(String[] args) throws ParseException {
		int scelta;

		Scanner sc = new Scanner(System.in);

		ApplicationContext context = SpringApplication.run(ParcheggioApplication.class, args);

		ParcheggioApplication app = context.getBean(ParcheggioApplication.class);

		if(!app.isTestProfileActive()){
			//app.startMosquitto();
			//app.avviaHueEmulator();
			//app.eseguiSbarra();
			//app.startBot();
			app.registraAdmin();
			app.initializeParkingSpot();

			do {
				System.out.println("MENU:");
				System.out.println("1. avvia emulatore");
				System.out.println("2. avvia App Sbarra");
				System.out.println("3. apri sbarra");
				System.out.println("4. chiudi sbarra");
				System.out.println("6. avvia Bot");
				System.out.println("7. start mosquitto");
				System.out.print("Scegli un'opzione: ");

				while (!sc.hasNextInt()) {
					System.out.println("Per favore, inserisci un numero valido.");
					sc.next();
				}
				scelta = sc.nextInt();
				sc.nextLine();
				switch (scelta) {
					case 1:
						app.avviaHueEmulator();
						break;

					case 2:
						app.eseguiSbarra();
						break;

					case 3:
						app.apriSbarra();
						break;

					case 4:
						app.chiudiSbarra();
						break;

					case 5:
						app.registraAdmin();
						break;

					case 6:
						app.startBot();
						break;

					case 7:
						app.startMosquitto();
						break;

					case 10:
						break;

					default:
						System.out.println("Errore: opzione non valida.");
				}
			} while (scelta != 10);
		}
	}

	public boolean isTestProfileActive() {
		return Arrays.asList(environment.getActiveProfiles()).contains("test");
	}

	public void initializeParkingSpot() {
		if (parkingSpotRepository.count() > 0) {
			List<ParkingSpot> x = parkingSpotRepository.findAll();
			for (ParkingSpot p : x) {
				parkingSpotRepository.delete(p);
			}
			parkingSpotRepository.resetAutoIncrement();
		}
		ParkingSpot parkingSpot = new ParkingSpot();
		parkingSpot.setId(1);
		parkingSpot.setPosti_totali_ricarica(1);
		parkingSpot.setPosti_totali_sosta(3);
		parkingSpotRepository.save(parkingSpot);
	}

	public String registraAdmin() {
		int errore = 0;
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String apiUrl = "https://localhost:8443/api/users/register-admin";

		Map<String, Object> requestBody = new HashMap<>();
		String x = "";
		String password = "Admin@10";
		String username = "Admin";
		String email = "admin@gmail.com";

		Optional<User> u = userRepository.findByUsername(username);
		if(u.isPresent()) {
			return "";
		}
		else {
			do {
				try {
					errore = 0;

					requestBody.put("username", username);

					requestBody.put("password", password);

					requestBody.put("email", email);

					x = restTemplate.postForObject(apiUrl, requestBody, String.class);

				} catch (Exception e) {
					System.out.println("Errore durante la registrazione: " + e.getMessage());
					errore = 1;
				}

			} while (errore == 1);

			return x;
		}
	}

	public Reservation stampaCodaPrenotazioni(Boolean bot) {
		String tk = bot ? botToken : token;

		if (tk == null || tk.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
		}

		String username;
		String ruolo;

		/*
		try {
			username = jwtUtil.validateToken(tk);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.out.println("Errore: Utente non trovato.");
			}

			System.out.println("Utente autenticato con ruolo ADMIN: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
		}
*/

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		if (!isSpringContextActive()) {
			System.out.println(" Spring sta chiudendo, interrompendo richiesta.");
			return null;
		}

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + tk);
		headers.set("Content-Type", "application/json");

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		try {
			String url = "https://localhost:8443/reservations/coda";
			ResponseEntity<Reservation> response = restTemplate.exchange(
					url, HttpMethod.GET, requestEntity, Reservation.class);

			if (response.getStatusCode() == HttpStatus.NO_CONTENT) {
				return null;
			}

			return response.getBody();

		} catch (Exception e) {
			System.out.println(" Errore durante il recupero delle prenotazioni: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	private boolean isSpringContextActive() {
		if (applicationContext instanceof ConfigurableApplicationContext) {
			return ((ConfigurableApplicationContext) applicationContext).isRunning();
		}
		return false;
	}

	public void avviaHueEmulator() {
		try {
			String[] command = {
					"java", "-jar",
					"HueEmulator-v0.8.jar"
			};

			File projectRoot = new File(".").getCanonicalFile();
			File emulatorDirectory = new File(projectRoot, "Hue-Emulator");

			ProcessBuilder processBuilder = new ProcessBuilder(command);
			processBuilder.directory(emulatorDirectory);
			processBuilder.redirectErrorStream(true);

			Process process = processBuilder.start();

			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line;
			System.out.println("Log dell'emulatore:");

			aspettaEmulatore();

			UsernameHUE = registraUtenteHUE();
			if (UsernameHUE == null) {
				throw new IllegalStateException("Impossibile registrare un utente. Controlla l'emulatore.");
			}

			pulisciLampadine();
		} catch (Exception e) {
			System.err.println("Errore durante l'avvio dell'emulatore Hue: " + e.getMessage());
		}
	}

	private void aspettaEmulatore() {
		String hueBridgeUrl = "http://localhost:8000/api";
		RestTemplate restTemplate = new RestTemplate();
		boolean pronto = false;

		System.out.println("Attesa che l'emulatore sia pronto (premi 'Start' nell'emulatore e poi il pulsante 'Link Button')...");

		while (!pronto) {
			try {
				Map<String, String> requestBody = new HashMap<>();
				requestBody.put("devicetype", "my_hue_app");

				ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
						hueBridgeUrl,
						HttpMethod.POST,
						new HttpEntity<>(requestBody),
						new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
						}
				);

				List<Map<String, Map<String, String>>> body = response.getBody();
				if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
					pronto = true;
					break;
				}
			} catch (Exception e) {
				if (e.getMessage().contains("link button not pressed")) {
					System.out.println("Il pulsante 'Link Button' non è stato premuto. Aspetto...");
				} else {
					System.out.println("L'emulatore non è ancora pronto. Riprovo tra 2 secondi...");
				}
			}

			try {
				Thread.sleep(2000);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
				throw new RuntimeException("Attesa interrotta.", ex);
			}
		}
	}

	private void pulisciLampadine() {
		String hueBridgeUrl = "http://localhost:8000/api/" + UsernameHUE + "/lights";
		RestTemplate restTemplate = new RestTemplate();

		try {
			ResponseEntity<String> response = restTemplate.exchange(
					hueBridgeUrl,
					HttpMethod.GET,
					null,
					String.class
			);

			System.out.println("Risposta API grezza: " + response.getBody());

			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> lights = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {
			});

			if (lights != null) {
				for (String id : lights.keySet()) {
					int lampId = Integer.parseInt(id);
					if (lampId > 2) {
						try {
							String lampUrl = hueBridgeUrl + "/" + lampId + "/state";

							Map<String, Object> lampState = new HashMap<>();
							lampState.put("on", false);

							HttpHeaders headers = new HttpHeaders();
							headers.setContentType(MediaType.APPLICATION_JSON);
							HttpEntity<Map<String, Object>> request = new HttpEntity<>(lampState, headers);

							restTemplate.put(lampUrl, request);
							OccupazioneLampadine();
						} catch (Exception e) {
							System.err.println("Errore durante lo spegnimento della lampadina " + lampId + ": " + e.getMessage());
						}
					}
				}
			}
		} catch (Exception e) {
			System.err.println("Errore durante la pulizia delle lampadine: " + e.getMessage());
		}
	}

	public void OccupazioneLampadine(){
		String tk = botToken;

		if (tk == null || tk.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
		}

		String username;
		String ruolo;

		/*
		try {
			username = jwtUtil.validateToken(tk);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.out.println("Errore: Utente non trovato.");
			}

			System.out.println("Utente autenticato con ruolo ADMIN: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
		}
*/

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		if (!isSpringContextActive()) {
			System.out.println("️ Spring sta chiudendo, interrompendo richiesta.");
		}

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + tk);
		headers.set("Content-Type", "application/json");

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		try {
			String url = "https://localhost:8443/reservations/lampadine";
			ResponseEntity<Reservation> response = restTemplate.exchange(
					url, HttpMethod.POST, requestEntity, Reservation.class);

		} catch (Exception e) {
			System.out.println(" Errore nella chiamata all'api: " + e.getMessage());
			e.printStackTrace();
		}
	}

	private String registraUtenteHUE() {
		String hueBridgeUrl = "http://localhost:8000/api";
		RestTemplate restTemplate = new RestTemplate();

		Map<String, String> requestBody = new HashMap<>();
		requestBody.put("devicetype", "my_hue_app");

		try {
			ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
					hueBridgeUrl,
					HttpMethod.POST,
					new HttpEntity<>(requestBody),
					new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
					}
			);

			List<Map<String, Map<String, String>>> body = response.getBody();
			if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
				String username = body.get(0).get("success").get("username");
				return username;
			} else {
				System.err.println("Errore durante la registrazione dell'utente. Risposta API: " + body);
			}
		} catch (Exception e) {
			System.err.println("Errore durante la registrazione dell'utente: " + e.getMessage());
		}
		return null;
	}

	public void eseguiSbarra() {
		try {
			File directory = new File(System.getProperty("user.dir"), "Sbarra");

			ProcessBuilder cleanInstallBuilder = new ProcessBuilder("mvn", "clean", "install");
			cleanInstallBuilder.directory(directory);
			cleanInstallBuilder.redirectErrorStream(true);
			Process cleanInstallProcess = cleanInstallBuilder.start();
			int exitCode = cleanInstallProcess.waitFor(); // Aspetta che termini
			if (exitCode != 0) {
				System.err.println("Errore durante 'mvn clean install': Codice di uscita " + exitCode);
				return;
			}

			new Thread(() -> {
				try {
					ProcessBuilder execJavaBuilder = new ProcessBuilder("mvn", "exec:java");
					execJavaBuilder.directory(directory);
					execJavaBuilder.redirectErrorStream(true);
					Process execJavaProcess = execJavaBuilder.start();
					execJavaProcess.waitFor();
				} catch (IOException | InterruptedException e) {
					e.printStackTrace();
					System.err.println("Errore durante l'esecuzione di 'mvn exec:java': " + e.getMessage());
				}
			}).start();

		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
			System.err.println("Errore durante l'esecuzione di 'mvn clean install': " + e.getMessage());
		}
	}

	public void apriSbarra() {
		String barrierOpenUrl = "http://localhost:9090/api/barrier/open";
		RestTemplate restTemplate = new RestTemplate();

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<>(null, headers);

			ResponseEntity<String> response = restTemplate.exchange(
					barrierOpenUrl,
					HttpMethod.POST,
					request,
					String.class
			);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Errore durante l'apertura della sbarra: " + e.getMessage());
		}
	}

	public void chiudiSbarra() {
		String barrierCloseUrl = "http://localhost:9090/api/barrier/close";
		RestTemplate restTemplate = new RestTemplate();

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<>(null, headers);

			ResponseEntity<String> response = restTemplate.exchange(
					barrierCloseUrl,
					HttpMethod.POST,
					request,
					String.class
			);
			OccupazioneLampadine();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Errore durante la chiusura della sbarra: " + e.getMessage());
		}
	}

	private void startBot() {
		try {
			String projectDir = System.getProperty("user.dir");

			String jarPath = projectDir + "/parcheggio/target/mwbot.jar";

			String os = System.getProperty("os.name").toLowerCase();

			ProcessBuilder processBuilder;

			if (os.contains("win")) {
				processBuilder = new ProcessBuilder("cmd.exe", "/c", "start cmd /k java -jar mwbot.jar");
			} else if (os.contains("mac")) {
				processBuilder = new ProcessBuilder(
						"osascript", "-e",
						"tell application \"Terminal\" to do script \"java -jar " + jarPath + "\""
				);
			} else if (os.contains("nix") || os.contains("nux")) {
				processBuilder = new ProcessBuilder("sh", "-c", "gnome-terminal -- java -jar " + jarPath);
			} else {
				throw new UnsupportedOperationException("Sistema operativo non supportato");
			}

			processBuilder.start();
			System.out.println(" Bot avviato correttamente in una nuova scheda!");

			Thread.sleep(1000);
			System.out.println(" Ritorno al menu...");
		} catch (IOException e) {
			System.err.println(" Errore durante l'avvio del bot: " + e.getMessage());
			e.printStackTrace();
		} catch (InterruptedException e) {
			System.err.println(" Errore durante l'attesa: " + e.getMessage());
			Thread.currentThread().interrupt();
		}
	}

	public void startMosquitto() {
		try {
			File currentFile = new File(ParcheggioApplication.class.getProtectionDomain()
					.getCodeSource().getLocation().toURI());

			File parentFolder = currentFile.getParentFile().getParentFile();

			File mqttFolder = Paths.get(parentFolder.getAbsolutePath(),
					"src", "main", "java", "Principale", "Parcheggio", "MQTT").toFile();

			File mosquittoConfigPath = new File(mqttFolder, "mosquitto_dynamic.conf");

			if (mosquittoConfigPath.exists()) {
				if(!mosquittoConfigPath.delete()){
					System.err.println("ERRORE nella cancellazione del file di configurazione dell'mqtt");
				}
			}

			generateMosquittoConfig(mosquittoConfigPath);

			String[] command = {
					"osascript", "-e",
					"tell application \"Terminal\" to do script \"mosquitto -c " + mosquittoConfigPath.getAbsolutePath() + "\""
			};

			ProcessBuilder processBuilder = new ProcessBuilder(command);
			processBuilder.start();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void generateMosquittoConfig(File configFile) {
		try (FileWriter writer = new FileWriter(configFile)) {
			writer.write("per_listener_settings true\n");
			writer.write("listener 1883\n");
			writer.write("allow_anonymous false\n");
			writer.write("password_file " + configFile.getParent() + "/passw.txt\n");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Scheduled(fixedRate = 60000) //1 minuto
	private void SpostaSoste(){
			if (isTestProfileActive()) {
				return;
			}
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		if (!isSpringContextActive()) {
			System.out.println("Spring sta chiudendo, interrompendo richiesta.");
			return;
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> requestEntity = new HttpEntity<>(null, headers);

		try {
			String url = "https://localhost:8443/Admin/SpostaSoste";

			ResponseEntity<String> response = restTemplate.exchange(
					url, HttpMethod.POST, requestEntity, String.class);

			System.out.println("Soste Vecchie Spostate");

		} catch (Exception e) {
			System.err.println("Errore durante la richiesta POST: " + e.getMessage());
			e.printStackTrace();
		}
	}
}
