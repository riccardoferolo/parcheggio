package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Models.ParkingSpot;
import Principale.Parcheggio.ParcheggioApplication;
import Principale.Parcheggio.Repository.ParkingSpotRepository;
import Principale.Parcheggio.Repository.ReservationRepository;
import Principale.Parcheggio.Services.ReservationService;
import Principale.Parcheggio.MQTT.MqttPublisher;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.Models.Reservation;

import java.util.Map;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/reservations")
@Tag(name = "ReservationController", description = "Controller per le prenotazioni")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private MqttPublisher mqttPublisher;
    @Autowired
    private ReservationRepository reservationRepository;

    @Operation(summary = "Restituisce le prenotazioni",
            description = "Restituisce le prenotazioni associate ad un username.")
    @GetMapping("/ReservationByUser")
        public ResponseEntity<List<Reservation>> getReservationsByUser(@RequestParam String username) {
            List<Reservation> reservations = reservationRepository.findByUserUsername(username);
            if (reservations.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(reservations);
            }
            return ResponseEntity.ok(reservations);
    }

    @Operation(summary = "Restituisce tutte le prenotazioni",
            description = "Restituisce tutte le prenotazioni che sono presenti nel database.")
    @GetMapping("/all")
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();
        mqttPublisher.publishMessage("reservations/fetch", "Tutte le prenotazioni sono state recuperate");
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/occupazione")
    public ResponseEntity<String> getActiveReservationsSummary() {
        Map<String, Integer> summary = reservationService.Occupazione();
        String message = String.format(
                "In questo momento nel parcheggio abbiamo:\n- in ricarica ci sono %d macchine\n- in sosta ci sono %d macchine",
                summary.get("ricariche"),
                summary.get("soste")
        );
        //mqttPublisher.publishMessage("reservations/summary", "Occupazione aggiornata: " + message);
        return ResponseEntity.ok(message);
    }

    @Operation(summary = "Uscita anticipata dal parcheggio",
            description = "Permette l'uscita anticipata dal parcheggio di una macchina a cui è associata una prenotazione con un determinato id.")
    @PostMapping("/uscita-anticipata")
    public ResponseEntity<String> esciPrimaDalParcheggio(@RequestBody Long id) {
        String response = reservationService.esciPrimaDalParcheggio(id);
        mqttPublisher.publishMessage("reservations/update", "la prenotazione con id:" + id + "esce prima. ARRIVEDERCI");
        return ResponseEntity.ok(response);
    }

    @Operation(summary = "Salva in storico",
            description = "La prenotazione viene completata e salvata nello storico.")
    @PostMapping("/GestioneReservation")
    public void gestioneReservation(@RequestBody Reservation r) {
        reservationService.completeReservation(r);
        mqttPublisher.publishMessage("reservations/manage", "Gestione completata per la prenotazione con ID: " + r.getId());
    }

    @Operation(summary = "coda delle prenotazioni",
            description = "Restituisce la coda delle prenotazioni in caso ci siano.")
    @GetMapping("/coda")
    public ResponseEntity<?> getProvaReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();

        reservations.sort(Comparator
                .comparing((Reservation r) -> r.getChargeRequest().getGiorno())
                .thenComparing(r -> r.getChargeRequest().getOra()));

        if (reservations.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Nessuna prenotazione trovata.");
        }
        return ResponseEntity.ok(reservations.get(0));
    }

    @Operation(summary = "Imposta una prenotazione come ritardo ",
            description = "sposta la prenotazione in delayedreservation, siccome è risultata in ritardo.")
    @PostMapping("/RitardoTrue")
    public void RitardoTrue(@RequestBody Reservation r) {
        reservationService.RitardoTrue(r);
        mqttPublisher.publishMessage("reservations/delay", "prenotazione con ID: " + r.getId()+ "spostata in delayed reservation");
    }

    @Operation(summary = "Rimuove il ritardo da una prenotazione",
            description = "sposta la prenotazione in storico, siccome non è in ritardo.")
    @PostMapping("/RitardoFalse")
    public void RitardoFalse(@RequestBody Reservation r) {
        reservationService.RitardoFalse(r);
        mqttPublisher.publishMessage("reservations/storico", "prenotazione con ID: " + r.getId()+ "spostata in storico");
    }

    @Operation(summary = "Pagamento del ritardo",
            description = "Permette il pagamento di un ritardo.")
    @PostMapping("/PagaRitardo")
    public void PagaRitardo(@RequestBody Map<String, DelayedReservation> requestBody) {
        if (requestBody.get("Prenotazione") == null) {
            mqttPublisher.publishMessage("errors/reservations", "Errore nell'input della prenotazione.");
            return;
        }

        reservationService.PagareRitardo(requestBody.get("Prenotazione"));
        mqttPublisher.publishMessage("reservations/delay", "Pagamento ritardo effettuato per la prenotazione.");
    }

    @Operation(summary = "Aggiorna Stato delle lampadine",
            description = "Lo stato delle lampadine viene aggiornato a seconda delle auto in sosta o in ricarica che ci sono.")
    @PostMapping("/lampadine")
    public void lampadine() {
        List<Reservation> reservations = reservationService.findAllReservations();
        Optional<ParkingSpot> optionalParkingSpot = parkingSpotRepository.findById(1);
        reservationService.OccupazioneLampadine(optionalParkingSpot, reservations);
        //mqttPublisher.publishMessage("reservations/lights", "Aggiornamento stato lampadine in base alle prenotazioni.");
    }
}
