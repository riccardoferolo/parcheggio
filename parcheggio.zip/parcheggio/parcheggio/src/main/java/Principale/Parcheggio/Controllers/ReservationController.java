package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Services.ReservationService;
import Principale.Parcheggio.DTO.ReservationDTO;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.Models.Reservation;

import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.Comparator;
import java.util.List;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    // Trova tutte le prenotazioni (opzionale)
    @GetMapping("/all")
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/occupazione")
    public ResponseEntity<String> getActiveReservationsSummary() {
        Map<String, Integer> summary = reservationService.Occupazione();
        System.out.println("ciao");
        // Creazione del messaggio leggibile
        String message = String.format(
                "In questo momento nel parcheggio abbiamo:\n- in ricarica ci sono %d macchine\n- in sosta ci sono %d macchine",
                summary.get("ricariche"),
                summary.get("soste")
        );

        return ResponseEntity.ok(message);
    }

    @PostMapping("/PagaRitardo")
    public void PagaRitardo(@RequestBody DelayedReservation delayedReservation) {
        reservationService.PagareRitardo(delayedReservation);
    }

    @PostMapping("/uscita-anticipata")
    public ResponseEntity<String> esciPrimaDalParcheggio(@RequestParam String username) {
        String response = reservationService.esciPrimaDalParcheggio(username);
        return ResponseEntity.ok(response);
    }


}

