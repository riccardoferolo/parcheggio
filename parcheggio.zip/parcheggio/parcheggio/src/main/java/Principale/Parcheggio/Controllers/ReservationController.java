package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Models.ParkingSpot;
import Principale.Parcheggio.ParcheggioApplication;
import Principale.Parcheggio.Repository.ParkingSpotRepository;
import Principale.Parcheggio.Services.ReservationService;
import org.hibernate.grammars.hql.HqlParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.Models.Reservation;

import java.util.Map;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    // Trova tutte le prenotazioni (opzionale)
    @GetMapping("/all")
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();
        return ResponseEntity.ok(reservations);
    }

    @GetMapping("/occupazione")
    public ResponseEntity<String> getActiveReservationsSummary() {
        Map<String, Integer> summary = reservationService.Occupazione();
        System.out.println("ciao");
        // Creazione del messaggio leggibile
        String message = String.format(
                "In questo momento nel parcheggio abbiamo:\n- in ricarica ci sono %d macchine\n- in sosta ci sono %d macchine",
                summary.get("ricariche"),
                summary.get("soste")
        );

        return ResponseEntity.ok(message);
    }



    @PostMapping("/uscita-anticipata")
    public ResponseEntity<String> esciPrimaDalParcheggio(@RequestParam String username) {
        String response = reservationService.esciPrimaDalParcheggio(username);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/GestioneReservation")
    public void gestioneReservation(@RequestBody Reservation r) {
        reservationService.completeReservation(r);
    }

    @GetMapping("/coda")
    public ResponseEntity<?> getProvaReservations() {
        List<Reservation> reservations = reservationService.findAllReservations();

        // Ordinamento per giorno e ora
        reservations.sort(Comparator
                .comparing((Reservation r) -> r.getChargeRequest().getGiorno())
                .thenComparing(r -> r.getChargeRequest().getOra()));

        if (reservations.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Nessuna prenotazione trovata.");
        }

        return ResponseEntity.ok(reservations.get(0));
        /*
        // Converte in DTO usando Collectors.toList()
        List<ReservationDTO> reservationDTOs = reservations.stream()
                .map(reservation -> new ReservationDTO(
                        reservation.getId(),
                        reservation.getUser().getId(),
                        reservation.getChargeRequest().getId(),
                        reservation.getPayment().getId(),
                        reservation.getChargeRequest().getGiorno(),
                        reservation.getChargeRequest().getOra(),
                        reservation.getChargeRequest().getdurata(),
                        reservation.getChargeRequest().getTarga()
                ))
                .collect(Collectors.toList()); // Utilizzo di Collectors.toList()

         */

        //return ResponseEntity.ok(x).getBody();
    }


    @PostMapping("/RitardoTrue")
    public void RitardoTrue(@RequestBody Reservation r) {
        reservationService.RitardoTrue(r);
    }

    @PostMapping("/RitardoFalse")
    public void RitardoFalse(@RequestBody Reservation r) {
        reservationService.RitardoFalse(r);
    }

    //--------------------------------------------------------------------------------------------------------
    @PostMapping("/PagaRitardo")
    public void PagaRitardo(@RequestBody Map<String, DelayedReservation> requestBody) {



        if (requestBody.get("Prenotazione")== null) {
            System.out.println(ResponseEntity.badRequest().body("Errore: Nessuna prenotazione ricevuta."));
        }



        reservationService.PagareRitardo(requestBody.get("Prenotazione"));

    }


    @PostMapping("/lampadine")
    public void lampadine() {
        List<Reservation> reservations = reservationService.findAllReservations();
        Optional<ParkingSpot> optionalParkingSpot = parkingSpotRepository.findById(1);
        reservationService.OccupazioneLampadine(optionalParkingSpot, reservations);
    }

}

