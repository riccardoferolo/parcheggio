package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.JwtUtil;
import Principale.Parcheggio.MQTT.MqttPublisher;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/delayed-reservations")
@Tag(name = "DelayedReservationController", description = "Controller per le Reservation in Ritardo")
public class DelayedReservationController {

    private final DelayedReservationRepository delayedReservationRepository;
    private final UserRepository userRepository;
    private final MqttPublisher mqttPublisher;

    public DelayedReservationController(DelayedReservationRepository delayedReservationRepository, UserRepository userRepository, JwtUtil jwtUtil, MqttPublisher mqttPublisher) {
        this.delayedReservationRepository = delayedReservationRepository;
        this.userRepository = userRepository;
        this.mqttPublisher = mqttPublisher;
    }


    @Operation(summary = "Ottiene tutte le prenotazioni segnate in ritardo di un determinato utente",
            description = "Ritorna una ResponseEntity con all'interno le prenotazioni se ci sono, altrimenti una lista vuota")
    @PostMapping("/user")
    public ResponseEntity<?> getUserDelayedReservations(@RequestBody Map<String, String> request) {
        try {
            String username = request.get("username");

            if (username == null || username.isEmpty()) {
                mqttPublisher.publishMessage("errors/delayed-reservations", "Errore: Username non valido o mancante.");
                return ResponseEntity.badRequest().body("Errore: Username non valido o mancante.");
            }

            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isEmpty()) {
                mqttPublisher.publishMessage("errors/delayed-reservations", "Errore: Utente non trovato: " + username);
                return ResponseEntity.badRequest().body("Errore: Utente non trovato.");
            }

            List<DelayedReservation> delayedReservations = delayedReservationRepository.findByUserUsername(username);

            if (delayedReservations.isEmpty()) {
                mqttPublisher.publishMessage("delayed-reservations/fetch", "Nessuna prenotazione in ritardo trovata per l'utente: " + username);
                return ResponseEntity.ok(Collections.emptyList());
            }

            mqttPublisher.publishMessage("delayed-reservations/fetch", "Prenotazioni in ritardo recuperate per l'utente: " + username);
            return ResponseEntity.ok(delayedReservations);

        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/delayed-reservations", "Errore durante il recupero delle prenotazioni: " + e.getMessage());
            return ResponseEntity.internalServerError().body("Errore durante il recupero delle prenotazioni: " + e.getMessage());
        }
    }
}

