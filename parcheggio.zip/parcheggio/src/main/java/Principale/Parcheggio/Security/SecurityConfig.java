package Principale.Parcheggio.Security;

import Principale.Parcheggio.Security.JwtAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.ignoringRequestMatchers(
                        new AntPathRequestMatcher("/h2-console/**"), // Disabilita CSRF per H2 Console
                        new AntPathRequestMatcher("/api/users/login", "POST"),
                        new AntPathRequestMatcher("/api/users/register", "POST"),
                        new AntPathRequestMatcher("/api/users/register-admin", "POST"),
                        new AntPathRequestMatcher("/api/users/aggiorna-carta", "PUT"),
                        new AntPathRequestMatcher("/api/users/aggiorna-saldo", "PUT"),
                        new AntPathRequestMatcher("/Admin/username", "GET"),
                        new AntPathRequestMatcher("/Admin/user/delete-all", "DELETE"),
                        new AntPathRequestMatcher("/Admin/user/delete", "DELETE"),
                        new AntPathRequestMatcher("/api/macchine/create", "POST"),
                        new AntPathRequestMatcher("/Admin/macchine/delete", "DELETE"),
                        new AntPathRequestMatcher("/api/macchine/byUser", "GET"),
                        new AntPathRequestMatcher("/api/macchine/byTarga", "GET"),
                        new AntPathRequestMatcher("/chargerequests/new", "POST"),
                        new AntPathRequestMatcher("/api/payments/listaPagamenti", "POST"),
                        new AntPathRequestMatcher("/Admin/reservation/delete-all", "DELETE"),
                        new AntPathRequestMatcher("/Admin/delayedreservation/delete-all", "DELETE"),
                        new AntPathRequestMatcher("/Admin/payment/delete-all", "DELETE"),
                        new AntPathRequestMatcher("/Admin//charge/delete-all", "DELETE"),
                        new AntPathRequestMatcher("/reservations/coda", "GET"),
                        new AntPathRequestMatcher("/reservations/occupazione", "GET"),
                        new AntPathRequestMatcher("/Admin/macchine/deleteALL", "DELETE"),
                        new AntPathRequestMatcher("/api/barrier/open", "POST"),
                        new AntPathRequestMatcher("/api/barrier/close", "POST"),
                        new AntPathRequestMatcher("/api/users/abbonamento", "PUT"),
                        new AntPathRequestMatcher("/Admin/Aggiorna-Costo-Sosta", "PUT"),
                        new AntPathRequestMatcher("/Admin/Aggiorna-Costo-ricarica", "PUT"),
                        new AntPathRequestMatcher("/Admin/Setritardo", "POST"),
                        new AntPathRequestMatcher("/reservations/PagaRitardo", "POST"),
                        new AntPathRequestMatcher("/reservations/GestioneReservation", "POST")

                ))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(new AntPathRequestMatcher("/h2-console/**")).permitAll() // H2 Console accessibile pubblicamente
                        .requestMatchers(new AntPathRequestMatcher("/api/users/login", "POST")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/api/users/register", "POST")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/api/users/register-admin", "POST")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/api/users/aggiorna-carta", "PUT")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/api/users/aggiorna-saldo", "PUT")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/Admin/username", "GET")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/Admin/user/delete", "DELETE")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/Admin/user/delete-all")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/api/macchine/create", "POST")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/Admin/macchine/delete", "DELETE")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/api/macchine/byUser", "GET")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/api/macchine/byTarga", "GET")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/chargerequests/new", "POST")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/api/payments/listaPagamenti", "POST")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/Admin/reservation/delete-all", "DELETE")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/Admin/delayedreservation/delete-all", "DELETE")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/Admin/charge/delete-all", "DELETE")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/Admin/payment/delete-all", "DELETE")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/reservations/coda", "GET")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/reservations/occupazione", "GET")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/Admin/macchine/deleteALL", "DELETE")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/api/barrier/open", "POST")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/api/barrier/close", "POST")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/api/users/abbonamento", "PUT")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/Admin/Aggiorna-Costo-Sosta", "PUT")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/Admin/Aggiorna-Costo-ricarica", "PUT")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/Admin/Setritardo", "POST")).hasRole("ADMIN")
                        .requestMatchers(new AntPathRequestMatcher("/reservations/PagaRitardo", "POST")).authenticated()
                        .requestMatchers(new AntPathRequestMatcher("/reservations/GestioneReservation", "POST")).hasRole("ADMIN")
                ).requiresChannel(channel -> channel
                        .anyRequest().requiresSecure() // Richiede HTTPS per tutte le richieste
                )
                .headers(headers -> headers.frameOptions(frame -> frame.disable())) // Consenti iframe per H2 Console
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }


}















