package Principale.Parcheggio.Security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Base64;
import java.util.Date;

@Component
public class JwtUtil {

    private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);


    @Value("${jwt.secret:non-impostata}")
    private String secretKey;

    private static final long EXPIRATION_TIME = 86400000; // 1 giorno

    @PostConstruct
    public void init() {
        if ("non-impostata".equals(secretKey)) {
            secretKey = System.getenv("JWT_SECRET");
        }

        if (secretKey == null || secretKey.isEmpty()) {
            throw new IllegalArgumentException("La chiave segreta non è configurata!");
        }

       // logger.info("Chiave segreta caricata: {}", secretKey);
    }

    private Key getKey() {
        if (secretKey == null) {
            secretKey = System.getenv("JWT_SECRET"); // Fallback manuale
        }
        if (secretKey == null || secretKey.length() < 32) {
            throw new IllegalStateException("La chiave segreta non è valida o non è stata caricata.");
        }
        //logger.debug("Chiave in getKey: {}", secretKey);


        byte[] decodedKey = Base64.getDecoder().decode(secretKey);
        return Keys.hmacShaKeyFor(decodedKey);
    }

    @PostConstruct
    public void logSecretKey() {
        //System.out.println("JWT_SECRET usata dal server: " + secretKey);
    }


    @PostConstruct
    public void validateSecretKey() {
        if (secretKey == null || secretKey.isEmpty()) {
            throw new IllegalArgumentException("La chiave segreta non è stata configurata correttamente.");
        }
        if (secretKey.length() < 32) {
            throw new IllegalArgumentException("La chiave segreta deve avere almeno 32 caratteri.");
        }
        //logger.info("Chiave segreta inizializzata correttamente: {}", secretKey);
    }


    public String generateToken(String username, String role) {
        return Jwts.builder()
                .setSubject(username) // Il nome utente come "sub"
                .claim("role", role)  // Il ruolo come claim
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000)) // Valido per 1 giorno
                .signWith(getKey(), SignatureAlgorithm.HS256) // Firma il token con la chiave segreta
                .compact();
    }




    public String validateToken(String token) {
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(getKey()) // Usa la chiave corretta
                    .parseClaimsJws(token)
                    .getBody();
            //logger.debug("Claims ottenuti: {}", claims);

            // Ritorna il nome utente o altra informazione utile
            return claims.getSubject(); // "sub" contiene il nome utente
        } catch (ExpiredJwtException e) {
            //logger.error("Il token è scaduto: {}", e.getMessage());
            throw new IllegalArgumentException("Token scaduto");
        } catch (JwtException | IllegalArgumentException e) {
            //logger.error("Errore durante la validazione del token: {}", e.getMessage());
            throw new IllegalArgumentException("Token non valido");
        }
    }




    public String extractRole(String token) {
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(getKey()) // Usa la chiave corretta
                    .parseClaimsJws(token)
                    .getBody();
            //logger.debug("Claims estratti: {}", claims);

            // Estrai il ruolo dal token
            return claims.get("role", String.class);
        } catch (JwtException | IllegalArgumentException e) {
            //logger.error("Errore durante l'estrazione del ruolo dal token: {}", e.getMessage());
            throw new IllegalArgumentException("Token non valido");
        }
    }






}




