package Principale.Parcheggio.Security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpsTestApplication {
    public static void main(String[] args) {
        SpringApplication.run(HttpsTestApplication.class, args);
    }
}

