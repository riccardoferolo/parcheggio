package Principale.Parcheggio.Repository;

import Principale.Parcheggio.Models.Storico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StoricoRepository extends JpaRepository<Storico, Long> {
    @Query("SELECT s FROM Storico s JOIN FETCH s.chargeRequest WHERE s.idStorico = :idStorico")
    Storico findByIdWithChargeRequest(@Param("idStorico") Long idStorico);
}

