package Principale.Parcheggio.Repository;

import Principale.Parcheggio.Models.DelayedReservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DelayedReservationRepository extends JpaRepository<DelayedReservation, Long> {
}

