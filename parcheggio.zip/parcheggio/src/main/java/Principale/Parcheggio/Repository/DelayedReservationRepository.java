package Principale.Parcheggio.Repository;

import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Models.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DelayedReservationRepository extends JpaRepository<DelayedReservation, Long> {

    @Query("SELECT r FROM DelayedReservation r WHERE r.username = :username")
    List<DelayedReservation> findByUserUsername(@Param("username") String username);
}

