package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.ParkingSpot;
import Principale.Parcheggio.Models.Reservation;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.ParkingSpotRepository;
import Principale.Parcheggio.Services.ReservationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import Principale.Parcheggio.Models.ChargeRequest;
import Principale.Parcheggio.Services.ChargeRequestService;
import Principale.Parcheggio.MQTT.MqttPublisher;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping("/chargerequests")
@Tag(name = "ChargeRequestController", description = "Controller per le ChargeRequest del parcheggio")
public class ChargeRequestController {

    @Autowired
    private ChargeRequestService chargeRequestService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ParkingSpotRepository parkingSpotRepository;

    @Autowired
    private MqttPublisher mqttPublisher; // Aggiunto MQTT Publisher

    @Operation(summary = "Crea una ChargeRequest",
            description = "permette di creare una richiesta di carica.")
    @PostMapping("/new")
    public ResponseEntity<?> createChargeRequest(@RequestBody Map<String, Object> requestBody) {
        try {
            String nome = (String) requestBody.get("username");
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            String dataStr = (String) requestBody.get("giorno");
            LocalDate data;
            try {
                data = LocalDate.parse(dataStr, dateFormatter);
            } catch (Exception e) {
                mqttPublisher.publishMessage("errors/charge", "Errore nella data: " + e.getMessage());
                return ResponseEntity.status(500).body("Errore nella data : " + e.getMessage());
            }

            String oraStr = (String) requestBody.get("ora");
            Time ora = Time.valueOf(oraStr);

            Integer percentuale_iniziale = (Integer) requestBody.get("Percentuale_iniziale");
            Integer percentuale_richiesta = (Integer) requestBody.get("Percentuale_richiesta");

            String dStr = (String) requestBody.get("durata");
            Time durata = Time.valueOf(dStr);

            String FStr = (String) requestBody.get("oraFine");
            Time oraFine = Time.valueOf(FStr);

            String Targa = (String) requestBody.get("Targa");
            Boolean r = (Boolean) requestBody.get("Ricarica");

            ChargeRequest chargeRequest = chargeRequestService.createChargeRequest(nome, data, ora, durata, percentuale_iniziale, percentuale_richiesta, oraFine, Targa, r);
            mqttPublisher.publishMessage("charges/create", "Nuova richiesta di carica creata per l'utente: " + nome);


            List<Reservation> reservations = reservationService.findAllReservations();
            Optional<ParkingSpot> optionalParkingSpot = parkingSpotRepository.findById(1);
            reservationService.OccupazioneLampadine(optionalParkingSpot, reservations);


            return ResponseEntity.ok(chargeRequest);
        } catch (IllegalArgumentException e) {
            mqttPublisher.publishMessage("errors/charge", "Errore nella creazione della richiesta: " + e.getMessage());
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            mqttPublisher.publishMessage("errors/charge", "Errore del server interno: " + e.getMessage());
            return ResponseEntity.status(500).body("Errore del server interno : " + e.getMessage());
        }
    }
    @Operation(summary = "Ritorna delle ChargeRequest",
            description = "Ritorna una lista di tutte le richieste di carica presenti nel database.")
    @GetMapping("/all")
    public List<ChargeRequest> getAllChargeRequests() {
        return chargeRequestService.getAllChargeRequests();
    }

    @Operation(summary = "Ritorna un ChargeRequest",
            description = "Ritorna una  richiesta di carica per ID nel database.")
    @GetMapping("/charge-per-id")
    public ResponseEntity<ChargeRequest> getChargeRequestById(@RequestBody Long id) {
        Optional<ChargeRequest> chargeRequest = chargeRequestService.getChargeRequestById(id);
        if (chargeRequest.isPresent()) {
            return ResponseEntity.ok(chargeRequest.get());
        } else {
            mqttPublisher.publishMessage("errors/charge", "Richiesta di carica con ID " + id + " non trovata");
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Ritorna una o più ChargeRequest",
            description = "Ritorna una o più richieste di carica in base all'ID dell'utente.")
    @GetMapping("/user/trova-per-userid")
    public ResponseEntity<?> getRequestsByUserId(@RequestBody Long Userid) {
        try {
            List<ChargeRequest> chargeRequests = chargeRequestService.getChargeRequestsByUserId(Userid);
            if (chargeRequests.isEmpty()) {
                mqttPublisher.publishMessage("errors/charge", "Nessuna richiesta trovata per l'utente con ID " + Userid);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Nessuna richiesta trovata per l'id " + Userid);
            }
            return ResponseEntity.ok(chargeRequests);
        } catch (Exception e) {
            mqttPublisher.publishMessage("errors/charge", "Errore durante il recupero delle richieste per l'utente con ID " + Userid + ": " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore del server interno: " + e.getMessage());
        }
    }

    @Operation(summary = "Calcola il tempo di ricarica",
            description = "Calcola il tempo di ricarica in base ai kw della batteria dell'auto.")
    @GetMapping("/calcola")
    public String calcolaRicarica(
            @RequestParam Integer percentualeIniziale,
            @RequestParam Integer percentualeFinale,
            @RequestParam double kwAuto) {
        return chargeRequestService.calcola(percentualeIniziale, percentualeFinale, kwAuto);
    }

    @Operation(summary = "Disponibilità",
            description = "Vede se c'è diponibile un posto per la ricarica.")
    @GetMapping("/DisponibileRicarica")
    public Boolean isReservationAvailableRicarica(@RequestParam LocalDate giorno, @RequestParam Time ora, @RequestParam Time oraFine) {
        return chargeRequestService.isReservationAvailableRicarica(giorno, ora, oraFine);
    }

    @Operation(summary = "Disponibilità",
            description = "Vede se c'è diponibile un posto per la sosta.")
    @GetMapping("/DisponibileSosta")
    public Boolean isReservationAvailable(@RequestParam LocalDate giorno, @RequestParam Time ora, @RequestParam Time oraFine) {
        return chargeRequestService.isReservationAvailable(giorno, ora, oraFine);
    }

    @Operation(summary = "Orario più vicino per la sosta",
            description = "Guarda quand'è l'orario più vicino in cui è possibile sostare.")
    @GetMapping("/TempoFineSosta")
    public Time findEarliestEndTimeSosta(@RequestParam LocalDate giorno, @RequestParam Time oraInizio, @RequestParam Time oraFine) {
        return chargeRequestService.findEarliestEndTimeSosta(giorno, oraInizio, oraFine);
    }

    @Operation(summary = "Orario più vicino per la ricarica",
            description = "Guarda quand'è l'orario più vicino in cui è possibile ricaricare.")
    @GetMapping("/TempoFineRicarica")
    public Time findEarliestEndTimeRicarica(@RequestParam LocalDate giorno, @RequestParam Time oraInizio, @RequestParam Time oraFine) {
        return chargeRequestService.findEarliestEndTimeRicarica(giorno, oraInizio, oraFine);
    }
}
