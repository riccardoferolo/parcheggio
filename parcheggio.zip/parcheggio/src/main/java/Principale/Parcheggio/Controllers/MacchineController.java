package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.MacchinaRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Services.MacchineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/macchine")
public class MacchineController {

    @Autowired
    private MacchineService macchineService;
    @Autowired
    private MacchinaRepository macchinaRepository;
    @Autowired
    private UserRepository userRepository;

    // Creare una nuova macchina
    @PostMapping("/create")
    public ResponseEntity<Macchine> createMacchina(@RequestParam String targa, @RequestParam double kwBatteria, @RequestParam String modello, @RequestParam String username) {
        Macchine macchina = macchineService.createMacchina(targa, kwBatteria, modello, username);
        return new ResponseEntity<>(macchina, HttpStatus.CREATED);
    }

    // Modificare i parametri di una macchina
    @PutMapping("/update")
    public ResponseEntity<Macchine> updateMacchina(@RequestParam String targa, @RequestParam double kwBatteria, @RequestParam String modello) {
        Macchine macchina = macchineService.updateMacchina(targa, kwBatteria, modello);
        return ResponseEntity.ok(macchina);
    }

    // Restituire tutte le macchine per un determinato id utente


    @GetMapping("/byUser")
    public ResponseEntity<List<Macchine>> getMacchineByUser(@RequestParam String username) {
        List<Macchine> macchine = macchineService.getMacchineByUser(username);

        if (macchine.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
        }

        return ResponseEntity.ok(macchine);
    }
//------------------------------------------------------------------------------
    @DeleteMapping("/delete")
    public ResponseEntity<Void> deleteMacchina(@RequestParam String targa) {
        macchineService.deleteMacchina(targa);
        return ResponseEntity.noContent().build();
    }
//------------------------------------------------------------------------------

    // Restituire i dettagli di una macchina tramite targa
    @GetMapping("/byTarga")
    public ResponseEntity<Macchine> getMacchinaByTarga(@RequestParam String targa) {
        Macchine macchina = macchineService.getMacchinaByTarga(targa);
        if (macchina != null) {
            return ResponseEntity.ok(macchina);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
}

