package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.DelayedReservation;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.JwtUtil;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/delayed-reservations")
public class DelayedReservationController {

    private final DelayedReservationRepository delayedReservationRepository;
    private final UserRepository userRepository;

    public DelayedReservationController(DelayedReservationRepository delayedReservationRepository, UserRepository userRepository, JwtUtil jwtUtil) {
        this.delayedReservationRepository = delayedReservationRepository;
        this.userRepository = userRepository;
    }

    /**
     * Endpoint per ottenere tutte le macchine ritardate di un utente autenticato.
     *
     * @return ResponseEntity con la lista delle prenotazioni ritardate o un messaggio di errore
     */
    @PostMapping("/user")
    public ResponseEntity<?> getUserDelayedReservations(@RequestBody Map<String, String> request) {
        try {
            String username = request.get("username");

            if (username == null || username.isEmpty()) {
                return ResponseEntity.badRequest().body("Errore: Username non valido o mancante.");
            }

            // Verifica se l'utente esiste
            Optional<User> userOpt = userRepository.findByUsername(username);
            if (userOpt.isEmpty()) {
                return ResponseEntity.badRequest().body("Errore: Utente non trovato.");
            }

            // Recupera le prenotazioni in ritardo dell'utente
            List<DelayedReservation> delayedReservations = delayedReservationRepository.findByUserUsername(username);

            if (delayedReservations.isEmpty()) {
                return ResponseEntity.ok(Collections.emptyList());
            }

            return ResponseEntity.ok(delayedReservations);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Errore durante il recupero delle prenotazioni: " + e.getMessage());
        }
    }

}

