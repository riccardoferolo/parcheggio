package Principale.Parcheggio.Controllers;

import Principale.Parcheggio.Models.Macchine;
import Principale.Parcheggio.Models.User;
import Principale.Parcheggio.Repository.UserRepository;
import Principale.Parcheggio.Security.JwtUtil;
import Principale.Parcheggio.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final UserRepository userRepository;
    Scanner s = new Scanner(System.in);

    @Autowired
    public UserController(UserService userService, UserRepository userRepository) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.jwtUtil = new JwtUtil();
    }

    // Endpoint per la registrazione di un nuovo utente
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody Map<String, Object> requestBody) {
        System.out.println("🔹 Ricevuta richiesta di registrazione: " + requestBody);

        User user = new User();
        user.setUsername((String) requestBody.get("username"));
        user.setPassword((String) requestBody.get("password"));
        user.setEmail((String) requestBody.get("email"));
        userService.registerUser(user);
        return ResponseEntity.ok("Utente registrato con successo");
    }

    @PostMapping("/register-admin")
    public ResponseEntity<String> registerAdmin(@RequestBody User user) {
        try {
            userService.registerAdmin(user);
            return ResponseEntity.ok("Utente registrato con successo");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody Map<String, String> loginData) {
        String email = loginData.get("email");
        String password = loginData.get("password");

        try {
            User user = userService.loginUser(email, password);
            String token = jwtUtil.generateToken(user.getUsername(), user.getRuolo().toString());
            return ResponseEntity.ok(token);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }



    // Endpoint per aggiornare il saldo di un utente
    @PutMapping("/aggiorna-saldo")
    public ResponseEntity<String> aggiornaSaldo(@RequestBody Map<String, String> requestBody) {
        double nuovoSaldo = Double.parseDouble(requestBody.get("saldo"));
        String username = requestBody.get("username");
        try {
            userService.aggiornaSaldo(username, nuovoSaldo);
            return ResponseEntity.ok("Saldo aggiornato con successo");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Errore del server interno");
        }
    }

    // Endpoint per aggiornare il saldo di un utente
    @PutMapping("/aggiorna-carta")
    public ResponseEntity<String> aggiornaCarta(@RequestBody Map<String, String> requestBody) {
        String username = requestBody.get("username");
        String carta = requestBody.get("carta");
        try {
            userService.aggiornaCarta(username, carta);
            return ResponseEntity.ok("carta salvata con successo");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Errore del server interno");
        }
    }


    @GetMapping("/username-to-id")
    public ResponseEntity<Integer> getUserId(@RequestParam String username) {
        Optional<User>  user = userService.findUserByUsername(username);
        Integer userId = user.get().getId();
            if (userId != null) {
                return ResponseEntity.ok(userId);
            }
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }



    @PutMapping("/abbonamento")
    public ResponseEntity<String> aggiornaAbbonamento(@RequestBody Map<String, String> requestBody) {
        String username = requestBody.get("username");

        try {
            userService.aggiornaAbbonamento(username);
            return ResponseEntity.ok("Ruolo aggiornato a PREMIUM con successo");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Errore del server interno");
        }
    }

    //------------------------------------------------------------------------------------------------------------------
    @PostMapping("/saldo")
    public ResponseEntity<?> getSaldo(@RequestBody Map<String, String> request) {
        System.out.println("Username ricevuto: " + request.get("username"));

        String username = request.get("username");

        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Errore: Utente non trovato.");
        }

        User user = userOptional.get();
        return ResponseEntity.ok(user.getSaldo());
    }

    @PostMapping("/carta")
    public ResponseEntity<?> getCarta(@RequestBody Map<String, String> request) {
        System.out.println("Username ricevuto: " + request.get("username"));

        String username = request.get("username");

        // Controlla se l'utente esiste
        Optional<User> userOptional = userRepository.findByUsername(username);
        if (!userOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Errore: Utente non trovato.");
        }

        // Controlla se l'utente ha una carta registrata
        User user = userOptional.get();
        boolean cartaPresente = user.getCarta_di_credito() != null && !user.getCarta_di_credito().trim().isEmpty();

        return ResponseEntity.ok(cartaPresente);
    }








    }



