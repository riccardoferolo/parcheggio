package Principale.Parcheggio;

import Principale.Parcheggio.Models.*;

import java.awt.*;
import java.io.*;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

import Principale.Parcheggio.Repository.*;
import Principale.Parcheggio.Security.JwtUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import Principale.Parcheggio.Services.*;
import Principale.Parcheggio.Repository.DelayedReservationRepository;
import Principale.Parcheggio.Services.ChargeRequestService;
import Principale.Parcheggio.Security.HttpsRestTemplateConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.List;

import org.springframework.web.util.UriComponentsBuilder;


@SpringBootApplication(scanBasePackages = {
		"Principale.Parcheggio.Controllers",
		"Principale.Parcheggio.DTO",
		"Principale.Parcheggio.Models",
		"Principale.Parcheggio.Repository",
		"Principale.Parcheggio.Services",
		"Principale.Parcheggio.Security"
})
public class ParcheggioApplication {

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private ChargeRequestService cService;

	@Autowired
	private MacchineService macchineService;

	@Autowired
	private MacchinaRepository macchinaRepository;

	Scanner s = new Scanner(System.in);

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ReservationRepository reservationRepository;

	@Autowired
	private ParkingSpotRepository parkingSpotRepository;

	@Autowired
	private ChargeRequestRepository chargeRequestRepository;

	@Autowired
	private StoricoService storicoService;

	@Autowired
	private MacchinaRepository MacchineRepository;

	@Autowired
	private DelayedReservationRepository delayedReservationRepository;

	@Autowired
	private HttpsRestTemplateConfig httpsRestTemplateConfig;

	@Autowired
	private JwtUtil jwtUtil;

	String targaScelta;

	String UsernameHUE;

	private String token; // Variabile globale per il token JWT

	@Value("${bot.token}")
	private String botToken;
    @Autowired
    private StoricoRepository storicoRepository;



	public static void main(String[] args) throws ParseException {
		int scelta;
		//SpringApplication.run(ParcheggioApplication.class, args);
		Scanner sc = new Scanner(System.in);

		// Avvia il contesto di Spring e ottieni un'istanza gestita di ParcheggioApplication
		System.out.println("🚀 Metodo main avviato!"); // Debug iniziale
		ApplicationContext context = SpringApplication.run(ParcheggioApplication.class, args);
		System.out.println("✅ Contesto Spring avviato correttamente.");

		// Ottieni l'istanza di ParcheggioApplication dal contesto di Spring
		ParcheggioApplication app = context.getBean(ParcheggioApplication.class);

		app.initializeParkingSpot();

		do {
			// Mostra il menu
			System.out.println("MENU:");
			System.out.println("1. Creare utente");
			System.out.println("2. Login utente");
			System.out.println("3. Cerca per username");
			System.out.println("4. Entra Ora");
			System.out.println("5. Prenota");
			System.out.println("6. Creare una nuova macchina");
			System.out.println("7. Cancellare una macchina");
			System.out.println("8. Restituire tutte le macchine di un utente");
			System.out.println("9. Restituire i dettagli di una macchina tramite targa");
			System.out.println("10. cancella prenotazioni e basta");
			System.out.println("11. cancella tutto");
			System.out.println("12. Stampa prima prenotazione in coda");
			System.out.println("13. Aggiorna Saldo");
			System.out.println("14. stampa occupazione parcheggio");
			System.out.println("15. stampa pagamenti");
			System.out.println("16. avvia emulatore");
			System.out.println("17. avvia App Sbarra");
			System.out.println("18. apri sbarra");
			System.out.println("19. chiudi sbarra");
			System.out.println("20. aggiorna costo sosta");
			System.out.println("21. aggiorna costo ricarica");
			System.out.println("22. abbonamento");
			System.out.println("23. segna ritardo");
			System.out.println("24. paga ritardo");
			System.out.println("26. Effettua il logout");
			System.out.println("27. Sposta Soste Finite");
			System.out.println("49. Registra Admin");
			System.out.println("50. avvia Bot");
			System.out.println("51. ferma Bot");

			System.out.println("100. Esci");
			System.out.print("Scegli un'opzione: ");

			// Gestisci input dell'utente
			while (!sc.hasNextInt()) {
				System.out.println("Per favore, inserisci un numero valido.");
				sc.next(); // Consuma l'input non valido
			}
			scelta = sc.nextInt();
			sc.nextLine(); // Pulisce il buffer dopo nextInt()
			String x;
			switch (scelta) {
				case 1:
					x = app.registra();
					System.out.println("Response from API: " + x);
					break;

				case 2:
					x = app.login();
					System.out.println("Response from API: " + x);
					break;

				case 3:
					app.Cerca_User();
					break;

				case 4:
					x = app.prenotaOra();
					System.out.println("Response from API: " + x);
					break;

				case 5:
					x = app.PrenotaPremium();
					System.out.println("Response from API: " + x);
					break;

				case 6:
					app.createMacchina("");
					break;

				case 7:
					app.deleteMacchina();
					break;

				case 8:
					app.getMacchineByUserId();
					break;

				case 9:
					app.getMacchinaByTarga();
					break;

				case 10:
					x = app.cancellaPrenotazioni();
					System.out.println("Response from API: " + x);
					break;

				case 11:
					x = app.Cancellatutto();
					System.out.println("Response from API: " + x);
					break;

				case 12:
					app.stampaCodaPrenotazioni(false);
					break;

				case 13:
					x = app.aggiornaSaldo();
					System.out.println("Response from API: " + x);
					break;

				case 14:
					app.Occupazione();
					break;

				case 15:
					app.stampaPagamenti();
					break;

				case 16:
					app.avviaHueEmulator();
					app.OccupazioneLampadine();
					break;

				case 17:
					app.eseguiSbarra();
					break;

				case 18:
					app.apriSbarra();
					break;

				case 19:
					app.chiudiSbarra();
					break;

				case 20:
					app.aggiornacostoSosta();
					break;

				case 21:
					app.aggiornacostoRicarica();
					break;

				case 22:
					app.Abbonamento();
					break;

				case 23:
					app.SetRitardo();
					break;

				case 24:
					app.pagaRitardo();
					break;

				case 25:
					//app.esciPrimaDalParcheggio();
					break;
				case 26:
					app.logout();
					break;

				case 27:
					app.spostaSoste();
					break;

				case 49:
					app.registraAdmin();
					break;

				case 50:
					app.startBot();
					break;

				case 51:
					app.stopBot();
					break;

				case 100:
					break;

				default:
					System.out.println("Errore: opzione non valida.");
			}
		} while (scelta != 100);

		//exit(0);
	}

	public void initializeParkingSpot() {
		if (parkingSpotRepository.count() == 0) { // Controlla se la tabella è vuota
			ParkingSpot parkingSpot = new ParkingSpot();
			parkingSpot.setId(1); // ID predefinito
			parkingSpot.setPosti_totali_ricarica(1);
			parkingSpot.setPosti_totali_sosta(3);
			parkingSpotRepository.save(parkingSpot);
			//System.out.println("Record aggiunto con id=1 e posti_totali=2");
		} else {
			//System.out.println("Record già presente, nessuna operazione eseguita.");
		}
	}

	//ok
	public String registra() {
		int errore = 0;
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String apiUrl = "https://localhost:8443/api/users/register";

		Map<String, Object> requestBody = new HashMap<>();
		String x = "";

		

		do {
			try {
				errore = 0;

				System.out.print("Inserisci un username: ");
				requestBody.put("username", s.nextLine().trim());

				System.out.print("Inserisci una password: ");
				requestBody.put("password", s.nextLine().trim());

				System.out.print("Inserisci un'email: ");
				requestBody.put("email", s.nextLine().trim());


				// Invio della richiesta POST
				x = restTemplate.postForObject(apiUrl, requestBody, String.class);

			} catch (Exception e) {
				System.out.println("Errore durante la registrazione: " + e.getMessage());
				errore = 1;
			}

		} while (errore == 1);

		return x;

 
		
	}

	public String registraAdmin() {
		int errore = 0;
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String apiUrl = "https://localhost:8443/api/users/register-admin";

		Map<String, Object> requestBody = new HashMap<>();
		String x = "";

		do {
			try {
				errore = 0;

				System.out.print("Inserisci un username: ");
				requestBody.put("username", s.nextLine().trim());

				System.out.print("Inserisci una password: ");
				requestBody.put("password", s.nextLine().trim());

				System.out.print("Inserisci un'email: ");
				requestBody.put("email", s.nextLine().trim());

				// Invio della richiesta POST
				x = restTemplate.postForObject(apiUrl, requestBody, String.class);

			} catch (Exception e) {
				System.out.println("Errore durante la registrazione: " + e.getMessage());
				errore = 1;
			}

		} while (errore == 1);

		return x;
	}

	//ok
	public String login() {
		// Usa HttpsRestTemplateConfig per creare un RestTemplate personalizzato
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		String apiUrl = "https://localhost:8443/api/users/login"; // URL HTTPS corretto
		Map<String, Object> requestBody = new HashMap<>();

		// Richiedi all'utente di inserire le credenziali
		System.out.println("Inserisci la email: ");
		requestBody.put("email", s.next());

		System.out.println("Inserisci la password: ");
		requestBody.put("password", s.next());

		try {
			String jwt = restTemplate.postForObject(apiUrl, requestBody, String.class);
			if (jwt != null && jwt.contains(".")) { // Controlla che il token abbia almeno 2 punti
				this.token = jwt; // Salva il token
				return "Login effettuato con successo!";
			} else {
				return "Errore: Token JWT non valido.";
			}
		} catch (Exception e) {
			return "Errore durante il login: " + e.getMessage();
		}

	}

	//ok
	public void Cerca_User() {
		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		// Verifica del ruolo tramite il token
		String username;
		String ruolo;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
				return;
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.out.println("Errore: Utente non trovato.");
				return;
			}

			ruolo = userOpt.get().getRuolo().toString();
			if (!ruolo.equalsIgnoreCase("ADMIN")) {
				System.out.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
				return;
			}

			System.out.println("Utente autenticato con ruolo ADMIN: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// Creazione del RestTemplate
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		// URL base dell'API
		String apiUrl = "https://localhost:8443/Admin/username";

		// Scanner per leggere l'input utente
		Scanner scanner = new Scanner(System.in);
		System.out.println("Inserisci Username: ");
		String usernameToSearch = scanner.nextLine(); // Legge l'input

		// Aggiunta del parametro di query all'URL
		String urlWithQueryParam = apiUrl + "?username=" + usernameToSearch;

		try {
			// Creazione delle intestazioni HTTP
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT all'intestazione

			HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

			// Esegue la richiesta GET con le intestazioni
			ResponseEntity<String> response = restTemplate.exchange(urlWithQueryParam, HttpMethod.GET, requestEntity, String.class);

			// Stampa la risposta
			System.out.println("Risultato API: " + response.getBody());
		} catch (HttpClientErrorException.NotFound e) {
			// Gestione specifica per 404
			System.out.println("Errore: L'utente con username '" + usernameToSearch + "' non esiste.");
		} catch (Exception e) {
			// Gestione generica degli errori
			System.out.println("Errore durante la chiamata all'API: " + e.getMessage());
		}
	}

	//ok
	public String prenotaOra() throws ParseException {
		if (token == null || token.isEmpty()) {
			return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
		}

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String apiUrl = "https://localhost:8443/chargerequests/new";
		Map<String, Object> requestBody = new HashMap<>();

		// Estrazione dell'username dal token
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				return "Errore: Il token non contiene un username valido.";
			}
			//System.out.println("Utente autenticato: " + username);
		} catch (Exception e) {
			return "Errore durante la validazione del token: " + e.getMessage();
		}

		String risposta = "";
		boolean success = false;
		boolean haRitardi = delayedReservationRepository.existsByUsername(username);

		if (haRitardi) {
			return "❌ Impossibile prenotare: devi prima pagare il ritardo!";
		}
		do {
			try {
				success = false;
				System.out.println("Si vuole ricaricare la sua auto? (si o no):");
				risposta = s.next().toLowerCase();
				if (!risposta.equals("si") && !risposta.equals("no")) {
					System.out.println("Errore nell'inserimento della risposta, riprovare!!!");
				} else if (risposta.equals("si")) {
					System.out.println("Inserisci la percentuale iniziale: ");
					int percentualeInizio = s.nextInt();
					s.nextLine(); // Consuma il carattere newline

					System.out.println("Inserisci la percentuale richiesta: ");
					int percentualeRichiesta = s.nextInt();
					s.nextLine(); // Consuma il carattere newline

					// Cerca l'utente
					Optional<User> user = userRepository.findByUsername(username);
					if (!user.isPresent()) {
						return "Utente non trovato.";
					}

					// Cerca le auto dell'utente
					List<Macchine> auto = cercaauto(user.get().getId(), "si");
					if (auto.isEmpty()) {
						System.out.println("Nessuna macchina associata all'utente.");
						System.out.println("Aggiungere una macchina? (si o no): ");
						String w = s.next().toLowerCase();
						if (w.equals("si")) {
							createMacchina(risposta);
							auto = cercaauto(user.get().getId(), "si");
						} else {
							return "Non puoi prenotare senza avere un'auto nel tuo account.";
						}
					}

					double kw = scegliAuto(auto);

					String durataS = cService.calcola(percentualeInizio, percentualeRichiesta, kw);

					SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
					Time durata = new Time(timeFormatter.parse(durataS).getTime());
					LocalDate data = LocalDate.now();
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
					String dataStr = data.format(formatter);
					Time orario = Time.valueOf(LocalTime.now());
					LocalTime oraFine = orario.toLocalTime().plusHours(durata.toLocalTime().getHour())
							.plusMinutes(durata.toLocalTime().getMinute())
							.plusSeconds(durata.toLocalTime().getSecond());

					if (cService.isReservationAvailableRicarica(data, orario, Time.valueOf(oraFine))) {
						requestBody.put("giorno", dataStr);
						requestBody.put("Percentuale_iniziale", percentualeInizio);
						requestBody.put("Percentuale_richiesta", percentualeRichiesta);
						requestBody.put("ora", orario.toString());
						requestBody.put("durata", durata.toString());
						requestBody.put("oraFine", oraFine.toString());
						requestBody.put("username", username);
						requestBody.put("Targa", targaScelta);
						requestBody.put("Ricarica", true);

						HttpHeaders headers = new HttpHeaders();
						headers.set("Authorization", "Bearer " + token);
						headers.setContentType(MediaType.APPLICATION_JSON);

						HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

						try {
							return restTemplate.postForObject(apiUrl, requestEntity, String.class);
						} catch (Exception e) {
							return "Errore durante la prenotazione: " + e.getMessage();
						}
					} else {
						Time x = cService.findEarliestEndTimeRicarica(data, orario, Time.valueOf(oraFine));
						return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARÀ ALLE: " + x;
					}
				} else if (risposta.equals("no")) {
					// Logica per la sosta senza ricarica
					List<Macchine> auto = cercaauto(userRepository.findByUsername(username).get().getId(), "");
					if (auto.isEmpty()) {
						System.out.println("Nessuna macchina associata all'utente.");
						System.out.println("Aggiungere una macchina? (si o no): ");
						String w = s.next().toLowerCase();
						if (w.equals("si")) {
							createMacchina(risposta);
							auto = cercaauto(userRepository.findByUsername(username).get().getId(), "");
						} else {
							return "Non puoi prenotare senza avere un'auto nel tuo account.";
						}
					}

					double kw = scegliAuto(auto);
					boolean valido = false;
					Time durata = null;

					do {
						System.out.println("Per quanto tempo desidera sostare? (formato HH:mm:ss)");
						String durataS = s.next();
						s.nextLine();
						SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
						try {
							durata = new Time(timeFormatter.parse(durataS).getTime());
							valido = true;
						} catch (Exception e) {
							valido = false;
							System.out.println("Errore nel formato inserito, riprovare.");
						}
					} while (!valido);

					LocalDate data = LocalDate.now();
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
					String dataStr = data.format(formatter);
					Time orario = Time.valueOf(LocalTime.now());
					LocalTime oraFine = orario.toLocalTime().plusHours(durata.toLocalTime().getHour())
							.plusMinutes(durata.toLocalTime().getMinute())
							.plusSeconds(durata.toLocalTime().getSecond());

					if (cService.isReservationAvailable(data, orario, Time.valueOf(oraFine))) {
						requestBody.put("giorno", dataStr);
						requestBody.put("Percentuale_iniziale", null);
						requestBody.put("Percentuale_richiesta", null);
						requestBody.put("ora", orario.toString());
						requestBody.put("durata", durata.toString());
						requestBody.put("oraFine", oraFine.toString());
						requestBody.put("username", username);
						requestBody.put("Targa", targaScelta);
						requestBody.put("Ricarica", null);

						HttpHeaders headers = new HttpHeaders();
						headers.set("Authorization", "Bearer " + token);
						headers.setContentType(MediaType.APPLICATION_JSON);

						HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

						try {
							return restTemplate.postForObject(apiUrl, requestEntity, String.class);
						} catch (Exception e) {
							return "Errore durante la prenotazione: " + e.getMessage();
						}
					} else {
						Time x = cService.findEarliestEndTimeSosta(data, orario, Time.valueOf(oraFine));
						return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARÀ ALLE: " + x;
					}
				}
				success = true;
			} catch (Exception e) {
				System.out.println("Errore durante la prenotazione: " + e.getMessage());
				success = false;
			}
		} while (!risposta.matches("si") && !risposta.matches("no") || success == false);

		return "Prenotazione completata.";
	}

	public String PrenotaPremium() throws ParseException {
		if (token == null || token.isEmpty()) {
			return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
		}

		// Utilizza RestTemplate configurato per HTTPS
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String apiUrl = "https://localhost:8443/chargerequests/new";

		Scanner scanner = new Scanner(System.in);
		Map<String, Object> requestBody = new HashMap<>();

		// Validazione del token JWT
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				return "Errore: Il token non contiene un username valido.";
			}
			System.out.println("Utente autenticato: " + username);
		} catch (Exception e) {
			return "Errore durante la validazione del token: " + e.getMessage();
		}

		String risposta;
		Optional<User> u = userRepository.findByUsername(username);
		Ruolo app = u.get().getRuolo();
		if (app != Ruolo.BASE) {
			// ✅ Controlla se l'utente ha ritardi
			boolean haRitardi = delayedReservationRepository.existsByUsername(username);

			if (haRitardi) {
				return "❌ Impossibile prenotare: devi prima pagare il ritardo!";
			}
			do {
				System.out.println("si vuole ricaricare la sua auto? (si o no):");
				risposta = s.next().toLowerCase();
				if (!risposta.equals("si") && !risposta.equals("no")) {
					System.out.println("errore nell'inserimento della rispsota, riprovare!!!");
					risposta = "";
				} else if (risposta.equals("si")) {
					System.out.println("Inserisci la percentuale iniziale: ");
					int percentuale_inizio = s.nextInt();
					s.nextLine(); // Consuma il carattere newline

					System.out.println("Inserisci la percentuale richiesta: ");
					int Percentage = s.nextInt();
					s.nextLine(); // Consuma il carattere newline

					//questo poi sarà preso dal token direttamente !!!!!!!!!!!!!!!!!
					//System.out.println("Inserisci l'username per la macchina richiesta: ");
					//String username = s.next();
					//s.nextLine(); // Consuma il carattere newline

					Optional<User> user = userRepository.findByUsername(username);
					if (!user.isPresent()) {
						return "Utente non trovato.";
					}

					// Cerca le auto dell'utente
					List<Macchine> auto = cercaauto(user.get().getId(), "si");
					if (auto.isEmpty()) {
						System.out.println("Nessuna macchina associata all'utente.");
						System.out.println("aggiungere una macchina?: (si o no) ");
						String w = s.next().toLowerCase();
						if (w.equals("si")) {
							createMacchina(risposta);
							auto = cercaauto(user.get().getId(), "si");
						} else {
							return "non puoi prenoare senza avere un'auto nel tuo account";
						}
					}

					double kw = scegliAuto(auto);

					String durataS = cService.calcola(percentuale_inizio, Percentage, kw);
					SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
					Time durata = new Time(timeFormatter.parse(durataS).getTime());

					String dataStr;
					LocalDate data = null;
					String dataFormattata = "";
					Boolean valido = false;
					do {
						System.out.println("Inserisci la data in questo formato (dd/MM/yyyy): ");
						dataStr = scanner.nextLine();
						if (isDataValida(dataStr)) {
							DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

							LocalDate data2 = null;
							try {
								data2 = LocalDate.parse(dataStr, inputFormatter);
								// Conversione della data in formato LocalDate (yyyy/MM/dd)
								DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
								dataFormattata = data2.format(outputFormatter);
								try {
									data = LocalDate.parse(dataFormattata, outputFormatter);
									valido = true;
								} catch (Exception e) {
									valido = false;
									System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
								}
							} catch (Exception e) {
								valido = false;
								System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
							}
						} else {
						}
					} while (!valido);


					Time orario = null;
					valido = false;
					do {
						System.out.println("Inserisci l'orario di arrivo in questo formato (HH:mm:ss): ");
						String orarioS = scanner.nextLine();
						if (isOrarioValido(orarioS, data)) {
							try {
								orario = Time.valueOf(orarioS);
								valido = true;
							} catch (Exception e) {
								valido = false;
								System.out.println("Errore: il formato dell'orario è errato. Usa il formato HH:mm:ss.");
							}
						} else {
						}
					} while (!valido);

					// Conversione a LocalTime per effettuare i calcoli
					LocalTime localOraInizio = orario.toLocalTime();
					LocalTime localDurata = durata.toLocalTime();

					// Calcola oraFine
					LocalTime orafine = localOraInizio.plusHours(localDurata.getHour())
							.plusMinutes(localDurata.getMinute())
							.plusSeconds(localDurata.getSecond());

					// Assicurati che sia nel formato "HH:mm:ss"
					DateTimeFormatter timeFormatter2 = DateTimeFormatter.ofPattern("HH:mm:ss");
					String oraFineStr = orafine.format(timeFormatter2);
					Time oraFine = new Time(timeFormatter.parse(oraFineStr).getTime());

					if (cService.isReservationAvailableRicarica(data, orario, oraFine)) {
						requestBody.put("giorno", dataFormattata); // Già una stringa
						requestBody.put("Percentuale_iniziale", percentuale_inizio); // Integer va bene
						requestBody.put("Percentuale_richiesta", Percentage); // Integer va bene
						requestBody.put("ora", orario.toString()); // Converte in String
						requestBody.put("durata", durata.toString()); // Converte in String
						requestBody.put("oraFine", oraFine.toString()); // Converte in String
						requestBody.put("username", username); // Già una stringa
						requestBody.put("Targa", targaScelta);
						requestBody.put("Ricarica", true);

						HttpHeaders headers = new HttpHeaders();
						headers.set("Authorization", "Bearer " + token);
						headers.setContentType(MediaType.APPLICATION_JSON);

						HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

						try {
							// Invio della richiesta POST e restituzione della risposta
							return restTemplate.postForObject(apiUrl, requestEntity, String.class);
						} catch (Exception e) {
							// Gestione degli errori del server
							return "Errore durante il login: " + e.getMessage();
						}
					} else {
						Time x = cService.findEarliestEndTimeRicarica(data, orario, oraFine);
						return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARà ALLE:" + x;
					}
				} else if (risposta.equals("no")) {
					//questo poi sarà preso dal token direttamente !!!!!!!!!!!!!!!!!
					//System.out.println("Inserisci l'username per la macchina richiesta: ");
					//String username = s.next();
					s.nextLine(); // Consuma il carattere newline

					Optional<User> user = userRepository.findByUsername(username);
					if (!user.isPresent()) {
						return "Utente non trovato.";
					}

					// Cerca le auto dell'utente
					List<Macchine> auto = cercaauto(user.get().getId(), "");
					if (auto.isEmpty()) {
						System.out.println("Nessuna macchina associata all'utente.");
						System.out.println("aggiungere una macchina?: (si o no) ");
						String w = s.next().toLowerCase();
						if (w.equals("si")) {
							createMacchina(risposta);
							auto = cercaauto(user.get().getId(), "");
						} else {
							return "non puoi prenoare senza avere un'auto nel tuo account";
						}
					}

					double kw = scegliAuto(auto);

					Boolean valido = false;
					Time durata = null;
					do {
						System.out.println("quanto vuole restare?:(formato HH:MM:SS) ");
						String durataS = s.next();
						s.nextLine();
						SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
						try {
							durata = new Time(timeFormatter.parse(durataS).getTime());
							valido = true;
						} catch (Exception e) {
							System.out.println("errore nel formato della durata riprovare");
							valido = false;
						}
					} while (valido == false);

					String dataStr;
					LocalDate data = null;
					String dataFormattata = "";
					valido = false;
					do {
						System.out.println("Inserisci la data in questo formato (dd/MM/yyyy): ");
						dataStr = scanner.nextLine();

						DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

						LocalDate data2 = null;
						// Parsing della stringa in LocalDate
						if (isDataValida(dataStr)) {
							try {
								data2 = LocalDate.parse(dataStr, inputFormatter);
								// Conversione della data in formato LocalDate (yyyy/MM/dd)
								DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
								dataFormattata = data2.format(outputFormatter);
								try {
									data = LocalDate.parse(dataFormattata, outputFormatter);
									valido = true;
								} catch (Exception e) {
									valido = false;
									System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
								}
							} catch (Exception e) {
								valido = false;
								System.out.println("Errore: il formato della data è errato. Usa il formato dd/MM/yyyy.");
							}
						} else {
						}
					} while (valido == false);


					Time orario = null;
					valido = false;
					SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
					do {
						System.out.println("Inserisci l'orario di arrivo in questo formato (HH:mm:ss): ");
						String orarioS = scanner.nextLine();
						if (isOrarioValido(orarioS, data)) {
							try {
								orario = Time.valueOf(orarioS);
								valido = true;
							} catch (Exception e) {
								valido = false;
								System.out.println("Errore: il formato dell'orario è errato. Usa il formato HH:mm:ss.");
							}
						} else {
						}
					} while (valido == false);

					// Conversione a LocalTime per effettuare i calcoli
					LocalTime localOraInizio = orario.toLocalTime();
					LocalTime localDurata = durata.toLocalTime();

					// Calcola oraFine
					LocalTime orafine = localOraInizio.plusHours(localDurata.getHour())
							.plusMinutes(localDurata.getMinute())
							.plusSeconds(localDurata.getSecond());

					// Assicurati che sia nel formato "HH:mm:ss"
					DateTimeFormatter timeFormatter2 = DateTimeFormatter.ofPattern("HH:mm:ss");
					String oraFineStr = orafine.format(timeFormatter2);
					Time oraFine = new Time(timeFormatter.parse(oraFineStr).getTime());

					if (cService.isReservationAvailable(data, orario, oraFine)) {
						requestBody.put("giorno", dataFormattata); // Già una stringa
						requestBody.put("Percentuale_iniziale", null); // Integer va bene
						requestBody.put("Percentuale_richiesta", null); // Integer va bene
						requestBody.put("ora", orario.toString()); // Converte in String
						requestBody.put("durata", durata.toString()); // Converte in String
						requestBody.put("oraFine", oraFine.toString()); // Converte in String
						requestBody.put("username", username); // Già una stringa
						requestBody.put("Targa", targaScelta);
						requestBody.put("Ricarica", null);

						HttpHeaders headers = new HttpHeaders();
						headers.set("Authorization", "Bearer " + token);
						headers.setContentType(MediaType.APPLICATION_JSON);

						HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);


						try {
							// Invio della richiesta POST e restituzione della risposta
							return restTemplate.postForObject(apiUrl, requestEntity, String.class);
						} catch (Exception e) {
							// Gestione degli errori del server
							e.printStackTrace();
							return "Errore durante il login: " + e.getMessage();
						}
					} else {
						Time x = cService.findEarliestEndTimeSosta(data, orario, oraFine);
						return "PARCHEGGIO PIENO, RIPROVARE DOPO. IL PRIMO POSTO DISPONIBILE SARà ALLE:" + x;
					}
				}
			} while (!risposta.matches("si") && !risposta.matches("no"));
			return "prenotato";
		} else {
			return "Errore: per prenotare devi essere utente PREMIUM, abbonati prima";
		}
	}


	public static boolean isDataValida(String dataStr) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

		try {
			LocalDate dataInserita = LocalDate.parse(dataStr, formatter);
			LocalDate oggi = LocalDate.now();

			// Controlla che la data non sia prima di oggi
			if (dataInserita.isBefore(oggi)) {
				System.out.println("Errore: La data inserita è nel passato. Inserisci una data odierna o futura.");
				return false;
			}

			// Estraggo giorno, mese e anno dalla stringa
			String[] partiData = dataStr.split("/");
			int giorno = Integer.parseInt(partiData[0]);
			int mese = Integer.parseInt(partiData[1]);
			int anno = Integer.parseInt(partiData[2]);

			// Controlla che il mese sia tra 1 e 12
			if (mese < 1 || mese > 12) {
				System.out.println("Errore: Il mese deve essere compreso tra 1 e 12.");
				return false;
			}

			// Controlla che il giorno sia valido per il mese e anno inseriti
			YearMonth annoMese = YearMonth.of(anno, mese);
			int giorniNelMese = annoMese.lengthOfMonth(); // Ottiene il numero di giorni validi per il mese

			if (giorno < 1 || giorno > giorniNelMese) {
				System.out.println("Errore: Il giorno inserito non è valido per il mese e l'anno specificati.");
				return false;
			}

			return true; // La data è valida

		} catch (Exception e) {
			System.out.println("Errore nella data inserita, CONTROLLA E RIMETTILA");
			return false;
		}
	}

	public static boolean isOrarioValido(String orarioStr, LocalDate dataInserita) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		LocalTime orarioInserito;

		// 1. Controlla il formato dell'orario prima di validare i valori
		try {
			orarioInserito = LocalTime.parse(orarioStr, formatter);
		} catch (DateTimeParseException e) {
			System.out.println("Errore: Il formato dell'orario è errato. Usa il formato HH:mm:ss.");
			return false;
		}

		// 2. Definizione dei limiti orari
		LocalTime oraAttuale = LocalTime.now();
		LocalTime oraMinima = LocalTime.of(9, 0);  // 09:00
		LocalTime oraMassima = LocalTime.of(20, 0); // 20:00
		LocalDate oggi = LocalDate.now();

		// 3. Controllo delle condizioni di validità
		if (dataInserita.isEqual(oggi)) { // Se la data è oggi
			if (orarioInserito.isBefore(oraAttuale)) {
				System.out.println("Errore: L'orario deve essere successivo all'orario attuale.");
				return false;
			}
			if (orarioInserito.isAfter(oraMassima)) {
				System.out.println("Errore: L'orario non può superare le 20:00.");
				return false;
			}
		} else if (dataInserita.isAfter(oggi)) { // Se la data è futura
			if (orarioInserito.isBefore(oraMinima) || orarioInserito.isAfter(oraMassima)) {
				System.out.println("Errore: L'orario deve essere compreso tra le 09:00 e le 20:00.");
				return false;
			}
		}

		return true; // Orario valido!
	}

	public String Cancellatutto() {
		if (token == null || token.isEmpty()) {
			return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
		}

		String username;
		String ruolo;

		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				return "Errore: Il token non contiene un username valido.";
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				return "Errore: Utente non trovato.";
			}

			ruolo = userOpt.get().getRuolo().toString();

			if (!ruolo.equalsIgnoreCase("ADMIN")) {
				return "Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.";
			}

			System.out.println("Utente autenticato con ruolo ADMIN: " + username);
		} catch (Exception e) {
			return "Errore durante la validazione del token: " + e.getMessage();
		}

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String[] urls = {
				"https://localhost:8443/Admin/reservation/delete-all",
				"https://localhost:8443/Admin/delayedreservation/delete-all",
				"https://localhost:8443/Admin/payment/delete-all",
				"https://localhost:8443/Admin/charge/delete-all",
				"https://localhost:8443/Admin/macchine/deleteALL",
				"https://localhost:8443/Admin/user/delete-all"
		};

		String x = "";

		for (String url : urls) {
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT
				HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

				restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, Void.class);
			} catch (Exception e) {
				System.err.println("Errore durante l'eliminazione della risorsa: " + e.getMessage());
				e.printStackTrace();
				return "Errore durante l'eliminazione della risorsa: " + e.getMessage();
			}
		}

		try {
			parkingSpotRepository.deleteAll();
			parkingSpotRepository.resetAutoIncrement();
			x = "Eliminato tutto con successo.";
		} catch (Exception e) {
			System.err.println("Errore durante l'eliminazione della risorsa dal database: " + e.getMessage());
			e.printStackTrace();
			return "Errore durante l'eliminazione delle risorse locali: " + e.getMessage();
		}

		return x;
	}

	private String cancellaPrenotazioni() {
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String Reservation_url = "https://localhost:8443/Admin/reservation/delete-all";
		String payment_url = "https://localhost:8443/Admin/payment/delete-all";
		String charge_url = "https://localhost:8443/Admin/charge/delete-all";
		String x = "";
		//String Reservation_reset = "http://localhost:8080/reservations/reset";

		if (token == null || token.isEmpty()) {
			return "Errore: Token JWT mancante. Effettua il login prima di procedere.";
		}

		// Estrai il ruolo dal token e verifica che sia ADMIN
		String username;
		String ruolo;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				return "Errore: Il token non contiene un username valido.";
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				return "Errore: Utente non trovato.";
			}

			ruolo = userOpt.get().getRuolo().toString();
			if (!ruolo.equalsIgnoreCase("ADMIN")) {
				return "Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.";
			}

			System.out.println("Utente autenticato con ruolo: " + ruolo);
		} catch (Exception e) {
			return "Errore durante la validazione del token: " + e.getMessage();
		}

		// Configura le intestazioni con il token JWT
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token);
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

		// Esegui le chiamate per cancellare le prenotazioni, pagamenti e richieste di ricarica
		try {
			restTemplate.exchange(Reservation_url, HttpMethod.DELETE, requestEntity, Void.class);
			restTemplate.exchange(payment_url, HttpMethod.DELETE, requestEntity, Void.class);
			restTemplate.exchange(charge_url, HttpMethod.DELETE, requestEntity, Void.class);

			x = "Eliminate le prenotazioni, i pagamenti e le richieste di ricarica con successo.";
		} catch (Exception e) {
			System.err.println("Errore durante l'eliminazione della risorsa: " + e.getMessage());
			e.printStackTrace();
			return "Errore durante l'eliminazione delle risorse: " + e.getMessage();
		}

		return x;
	}

	private List<Macchine> cercaauto(Integer id, String r) {
		List<Macchine> auto = List.of();
		if (r.matches("si")) {
			auto = MacchineRepository.findAllByUserIdElettriche(id);
		} else if (r.matches("")) {
			auto = MacchineRepository.findByUserId(id);
		}

		return auto;
	}

	private double scegliAuto(List<Macchine> auto) {
		if (auto == null || auto.isEmpty()) {
			throw new IllegalArgumentException("La lista delle auto è vuota o nulla.");
		}

		Scanner s = new Scanner(System.in);

		// Stampa le targhe disponibili
		System.out.println("Scegli tra le seguenti targhe:");
		for (Macchine macchina : auto) {
			System.out.println("- " + macchina.getTarga());
		}

		while (true) {
			// Leggi la targa inserita dall'utente
			System.out.print("Inserisci la targa: ");
			targaScelta = s.nextLine().trim().toUpperCase();

			// Cerca la macchina corrispondente
			for (Macchine macchina : auto) {
				if (macchina.getTarga().equalsIgnoreCase(targaScelta)) {
					// Restituisci i kW della macchina trovata
					return macchina.getKwBatteria();
				}
			}

			// Se la targa non è valida, chiedi di riprovare
			System.out.println("Targa non trovata. Riprova.");
		}
	}

	//ok
	public void createMacchina(String risp) {
		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		Scanner scanner = new Scanner(System.in);

		String targa;

		do {
			System.out.print("Inserisci la targa (rispettando gli standard italiani): ");
			targa = scanner.nextLine().trim().toUpperCase();

			if (macchineService.isValidTargaItaliana(targa)) {
				System.out.println("Targa valida: " + targa);
				break;
			} else {
				System.out.println("Errore: La targa non rispetta gli standard italiani. Riprova.");
			}
		} while (true);

		if (risp.isEmpty()) {
			do {
				System.out.println("è elettrica? (si o no): ");
				risp = scanner.nextLine();
				if (!risp.matches("si") && !risp.matches("no")) {
					System.out.println("risposta non valida, rifare");
				}
			} while (!risp.matches("si") && !risp.matches("no"));
		}
		double kwBatteria = 0;
		if (risp.equals("si")) {
			do {
				try {
					System.out.print("Inserisci i kW della batteria (se non elettrica mettere 0): ");
					kwBatteria = scanner.nextDouble();
					scanner.nextLine(); // Consuma la newline
					if (kwBatteria == 0) System.out.println("deve essere elettrica");
				}catch(InputMismatchException e) {
					System.err.println("NON PUOI METTERE LETTERE!!!!!!");
					scanner.nextLine();
				}
			} while (kwBatteria == 0);
		}
		if (risp.equals("no")) {
			kwBatteria = 0;
		}

		System.out.print("Inserisci il modello dell'auto: ");
		String modello = scanner.nextLine();

		// Estrai l'username dal token
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
				return;
			}
			System.out.println("Utente autenticato: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// Trova l'utente nel repository
		User user = userRepository.findByUsername(username).orElse(null);
		if (user == null) {
			System.out.println("Errore: Utente non trovato nel database per username: " + username);
			return;
		}

		System.out.println("Utente trovato: " + user.getUsername());

		int userId = user.getId();

		// Prepara i parametri della richiesta
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		params.add("targa", targa);
		params.add("kwBatteria", String.valueOf(kwBatteria));
		params.add("modello", modello);
		params.add("userId", String.valueOf(userId));

		// Prepara le intestazioni
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token);
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED); // Usa form-urlencoded

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(params, headers);


		String url = "https://localhost:8443/api/macchine/create";

		try {
			ResponseEntity<Macchine> response = restTemplate.postForEntity(url, request, Macchine.class);
			System.out.println("Macchina creata: " + response.getBody());
		} catch (Exception e) {
			System.err.println("Errore durante la creazione della macchina: " + e.getMessage());
		}
	}

	//
	public void deleteMacchina() {
		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		Scanner scanner = new Scanner(System.in);

		System.out.print("Inserisci la targa della macchina da cancellare: ");
		String targa = scanner.nextLine();

		List<Macchine> x = macchinaRepository.findAll();
		Boolean trovato = false;
		for(Macchine m : x){
			if(m.getTarga().equals(targa)){
				trovato = true;
			}
		}

		if(trovato) {
			// Costruzione dell'URL con parametro query
			String url = UriComponentsBuilder.fromHttpUrl("https://localhost:8443/Admin/macchine/delete")
					.queryParam("targa", targa)
					.toUriString();

			// Creazione delle intestazioni con il token JWT
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT

			HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

			try {
				// Esegui la richiesta DELETE con il token
				restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, Void.class);
				System.out.println("Macchina con targa " + targa + " cancellata.");
			} catch (Exception e) {
				System.err.println("Errore durante la cancellazione della macchina: " + e.getMessage());
			}
		}
		else{
			System.out.println("Errore: MACCHINA INESISTENTE CON QUELLA TARGA!!!!!!");
			System.out.flush(); // Assicura che il messaggio venga stampato subito prima del menu
		}
	}

	//ok
	public void getMacchineByUserId() {
		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		// Extract username from the token
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
				return;
			}
			//System.out.println("Utente autenticato: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// Use HTTPS RestTemplate configuration
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		// Base URL dell'API
		String baseUrl = "https://localhost:8443/api/macchine/byUser";

		// Costruzione dinamica dell'URL con query string
		String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
				.queryParam("username", username)
				.toUriString();

		try {
			// Creazione delle intestazioni con il token JWT
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT
			headers.setContentType(MediaType.APPLICATION_JSON);

			HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

			// Richiesta HTTP
			ResponseEntity<List<Macchine>> response = restTemplate.exchange(
					url, HttpMethod.GET, requestEntity, new ParameterizedTypeReference<List<Macchine>>() {
					}
			);

			List<Macchine> macchine = response.getBody();
			if (macchine != null && !macchine.isEmpty()) {
				System.out.println("Macchine associate all'utente con ID " + username + ":");
				for (Macchine macchina : macchine) {
					System.out.println(macchina);
				}
			} else {
				System.out.println("Nessuna macchina trovata per l'utente con ID " + username);
			}
		} catch (HttpClientErrorException.NotFound e) {
			System.out.println("Errore: Utente non trovato o nessuna macchina associata.");
		} catch (Exception e) {
			System.out.println("Errore durante la chiamata all'API: " + e.getMessage());
		}
	}

	//ok
	public void getMacchinaByTarga() {
		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}


		Optional<User> userOpt = userRepository.findByUsername(jwtUtil.validateToken(token));


		String ruolo = userOpt.get().getRuolo().toString();
		if (!ruolo.equalsIgnoreCase("ADMIN")) {
			System.out.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
			return;
		}

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		Scanner scanner = new Scanner(System.in);

		System.out.print("Inserisci la targa della macchina: ");
		String targa = scanner.nextLine();

		List<Macchine> x = macchinaRepository.findAll();
		Boolean trovato = false;
		for(Macchine m : x){
			if(m.getTarga().equals(targa)){
				trovato = true;
			}
		}

		if(trovato) {

			// Base URL dell'API
			String baseUrl = "https://localhost:8443/api/macchine/byTarga";

			// Costruzione dinamica dell'URL con query string
			String url = UriComponentsBuilder.fromHttpUrl(baseUrl)
					.queryParam("targa", targa)
					.toUriString();

			// Creazione delle intestazioni con il token JWT
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT

			HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

			try {
				// Richiesta HTTP con token e gestione della risposta
				ResponseEntity<Macchine> response = restTemplate.exchange(
						url, HttpMethod.GET, requestEntity, Macchine.class
				);

				if (response.getStatusCode().is2xxSuccessful()) {
					Macchine macchina = response.getBody();
					System.out.println("Dettagli della macchina con targa " + targa + ": " + macchina);
				} else {
					System.out.println("Macchina con targa " + targa + " non trovata.");
				}
			} catch (Exception e) {
				System.err.println("Errore durante il recupero dei dettagli della macchina: " + e.getMessage());
			}
		}
		else{
			System.out.println("Errore: MACCHINA INESISTENTE CON QUELLA TARGA!!!!!!");
			System.out.flush(); // Assicura che il messaggio venga stampato subito prima del menu
		}
	}

	//ok
	public Reservation stampaCodaPrenotazioni(Boolean bot) {
		String tk = bot ? botToken : token;

		if (tk == null || tk.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
		}

		String username;
		String ruolo;

		/*
		try {
			username = jwtUtil.validateToken(tk);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.out.println("Errore: Utente non trovato.");
			}

			System.out.println("Utente autenticato con ruolo ADMIN: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
		}
*/

		System.out.println("📢 DEBUG: Entrato in stampaCodaPrenotazioni()");
		// Crea un nuovo RestTemplate con configurazione personalizzata
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		System.out.println("📢 DEBUG: Creato RestTemplate");

		System.out.println("✅ DEBUG: Token valido, procedo con la richiesta.");

		// Verifica se Spring è ancora attivo
		if (!isSpringContextActive()) {
			System.out.println("⚠️ Spring sta chiudendo, interrompendo richiesta.");
			return null;
		}

		System.out.println("✅ DEBUG: Spring è attivo, procedo con la richiesta REST.");

		// Configura le intestazioni della richiesta con il token
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + tk);  // Aggiungi il token JWT
		headers.set("Content-Type", "application/json");

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		try {
			String url = "https://localhost:8443/reservations/coda";
			ResponseEntity<Reservation> response = restTemplate.exchange(
					url, HttpMethod.GET, requestEntity, Reservation.class);

			System.out.println("✅ DEBUG: Risposta ricevuta, codice: " + response.getStatusCode());

			if (response.getStatusCode() == HttpStatus.NO_CONTENT) {
				System.out.println("⚠️ Nessuna prenotazione trovata nella coda.");
				return null;
			}

			return response.getBody();

		} catch (Exception e) {
			System.out.println("❌ Errore durante il recupero delle prenotazioni: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}


	private boolean isSpringContextActive() {
		if (applicationContext instanceof ConfigurableApplicationContext) {
			return ((ConfigurableApplicationContext) applicationContext).isRunning();
		}
		return false;
	}

	//ok
	public String aggiornaSaldo() {
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		Map<String, Object> requestBody = new HashMap<>();

		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return "Token JWT mancante";
		}

		// Estrazione dell'username dal token
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				return "Errore: Il token non contiene un username valido.";
			}
			//System.out.println("Utente autenticato: " + username);
		} catch (Exception e) {
			return "Errore durante la validazione del token: " + e.getMessage();
		}

		// Trova l'utente nel repository
		Optional<User> user = userRepository.findByUsername(username);
		if (user.isEmpty()) {
			return "Errore: Utente non trovato.";
		}

		// Verifica se l'utente ha una carta di credito salvata
		if (user.get().getCarta_di_credito() == null || user.get().getCarta_di_credito().isEmpty()) {
			String cartaDiCredito;
			boolean cartaValida;
			do {
				System.out.println("Inserisci la carta di credito:");
				cartaDiCredito = s.next();
				if (!isValidCreditCard(cartaDiCredito)) {
					System.out.println("Numero di carta di credito invalido.");
					cartaValida = false;
				} else {
					cartaValida = true;
				}
			} while (!cartaValida);

			String risposta;
			do {
				System.out.println("Si vuole salvare il metodo di pagamento nel proprio profilo? (si o no):");
				risposta = s.next().toLowerCase();
				if (risposta.matches("si")) {
					String url = "https://localhost:8443/api/users/aggiorna-carta";
					requestBody.put("carta", cartaDiCredito);
					requestBody.put("username", username);

					HttpHeaders headers = new HttpHeaders();
					headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT
					headers.setContentType(MediaType.APPLICATION_JSON);

					try {
						HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);
						String response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class).getBody();
						System.out.println(response);
					} catch (Exception e) {
						return "Errore durante l'aggiornamento della carta: " + e.getMessage();
					}
				} else if (risposta.matches("no")) {
					System.out.println("Carta usata solo questa volta e non salvata.");
				} else {
					System.out.println("Errore nell'inserimento della risposta, riprovare!!!");
				}
			} while (!risposta.matches("si") && !risposta.matches("no"));
		}

		// Inserimento del saldo
		double saldo;
		s.nextLine();
		while (true) {
			//s.nextLine();
			System.out.println("Inserisci il saldo: ");
			double input = s.nextDouble();
			try {
				saldo = input;
				if (saldo > 0) {
					break;
				} else {
					System.out.println("Il saldo deve essere maggiore di 0. Riprova.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Input non valido. Inserisci un numero valido.");
			}
		}

		System.out.println("Saldo inserito correttamente: " + saldo);

		// Preparazione della richiesta per aggiornare il saldo
		String url = "https://localhost:8443/api/users/aggiorna-saldo";
		requestBody.clear();
		requestBody.put("saldo", saldo);
		requestBody.put("username", username);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT
		headers.setContentType(MediaType.APPLICATION_JSON);

		try {
			HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);
			return restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class).getBody();
		} catch (Exception e) {
			return "Errore durante l'aggiornamento del saldo: " + e.getMessage();
		}
	}

	public static boolean isValidCreditCard(String cardNumber) {
		if (cardNumber == null || cardNumber.isEmpty()) {
			return false;
		}

		// Rimuove eventuali spazi o trattini
		cardNumber = cardNumber.replaceAll("\\s|-", "");

		// Verifica che sia composto solo da cifre
		if (!cardNumber.matches("\\d+")) {
			return false;
		}

		// Algoritmo di Luhn
		int sum = 0;
		boolean alternate = false;
		for (int i = cardNumber.length() - 1; i >= 0; i--) {
			int n = Character.getNumericValue(cardNumber.charAt(i));
			if (alternate) {
				n *= 2;
				if (n > 9) {
					n -= 9;
				}
			}
			sum += n;
			alternate = !alternate;
		}

		// È valido se la somma è divisibile per 10
		return sum % 10 == 0;
	}

	//ok
	public void Occupazione() {
		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String url = "https://localhost:8443/reservations/occupazione";

		try {
			// Crea le intestazioni e aggiungi il token JWT
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + token);

			// Creazione della richiesta HTTP
			HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

			// Richiama l'API con le intestazioni
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);

			// Stampa il messaggio
			System.out.println(response.getBody());

		} catch (Exception e) {
			System.err.println("Errore durante la chiamata all'API: " + e.getMessage());
		}
	}

	//Ok
	public void stampaPagamenti() {
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		String url = "https://localhost:8443/api/payments/listaPagamenti";

		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		// Estrazione dell'username e del ruolo dal token
		String username;
		String ruolo;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
				return;
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.out.println("Errore: Utente non trovato.");
				return;
			}

			ruolo = userOpt.get().getRuolo().toString();
			if (!ruolo.equalsIgnoreCase("ADMIN")) {
				System.out.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
				return;
			}

			System.out.println("Utente autenticato con ruolo: " + ruolo);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		int scelta = 0;
		int ok = 0;
		while (true) {
			try {
				while(ok == 0){
					ok = 1;
					try {
						System.out.println("\nScegli il criterio di ricerca per i pagamenti:");
						System.out.println("1. Tipo di prenotazione (ricarica/sosta)");
						System.out.println("2. Ruolo dell'utente (base/premium)");
						System.out.println("0. Torna al menu principale");
						System.out.print("Inserisci la tua scelta: ");
						scelta = s.nextInt();

						if(scelta!= 0 && scelta != 1 && scelta != 2){
							System.out.println("ERRORE --> Inserisci un numero valido.");
							s.nextLine();
							ok = 0;
						}
					}catch (InputMismatchException e){
						System.out.println("Errore --> non puoi inserire lettere");
						s.nextLine();
						ok = 0;
					}
				}

				if (scelta == 0) {
					System.out.println("Tornando al menu principale...");
					return;
				}

				Map<String, Object> params = new HashMap<>();

				if (scelta == 1) {
					while (true) {
						System.out.print("Vuoi cercare pagamenti per ricarica (true) o sosta (false)? ");
						String input = s.next();
						if (input.equalsIgnoreCase("true") || input.equalsIgnoreCase("false")) {
							params.put("ricarica", Boolean.parseBoolean(input));
							break;
						} else {
							System.out.println("Input non valido. Inserisci 'true' o 'false'.");
						}
					}
				} else if (scelta == 2) {
					while (true) {
						System.out.print("Vuoi cercare pagamenti per utenti base o premium? (BASE/PREMIUM): ");
						String userRole = s.next().toUpperCase();
						if (userRole.equals("BASE") || userRole.equals("PREMIUM")) {
							params.put("ruolo", userRole);
							break;
						} else {
							System.out.println("Input non valido. Inserisci 'BASE' o 'PREMIUM'.");
						}
					}
				} else {
					System.out.println("Scelta non valida. Riprova.");
					continue;
				}

				// Configura le intestazioni con il token JWT
				HttpHeaders headers = new HttpHeaders();
				headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT
				headers.setContentType(MediaType.APPLICATION_JSON);

				HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(params, headers);

				// Chiamata all'API
				ResponseEntity<List> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, List.class);

				// Stampa tabellata direttamente
				List<Map<String, Object>> payments = response.getBody();

				if (payments == null || payments.isEmpty()) {
					System.out.println("Nessun pagamento trovato.");
				} else {
					System.out.printf("%-10s %-10s %-15s %-10s %-10s %-15s%n", "ID", "Totale", "Utente", "Ruolo", "Tipo", "Targa");
					System.out.println("-----------------------------------------------------------------------");

					for (Map<String, Object> payment : payments) {
						String id = payment.get("id") != null ? payment.get("id").toString() : "N/A";
						String totalAmount = payment.get("totalAmount") != null
								? String.format("%.2f", Double.parseDouble(payment.get("totalAmount").toString()))
								: "N/A";
						String usernamePayment = payment.get("user") != null && ((Map<String, Object>) payment.get("user")).get("username") != null
								? ((Map<String, Object>) payment.get("user")).get("username").toString()
								: "N/A";
						String role = payment.get("user") != null && ((Map<String, Object>) payment.get("user")).get("ruolo") != null
								? ((Map<String, Object>) payment.get("user")).get("ruolo").toString()
								: "N/A";
						String type = payment.get("chargeRequest") != null && ((Map<String, Object>) payment.get("chargeRequest")).get("ricarica") != null
								? (((Boolean) ((Map<String, Object>) payment.get("chargeRequest")).get("ricarica")) ? "Ricarica" : "Sosta")
								: "Sosta";
						String targa = payment.get("chargeRequest") != null && ((Map<String, Object>) payment.get("chargeRequest")).get("targa") != null
								? ((Map<String, Object>) payment.get("chargeRequest")).get("targa").toString()
								: "N/A";

						System.out.printf("%-10s %-10s %-15s %-10s %-10s %-15s%n", id, totalAmount, usernamePayment, role, type, targa);
					}
					return;
				}
			} catch (Exception e) {
				System.err.println("Errore durante la chiamata all'API: " + e.getMessage());
			}
		}
	}

	public void aggiornaLampadine(int postiTotSosta, int postiTotRicarica, Long postiSostaOccupati, Long postiRicaricaOccupati) {
		String hueBridgeUrl = "http://localhost:8000/api/" + UsernameHUE + "/lights";
		RestTemplate restTemplate = new RestTemplate();

		// Lampadina 1 -> Sosta, Lampadina 2 -> Ricarica
		aggiornaStatoLampadina(restTemplate, hueBridgeUrl, 1, postiSostaOccupati < postiTotSosta); // Verde se ci sono posti liberi
		aggiornaStatoLampadina(restTemplate, hueBridgeUrl, 2, postiRicaricaOccupati < postiTotRicarica); // Verde se ci sono posti liberi
	}

	private void aggiornaStatoLampadina(RestTemplate restTemplate, String hueBridgeUrl, int lampId, boolean disponibile) {
		String lampUrl = hueBridgeUrl + "/" + lampId + "/state";

		// Prepara il corpo della richiesta
		Map<String, Object> lampState = new HashMap<>();
		lampState.put("on", true); // La lampadina è sempre accesa
		lampState.put("bri", 254); // Luminosità massima
		lampState.put("hue", disponibile ? 25500 : 0); // Verde se disponibile, rosso altrimenti

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Map<String, Object>> request = new HttpEntity<>(lampState, headers);

			restTemplate.put(lampUrl, request);
			System.out.println("Lampadina " + lampId + " aggiornata: " + (disponibile ? "Verde" : "Rossa"));
		} catch (Exception e) {
			System.err.println("Errore durante l'aggiornamento della lampadina " + lampId + ": " + e.getMessage());
		}
	}

	public void OccupazioneLampadine() {
		List<Reservation> reservations = reservationRepository.findAll();

		Optional<ParkingSpot> optionalParkingSpot = parkingSpotRepository.findById(1);
		if (!optionalParkingSpot.isPresent()) {
			System.out.println("Nessun record di parcheggio trovato.");
			return;
		}
		ParkingSpot parkingSpot = optionalParkingSpot.get();
		int postiTotRicarica = parkingSpot.getPosti_totali_ricarica();
		int postiTotSosta = parkingSpot.getPosti_totali_sosta();

		long postiRicaricaOccupati = reservations.stream()
				.filter(reservation -> Boolean.TRUE.equals(reservation.getRicarica()))
				.count();

		long postiSostaOccupati = reservations.stream()
				.filter(reservation -> reservation.getRicarica() == null)
				.count();

		aggiornaLampadine(postiTotSosta, postiTotRicarica, postiSostaOccupati, postiRicaricaOccupati);
	}

	public void avviaHueEmulator() {
		try {
			String[] command = {
					"java", "-jar",
					"HueEmulator-v0.8.jar"
			};

			File projectRoot = new File(".").getCanonicalFile(); // Salire dalla directory corrente 'src' a 'Parcheggio'
			File emulatorDirectory = new File(projectRoot, "Hue-Emulator");

			ProcessBuilder processBuilder = new ProcessBuilder(command);
			processBuilder.directory(emulatorDirectory);
			processBuilder.redirectErrorStream(true);

			Process process = processBuilder.start();

			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line;
			System.out.println("Log dell'emulatore:");

			// Attendi che l'emulatore sia pronto e che il "Link Button" sia premuto
			aspettaEmulatore();

			// Registra un nuovo utente e ottieni l'username
			UsernameHUE = registraUtenteHUE();
			if (UsernameHUE == null) {
				throw new IllegalStateException("Impossibile registrare un utente. Controlla l'emulatore.");
			}

			System.out.println("L'emulatore è stato avviato con successo. Username: " + UsernameHUE);

			// Pulisci le lampadine
			pulisciLampadine();
		} catch (Exception e) {
			System.err.println("Errore durante l'avvio dell'emulatore Hue: " + e.getMessage());
		}
	}

	private void aspettaEmulatore() {
		String hueBridgeUrl = "http://localhost:8000/api";
		RestTemplate restTemplate = new RestTemplate();
		boolean pronto = false;

		System.out.println("Attesa che l'emulatore sia pronto (premi 'Start' nell'emulatore e poi il pulsante 'Link Button')...");

		while (!pronto) {
			try {
				// Tentativo di registrare un utente per verificare lo stato del pulsante "Link Button"
				Map<String, String> requestBody = new HashMap<>();
				requestBody.put("devicetype", "my_hue_app");

				ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
						hueBridgeUrl,
						HttpMethod.POST,
						new HttpEntity<>(requestBody),
						new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
						}
				);

				List<Map<String, Map<String, String>>> body = response.getBody();
				if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
					System.out.println("Pulsante 'Link Button' premuto. L'emulatore è pronto.");
					pronto = true;
					break;
				}
			} catch (Exception e) {
				if (e.getMessage().contains("link button not pressed")) {
					System.out.println("Il pulsante 'Link Button' non è stato premuto. Aspetto...");
				} else {
					System.out.println("L'emulatore non è ancora pronto. Riprovo tra 2 secondi...");
				}
			}

			try {
				Thread.sleep(2000); // Aspetta 2 secondi prima di riprovare
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
				throw new RuntimeException("Attesa interrotta.", ex);
			}
		}
	}

	private void pulisciLampadine() {
		String hueBridgeUrl = "http://localhost:8000/api/" + UsernameHUE + "/lights";
		RestTemplate restTemplate = new RestTemplate();

		try {
			ResponseEntity<String> response = restTemplate.exchange(
					hueBridgeUrl,
					HttpMethod.GET,
					null,
					String.class
			);

			System.out.println("Risposta API grezza: " + response.getBody());

			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> lights = mapper.readValue(response.getBody(), new TypeReference<Map<String, Object>>() {
			});

			if (lights != null) {
				for (String id : lights.keySet()) {
					int lampId = Integer.parseInt(id);
					if (lampId > 2) {
						// Spegni la lampadina
						try {
							String lampUrl = hueBridgeUrl + "/" + lampId + "/state";

							Map<String, Object> lampState = new HashMap<>();
							lampState.put("on", false); // Spegni la lampadina

							HttpHeaders headers = new HttpHeaders();
							headers.setContentType(MediaType.APPLICATION_JSON);
							HttpEntity<Map<String, Object>> request = new HttpEntity<>(lampState, headers);

							restTemplate.put(lampUrl, request);
							System.out.println("Lampadina " + lampId + " spenta.");
						} catch (Exception e) {
							System.err.println("Errore durante lo spegnimento della lampadina " + lampId + ": " + e.getMessage());
						}
					}
				}
			}
		} catch (Exception e) {
			System.err.println("Errore durante la pulizia delle lampadine: " + e.getMessage());
		}
	}

	private String registraUtenteHUE() {
		String hueBridgeUrl = "http://localhost:8000/api";
		RestTemplate restTemplate = new RestTemplate();

		Map<String, String> requestBody = new HashMap<>();
		requestBody.put("devicetype", "my_hue_app");

		try {
			ResponseEntity<List<Map<String, Map<String, String>>>> response = restTemplate.exchange(
					hueBridgeUrl,
					HttpMethod.POST,
					new HttpEntity<>(requestBody),
					new ParameterizedTypeReference<List<Map<String, Map<String, String>>>>() {
					}
			);

			// Estrai il nome utente dalla risposta
			List<Map<String, Map<String, String>>> body = response.getBody();
			if (body != null && !body.isEmpty() && body.get(0).containsKey("success")) {
				String username = body.get(0).get("success").get("username");
				System.out.println("Utente registrato con successo: " + username);
				return username;
			} else {
				System.err.println("Errore durante la registrazione dell'utente. Risposta API: " + body);
			}
		} catch (Exception e) {
			System.err.println("Errore durante la registrazione dell'utente: " + e.getMessage());
		}
		return null;
	}

	public void eseguiSbarra() {
		try {
			File directory = new File(System.getProperty("user.dir"), "Sbarra");

			// Esegui 'mvn clean install'
			ProcessBuilder cleanInstallBuilder = new ProcessBuilder("mvn", "clean", "install");
			cleanInstallBuilder.directory(directory);
			cleanInstallBuilder.redirectErrorStream(true);
			Process cleanInstallProcess = cleanInstallBuilder.start();
			int exitCode = cleanInstallProcess.waitFor(); // Aspetta che termini
			if (exitCode != 0) {
				System.err.println("Errore durante 'mvn clean install': Codice di uscita " + exitCode);
				return;
			}

			// Esegui 'mvn exec:java' in un nuovo thread
			new Thread(() -> {
				try {
					ProcessBuilder execJavaBuilder = new ProcessBuilder("mvn", "exec:java");
					execJavaBuilder.directory(directory);
					execJavaBuilder.redirectErrorStream(true);
					Process execJavaProcess = execJavaBuilder.start();
					execJavaProcess.waitFor(); // Aspetta la fine del processo
				} catch (IOException | InterruptedException e) {
					e.printStackTrace();
					System.err.println("Errore durante l'esecuzione di 'mvn exec:java': " + e.getMessage());
				}
			}).start();

		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
			System.err.println("Errore durante l'esecuzione di 'mvn clean install': " + e.getMessage());
		}
	}

	private synchronized void apriSbarra() {
		String barrierOpenUrl = "http://localhost:9090/api/barrier/open";
		RestTemplate restTemplate = new RestTemplate();

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<>(null, headers);

			ResponseEntity<String> response = restTemplate.exchange(
					barrierOpenUrl,
					HttpMethod.POST,
					request,
					String.class
			);
			System.out.println("Sbarra aperta. Risposta API: " + response.getBody());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Errore durante l'apertura della sbarra: " + e.getMessage());
		}
	}

	private synchronized void chiudiSbarra() {
		String barrierCloseUrl = "http://localhost:9090/api/barrier/close";
		RestTemplate restTemplate = new RestTemplate();

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<>(null, headers);

			ResponseEntity<String> response = restTemplate.exchange(
					barrierCloseUrl,
					HttpMethod.POST,
					request,
					String.class
			);
			System.out.println("Sbarra chiusa. Risposta API: " + response.getBody());
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Errore durante la chiusura della sbarra: " + e.getMessage());
		}
	}

	public void Abbonamento() {
		System.out.println("Avvio della funzione Abbonamento");
		if (token == null || token.isEmpty()) {
			System.out.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
		}

		// Estrazione dell'username dal token
		String username = "";
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.out.println("Errore: Il token non contiene un username valido.");
			}
			System.out.println("Utente autenticato: " + username);
		} catch (Exception e) {
			System.out.println("Errore durante la validazione del token: " + e.getMessage());
		}

		// Recupero dell'utente dal repository
		Optional<User> userOptional = userRepository.findByUsername(username);
		if (!userOptional.isPresent()) {
			System.out.println("Errore: Utente non trovato.");
		}

		User user = userOptional.get();

		// Controlla se l'utente è già PREMIUM
		if (user.getRuolo().equals(Ruolo.PREMIUM)) {
			System.out.println("Errore: SEI GIA PREMIUM!!!!!!");
			System.out.flush(); // Assicura che il messaggio venga stampato subito prima del menu
		}
		if (user.getRuolo().equals(Ruolo.ADMIN)) {
			System.out.println("Errore: SEI GIA ADMIN!!!!!!");
			System.out.flush(); // Assicura che il messaggio venga stampato subito prima del menu
		}

		// Ciclo per verificare il saldo e aggiornarlo se necessario
		while (user.getSaldo() < 20) {
			System.out.println("Saldo insufficiente, il tuo saldo è: " + user.getSaldo());
			String aggiornamentoSaldoRisultato = aggiornaSaldo();
			System.out.println("Risultato aggiornamento saldo: " + aggiornamentoSaldoRisultato);

			// Ricarica l'utente dal repository per ottenere il saldo aggiornato
			user = userRepository.findByUsername(username).orElse(null);
			if (user == null) {
				System.out.println("Errore: Utente non trovato dopo l'aggiornamento del saldo.");
			}
		}

		// Chiedi conferma per l'abbonamento
		Scanner scanner = new Scanner(System.in);
		String risposta;

		do {
			System.out.println("Vuoi procedere con l'abbonamento a PREMIUM al costo di 20 euro? (si/no):");
			risposta = scanner.nextLine().trim().toLowerCase();

			if (!risposta.equals("si") && !risposta.equals("no")) {
				System.out.println("Risposta non valida. Inserisci 'si' o 'no'.");
			}
		} while (!risposta.equals("si") && !risposta.equals("no"));

		if (risposta.equals("no")) {
			System.out.println("Abbonamento annullato dall'utente.");
		}

		// Preparazione della chiamata al servizio tramite il controller
		String url = "https://localhost:8443/api/users/abbonamento";
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token);
		headers.setContentType(MediaType.APPLICATION_JSON);

		Map<String, String> requestBody = new HashMap<>();
		requestBody.put("username", username);

		HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);

		try {
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);
			System.out.println("RISPOSTA --> " + response.getBody());
		} catch (HttpClientErrorException e) {
			System.out.println("Errore durante l'aggiornamento dell'abbonamento: " + e.getResponseBodyAsString());
		} catch (Exception e) {
			System.out.println("Errore interno: " + e.getMessage());
		}
	}

	public void aggiornacostoSosta() {
		if (token == null || token.isEmpty()) {
			System.err.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		// Validazione del token
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.err.println("Errore: Il token non contiene un username valido.");
				return;
			}
			// Recupera l'utente dal repository e verifica il ruolo
			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.err.println("Errore: Utente non trovato.");
				return;
			}

			String ruolo = userOpt.get().getRuolo().toString();
			if (!"ADMIN".equalsIgnoreCase(ruolo)) {
				System.err.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
				return;
			}
		} catch (Exception e) {
			System.err.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// Lettura del nuovo costo della sosta dall'utente
		Scanner scanner = new Scanner(System.in);
		double nuovoCostoSosta = -1;
		while (nuovoCostoSosta < 0) {
			System.out.println("Inserisci il nuovo costo della sosta (numero maggiore o uguale a 0): ");
			String input = scanner.nextLine();
			try {
				nuovoCostoSosta = Double.parseDouble(input);
				if (nuovoCostoSosta < 0) {
					System.out.println("Errore: il costo deve essere maggiore o uguale a 0.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Errore: input non valido. Inserisci un numero valido.");
			}
		}

		// Preparazione della richiesta HTTP
		String url = "https://localhost:8443/Admin/Aggiorna-Costo-Sosta";
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token);
		headers.setContentType(MediaType.APPLICATION_JSON);

		// Invia solo il valore Double come corpo della richiesta
		HttpEntity<Double> requestEntity = new HttpEntity<>(nuovoCostoSosta, headers);

		// Invio della richiesta PUT al server
		try {
			RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);

		} catch (HttpClientErrorException e) {
			System.err.println("Errore durante l'aggiornamento del costo della sosta: " + e.getResponseBodyAsString());

		} catch (Exception e) {
			System.err.println("Errore durante la chiamata all'API: " + e.getMessage());

		}
	}

	private void aggiornacostoRicarica() {
		// Controllo iniziale: verifica se il token è presente
		if (token == null || token.isEmpty()) {
			System.err.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		// Validazione del token e verifica del ruolo ADMIN
		try {
			// Estrai l'username dal token
			String username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.err.println("Errore: Il token non contiene un username valido.");
				return;
			}

			// Recupera l'utente dal repository e verifica il ruolo
			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.err.println("Errore: Utente non trovato.");
				return;
			}

			String ruolo = userOpt.get().getRuolo().toString();
			if (!"ADMIN".equalsIgnoreCase(ruolo)) {
				System.err.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
				return;
			}

		} catch (Exception e) {
			System.err.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// Richiedi il nuovo costo della ricarica
		double x;
		while (true) {
			s.nextLine();

			System.out.println("Dimmi il nuovo costo della ricarica:");
			String input = s.nextLine().trim(); // Legge l'input dell'utente e rimuove spazi vuoti

			// Controlla se l'input è valido
			if (input.isEmpty()) {
				System.err.println("Errore: il valore non può essere vuoto. Riprova.");
				continue;
			}

			try {
				x = Double.parseDouble(input); // Prova a convertire l'input in un double
				if (x < 0) {
					System.err.println("Errore: il valore non può essere negativo. Riprova.");
					continue;
				}
				break; // Esce dal ciclo se l'input è valido
			} catch (NumberFormatException e) {
				System.err.println("Errore: il valore inserito non è un numero valido. Riprova.");
			}
		}

		// URL dell'API
		String url = "https://localhost:8443/Admin/Aggiorna-Costo-ricarica";

		// Configura RestTemplate con supporto HTTPS
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		// Prepara l'intestazione con il token
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token); // Inserisci il token JWT
		headers.setContentType(MediaType.APPLICATION_JSON); // Imposta il tipo di contenuto

		// Crea il corpo della richiesta
		HttpEntity<Double> requestEntity = new HttpEntity<>(x, headers);

		try {
			// Esegui la richiesta PUT
			restTemplate.exchange(url, HttpMethod.PUT, requestEntity, Void.class);
			System.out.println("Costo della ricarica aggiornato con successo!");
		} catch (Exception e) {
			System.err.println("Errore durante la chiamata all'API: " + e.getMessage());
		}
	}

	public void SetRitardo() {
		if (token == null || token.isEmpty()) {
			System.err.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		String username;
		// Validazione del token e verifica del ruolo ADMIN
		try {
			// Estrai l'username dal token
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.err.println("Errore: Il token non contiene un username valido.");
				return;
			}

			// Recupera l'utente dal repository e verifica il ruolo
			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.err.println("Errore: Utente non trovato.");
				return;
			}

			String ruolo = userOpt.get().getRuolo().toString();
			if (!"ADMIN".equalsIgnoreCase(ruolo)) {
				System.err.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
				return;
			}

		} catch (Exception e) {
			System.err.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();
		// Recupera tutte le prenotazioni
		List<Reservation> reservations = reservationRepository.findAll();

		if (reservations.isEmpty()) {
			System.out.println("Nessuna prenotazione trovata nel database.");
			return;
		}

		// Stampa l'intestazione della tabella
		System.out.printf("%-5s | %-15s | %-10s | %-12s | %-8s | %-8s%n",
				"ID", "Username", "Targa", "Giorno", "Ora Inizio", "Durata");
		System.out.println("--------------------------------------------------------------");

		// Stampa ogni prenotazione in riga
		for (Reservation reservation : reservations) {
			User user = userRepository.findById(reservation.getUser().getId()).orElse(null);
			ChargeRequest chargeRequest = chargeRequestRepository.findById(reservation.getChargeRequest().getId()).orElse(null);

			String username2 = (user != null) ? user.getUsername() : "Sconosciuto";
			String giorno = (chargeRequest != null) ? chargeRequest.getGiorno().toString() : "N/D";
			String oraInizio = (chargeRequest != null) ? chargeRequest.getOra().toString() : "N/D";
			String durata = (chargeRequest != null) ? chargeRequest.getdurata().toString() : "N/D";

			System.out.printf("%-5d | %-15s | %-10s | %-12s | %-8s | %-8s%n",
					reservation.getId(), username2, reservation.getTarga(), giorno, oraInizio, durata);
		}

		long idScelto = 0L;
		int ok = 0;
		Optional<Reservation> optionalReservation = Optional.empty();
		// Chiede all'utente di selezionare un ID prenotazione
		while(ok == 0) {
			try {
				System.out.print("\nInserisci l'ID della prenotazione per segnalare il ritardo: ");
				idScelto = s.nextLong();
				s.nextLine(); // Consuma l'input per evitare problemi di nextLine()
				ok = 1;
			} catch (InputMismatchException e) {
				System.err.println("Errore --> inserire id valido");
				s.nextLine();
				ok = 0;
			}
			// Verifica se l'ID della prenotazione esiste nel database
			optionalReservation = reservationRepository.findById(idScelto);
			if (optionalReservation.isEmpty()) {
				System.out.println("Errore: Nessuna prenotazione trovata con l'ID specificato.");
				ok = 0;
			}
		}

		Reservation reservation = optionalReservation.get();

		// Invia la richiesta POST all'API /Setritardo
		String apiUrl = "https://localhost:8443/Admin/Setritardo";

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT alla richiesta

		HttpEntity<Reservation> requestEntity = new HttpEntity<>(reservation, headers);

		restTemplate.exchange(apiUrl, HttpMethod.POST, requestEntity, String.class);

		System.out.println("Richiesta di ritardo inviata con successo per la prenotazione ID: " + idScelto);
	}

	public void pagaRitardo() {
		String conferma;
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		if (token == null || token.isEmpty()) {
			System.err.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.err.println("Errore: Il token non contiene un username valido.");
				return;
			}

			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.err.println("Errore: Utente non trovato.");
				return;
			}

		} catch (Exception e) {
			System.err.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// Recupera tutte le prenotazioni ritardate
		List<DelayedReservation> delayedReservations = delayedReservationRepository.findByUserUsername(username);

		if (delayedReservations.isEmpty()) {
			System.out.println("Nessuna prenotazione in ritardo trovata.");
			return;
		}

		// Stampa le prenotazioni ritardate
		System.out.printf("%-5s | %-15s | %-10s | %-12s | %-8s%n",
				"ID", "Username", "Targa", "Data Spostamento", "Costo Ritardo (€)");
		System.out.println("--------------------------------------------------------");

		for (DelayedReservation delayedReservation : delayedReservations) {
			if (delayedReservation.getUsername().matches(username)) {
				System.out.printf("%-5d | %-15s | %-10s | %-12s | %-8.2f%n",
						delayedReservation.getId(), delayedReservation.getUsername(), delayedReservation.getTarga(),
						delayedReservation.getGiorno(), 20.0);
			}
		}

		long idScelto = 0L;
		int ok = 0;
		Optional<DelayedReservation> optionalDelayedReservation = Optional.empty();
		// Chiede all'utente di selezionare un ID prenotazione
		while(ok == 0) {
			try {
				System.out.print("\nInserisci l'ID della prenotazione per segnalare il ritardo: ");
				idScelto = s.nextLong();
				s.nextLine(); // Consuma l'input per evitare problemi di nextLine()
				ok = 1;
			} catch (InputMismatchException e) {
				System.err.println("Errore --> inserire id valido");
				s.nextLine();
				ok = 0;
			}
			// Verifica se l'ID della prenotazione esiste nel database
			optionalDelayedReservation = delayedReservationRepository.findById(idScelto);
			if (optionalDelayedReservation.isEmpty()) {
				System.out.println("Errore: Nessuna prenotazione trovata con l'ID specificato.");
				ok = 0;
			}
		}

		Optional<User> user = userRepository.findByUsername(username);
		while (user.get().getSaldo() < 20) {
			System.out.println("Saldo insufficiente, il tuo saldo è: " + user.get().getSaldo() + ", premere invio per ricaricare!!");
			String aggiornamentoSaldoRisultato = aggiornaSaldo();
			System.out.println("Risultato aggiornamento saldo: " + aggiornamentoSaldoRisultato);

			// Ricarica l'utente dal repository per ottenere il saldo aggiornato
			user = userRepository.findByUsername(username);
			if (user.isEmpty()) {
				System.out.println("Errore: Utente non trovato dopo l'aggiornamento del saldo.");
				return;
			}
		}

		if (optionalDelayedReservation.get().getUsername().matches(username)) {
			DelayedReservation delayedReservation = optionalDelayedReservation.get();
			// Invia la richiesta POST all'API /Setritardo
			String apiUrl = "https://localhost:8443/reservations/PagaRitardo";

			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + token); // Aggiunge il token JWT alla richiesta

			HttpEntity<DelayedReservation> requestEntity = new HttpEntity<>(delayedReservation, headers);

			restTemplate.exchange(apiUrl, HttpMethod.POST, requestEntity, String.class);
		} else {
			System.err.println("Errore: hai inserito un id non valido");
			return;
		}
	}

	public void spostaSoste(){
		if (token == null || token.isEmpty()) {
			System.err.println("Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		// Validazione del token
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.err.println("Errore: Il token non contiene un username valido.");
				return;
			}
			// Recupera l'utente dal repository e verifica il ruolo
			Optional<User> userOpt = userRepository.findByUsername(username);
			if (!userOpt.isPresent()) {
				System.err.println("Errore: Utente non trovato.");
				return;
			}

			String ruolo = userOpt.get().getRuolo().toString();
			if (!"ADMIN".equalsIgnoreCase(ruolo)) {
				System.err.println("Errore: Solo gli utenti con ruolo ADMIN possono eseguire questa operazione.");
				return;
			}
		} catch (Exception e) {
			System.err.println("Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// URL dell'API
		String url = "https://localhost:8443/Admin/SpostaSoste";

		// Configura RestTemplate con supporto HTTPS
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		// Prepara l'intestazione con il token
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token); // Inserisci il token JWT
		headers.setContentType(MediaType.APPLICATION_JSON); // Imposta il tipo di contenuto

		// Crea la richiesta senza corpo
		HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

		try {
			// Esegui la richiesta POST
			ResponseEntity<Void> response = restTemplate.exchange(url, HttpMethod.POST, requestEntity, Void.class);
			System.out.println("Soste Vecchie cancellate con successo!");
		} catch (HttpClientErrorException e) {
			System.err.println("Errore HTTP durante la chiamata all'API: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
		} catch (Exception e) {
			System.err.println("Errore durante la chiamata all'API: " + e.getMessage());
		}

	}

	/*
	public void esciPrimaDalParcheggio() {
		if (token == null || token.isEmpty()) {
			System.out.println("❌ Errore: Token JWT mancante. Effettua il login prima di procedere.");
			return;
		}

		// Estrazione dell'username dal token
		String username;
		try {
			username = jwtUtil.validateToken(token);
			if (username == null || username.isEmpty()) {
				System.out.println("❌ Errore: Il token non contiene un username valido.");
				return;
			}
		} catch (Exception e) {
			System.out.println("❌ Errore durante la validazione del token: " + e.getMessage());
			return;
		}

		// Creazione di RestTemplate con supporto HTTPS
		RestTemplate restTemplate = httpsRestTemplateConfig.createRestTemplate();

		// URL dell'endpoint per l'uscita anticipata
		String apiUrl = "https://localhost:8443/reservations/uscita-anticipata";

		// Creazione delle intestazioni HTTP
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + token);
		headers.setContentType(MediaType.APPLICATION_JSON);

		// Creazione della richiesta HTTP con le intestazioni
		HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

		String result;
		try {
			// Chiamata API per l'uscita anticipata
			ResponseEntity<String> response = restTemplate.exchange(
					apiUrl + "?username=" + username,
					HttpMethod.POST,
					requestEntity,
					String.class
			);
			result = response.getBody();
		} catch (Exception e) {
			result = "❌ Errore durante l'uscita anticipata: " + e.getMessage();
		}

		// Stampa tabella formattata con dettagli della prenotazione
		System.out.println("╔════════════════════════════════════════╗");
		System.out.println("║         🚗 USCITA PARCHEGGIO 🚗        ║");
		System.out.println("╠════════════════════════════════════════╣");
		System.out.printf("║ %-15s: %-20s ║%n", "Utente", username);
		System.out.printf("║ %-15s: %-20s ║%n", "Esito", result);
		System.out.println("╚════════════════════════════════════════╝");
	}
*/
	public void logout() {
		if (token == null || token.isEmpty()) {
			System.out.println("❌ Errore: Nessun utente è attualmente loggato.");
			return;
		}

		// Reset del token
		token = null;

		// Messaggio di conferma
		System.out.println("✅ Logout effettuato con successo. Dovrai accedere nuovamente per utilizzare il sistema.");
	}

	private void startBot() {
		try {
			// Ottieni il percorso assoluto della directory del progetto
			String projectDir = System.getProperty("user.dir"); // Directory corrente del progetto

			// Costruisci il percorso completo del JAR
			String jarPath = projectDir + "/parcheggio/target/mwbot.jar";

			// Rilevamento del sistema operativo
			String os = System.getProperty("os.name").toLowerCase();

			ProcessBuilder processBuilder;

			if (os.contains("win")) {
				// Windows: utilizza cmd.exe per aprire una nuova finestra di terminale
				processBuilder = new ProcessBuilder("cmd.exe", "/c", "start", "java", "-jar", jarPath);
			} else if (os.contains("mac")) {
				// macOS: utilizza AppleScript per aprire una nuova scheda del terminale
				processBuilder = new ProcessBuilder(
						"osascript", "-e",
						"tell application \"Terminal\" to do script \"java -jar " + jarPath + "\""
				);
			} else if (os.contains("nix") || os.contains("nux")) {
				// Linux: utilizza gnome-terminal o x-terminal-emulator per aprire una nuova finestra
				processBuilder = new ProcessBuilder("sh", "-c", "gnome-terminal -- java -jar " + jarPath);
			} else {
				throw new UnsupportedOperationException("Sistema operativo non supportato");
			}

			// Avvia il processo
			processBuilder.start();
			System.out.println("✅ Bot avviato correttamente in una nuova scheda!");

			// Ritardo prima di tornare al menu
			Thread.sleep(1000); // Ritardo di 1 secondo (1000 millisecondi)
			System.out.println("🔄 Ritorno al menu...");
		} catch (IOException e) {
			System.err.println("❌ Errore durante l'avvio del bot: " + e.getMessage());
			e.printStackTrace();
		} catch (InterruptedException e) {
			System.err.println("❌ Errore durante l'attesa: " + e.getMessage());
			Thread.currentThread().interrupt();
		}
	}

	public void stopBot() {
		String os = System.getProperty("os.name").toLowerCase();

		try {
			if (os.contains("win")) {
				// Windows: chiude completamente tutte le finestre del terminale
				new ProcessBuilder("taskkill", "/F", "/IM", "cmd.exe").start();
			} else if (os.contains("mac")) {
				// macOS: chiude completamente l'app del Terminale
				new ProcessBuilder("osascript", "-e", "tell application \"Terminal\" to quit").start();
			} else if (os.contains("nix") || os.contains("nux")) {
				// Linux: chiude completamente l'app del terminale
				new ProcessBuilder("pkill", "gnome-terminal").start();
				new ProcessBuilder("pkill", "x-terminal-emulator").start();
				new ProcessBuilder("pkill", "konsole").start(); // KDE terminal
				new ProcessBuilder("pkill", "xfce4-terminal").start(); // XFCE terminal
				new ProcessBuilder("pkill", "mate-terminal").start(); // MATE terminal
			} else {
				throw new UnsupportedOperationException("Sistema operativo non supportato");
			}

			System.out.println("✅ Terminale chiuso con successo!");
		} catch (IOException e) {
			System.err.println("❌ Errore durante la chiusura del terminale: " + e.getMessage());
		}
	}
}
