package Principale.Parcheggio.Models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "delayed_reservations")
public class DelayedReservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "charge_request_id", nullable = false)
    private ChargeRequest chargeRequest;

    @ManyToOne
    @JoinColumn(name = "payment_id", nullable = false)
    private Payment payment;

    @Column(name = "auto", nullable = false)
    private String Targa;

    @Column
    private Boolean ricarica;

    @Column
    private LocalDateTime dataSpostamento;

    // Costruttore
    public DelayedReservation() {}

    public DelayedReservation(Reservation reservation) {
        this.user = reservation.getUser();
        this.chargeRequest = reservation.getChargeRequest();
        this.payment = reservation.getPayment();
        this.Targa = reservation.getTarga();
        this.ricarica = reservation.getRicarica();
        this.dataSpostamento = LocalDateTime.now();
    }

    // Getters e Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public ChargeRequest getChargeRequest() { return chargeRequest; }
    public void setChargeRequest(ChargeRequest chargeRequest) { this.chargeRequest = chargeRequest; }

    public Payment getPayment() { return payment; }
    public void setPayment(Payment payment) { this.payment = payment; }

    public String getTarga() { return Targa; }
    public void setTarga(String targa) { this.Targa = targa; }

    public Boolean getRicarica() { return ricarica; }
    public void setRicarica(Boolean ricarica) { this.ricarica = ricarica; }

    public LocalDateTime getDataSpostamento() { return dataSpostamento; }
    public void setDataSpostamento(LocalDateTime dataSpostamento) { this.dataSpostamento = dataSpostamento; }
}

